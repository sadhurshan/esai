# Definition of Done
1) API envelope + correct codes. 2) RBAC enforced. 3) Pagination/sorting. 4) UI: skeleton, empty, inline validation, toasts. 5) Audit entries on mutations. 6) Notifications wired. 7) Docs updated. 8) Lint/type clean + basic tests.
