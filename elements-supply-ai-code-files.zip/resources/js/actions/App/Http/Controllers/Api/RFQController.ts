import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RFQController::index
 * @see app/Http/Controllers/Api/RFQController.php:16
 * @route '/api/rfqs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfqs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RFQController::index
 * @see app/Http/Controllers/Api/RFQController.php:16
 * @route '/api/rfqs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RFQController::index
 * @see app/Http/Controllers/Api/RFQController.php:16
 * @route '/api/rfqs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RFQController::index
 * @see app/Http/Controllers/Api/RFQController.php:16
 * @route '/api/rfqs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RFQController::index
 * @see app/Http/Controllers/Api/RFQController.php:16
 * @route '/api/rfqs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RFQController::index
 * @see app/Http/Controllers/Api/RFQController.php:16
 * @route '/api/rfqs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RFQController::index
 * @see app/Http/Controllers/Api/RFQController.php:16
 * @route '/api/rfqs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\RFQController::store
 * @see app/Http/Controllers/Api/RFQController.php:71
 * @route '/api/rfqs'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/rfqs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RFQController::store
 * @see app/Http/Controllers/Api/RFQController.php:71
 * @route '/api/rfqs'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RFQController::store
 * @see app/Http/Controllers/Api/RFQController.php:71
 * @route '/api/rfqs'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RFQController::store
 * @see app/Http/Controllers/Api/RFQController.php:71
 * @route '/api/rfqs'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RFQController::store
 * @see app/Http/Controllers/Api/RFQController.php:71
 * @route '/api/rfqs'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\RFQController::show
 * @see app/Http/Controllers/Api/RFQController.php:54
 * @route '/api/rfqs/{rfq}'
 */
export const show = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RFQController::show
 * @see app/Http/Controllers/Api/RFQController.php:54
 * @route '/api/rfqs/{rfq}'
 */
show.url = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: args.rfq,
                }

    return show.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RFQController::show
 * @see app/Http/Controllers/Api/RFQController.php:54
 * @route '/api/rfqs/{rfq}'
 */
show.get = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RFQController::show
 * @see app/Http/Controllers/Api/RFQController.php:54
 * @route '/api/rfqs/{rfq}'
 */
show.head = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RFQController::show
 * @see app/Http/Controllers/Api/RFQController.php:54
 * @route '/api/rfqs/{rfq}'
 */
    const showForm = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RFQController::show
 * @see app/Http/Controllers/Api/RFQController.php:54
 * @route '/api/rfqs/{rfq}'
 */
        showForm.get = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RFQController::show
 * @see app/Http/Controllers/Api/RFQController.php:54
 * @route '/api/rfqs/{rfq}'
 */
        showForm.head = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\RFQController::update
 * @see app/Http/Controllers/Api/RFQController.php:95
 * @route '/api/rfqs/{rfq}'
 */
export const update = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/rfqs/{rfq}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\RFQController::update
 * @see app/Http/Controllers/Api/RFQController.php:95
 * @route '/api/rfqs/{rfq}'
 */
update.url = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: args.rfq,
                }

    return update.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RFQController::update
 * @see app/Http/Controllers/Api/RFQController.php:95
 * @route '/api/rfqs/{rfq}'
 */
update.put = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\RFQController::update
 * @see app/Http/Controllers/Api/RFQController.php:95
 * @route '/api/rfqs/{rfq}'
 */
    const updateForm = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RFQController::update
 * @see app/Http/Controllers/Api/RFQController.php:95
 * @route '/api/rfqs/{rfq}'
 */
        updateForm.put = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\RFQController::destroy
 * @see app/Http/Controllers/Api/RFQController.php:133
 * @route '/api/rfqs/{rfq}'
 */
export const destroy = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/rfqs/{rfq}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\RFQController::destroy
 * @see app/Http/Controllers/Api/RFQController.php:133
 * @route '/api/rfqs/{rfq}'
 */
destroy.url = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: args.rfq,
                }

    return destroy.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RFQController::destroy
 * @see app/Http/Controllers/Api/RFQController.php:133
 * @route '/api/rfqs/{rfq}'
 */
destroy.delete = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\RFQController::destroy
 * @see app/Http/Controllers/Api/RFQController.php:133
 * @route '/api/rfqs/{rfq}'
 */
    const destroyForm = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RFQController::destroy
 * @see app/Http/Controllers/Api/RFQController.php:133
 * @route '/api/rfqs/{rfq}'
 */
        destroyForm.delete = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const RFQController = { index, store, show, update, destroy }

export default RFQController