import HealthController from './HealthController'
import FileController from './FileController'
import SupplierController from './SupplierController'
import RFQController from './RFQController'
import RFQQuoteController from './RFQQuoteController'
import OrderController from './OrderController'
const Api = {
    HealthController: Object.assign(HealthController, HealthController),
FileController: Object.assign(FileController, FileController),
SupplierController: Object.assign(SupplierController, SupplierController),
RFQController: Object.assign(RFQController, RFQController),
RFQQuoteController: Object.assign(RFQQuoteController, RFQQuoteController),
OrderController: Object.assign(OrderController, OrderController),
}

export default Api