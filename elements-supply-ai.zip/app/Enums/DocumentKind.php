<?php

namespace App\Enums;

enum DocumentKind: string
{
    case Rfq = 'rfq';
    case Quote = 'quote';
    case Rfp = 'rfp';
    case RfpProposal = 'rfp_proposal';
    case PurchaseOrder = 'po';
    case GoodsReceipt = 'grn_attachment';
    case Invoice = 'invoice';
    case Supplier = 'supplier';
    case Part = 'part';
    case Cad = 'cad';
    case Manual = 'manual';
    case Certificate = 'certificate';
    case EsgPack = 'esg_pack';
    case Other = 'other';

    /**
     * @return list<string>
     */
    public static function values(): array
    {
        return array_map(static fn (self $case) => $case->value, self::cases());
    }
}
