<?php

namespace App\Enums;

enum MoneyRoundRule: string
{
    case Bankers = 'bankers';
    case HalfUp = 'half_up';
}
