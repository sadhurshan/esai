<?php

namespace App\Exceptions;

use RuntimeException;

class AiServiceUnavailableException extends RuntimeException
{
}
