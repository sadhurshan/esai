<?php

namespace App\Exceptions;

use RuntimeException;

class AiWorkflowException extends RuntimeException
{
}
