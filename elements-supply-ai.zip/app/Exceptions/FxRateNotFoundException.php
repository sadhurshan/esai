<?php

namespace App\Exceptions;

use RuntimeException;

class FxRateNotFoundException extends RuntimeException
{
}
