<?php

namespace App\Exceptions;

use RuntimeException;

class UnitConversionException extends RuntimeException
{
}
