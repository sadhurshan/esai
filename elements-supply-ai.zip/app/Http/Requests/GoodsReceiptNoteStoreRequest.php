<?php

namespace App\Http\Requests;

class GoodsReceiptNoteStoreRequest extends StoreGoodsReceiptRequest
{
}
