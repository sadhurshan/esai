<?php

namespace App\Http\Requests;

class GoodsReceiptNoteUpdateRequest extends UpdateGoodsReceiptRequest
{
}
