<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'login.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'register.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/email/verify' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.notice',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/email/verification-notification' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.send',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/confirm-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/confirmed-password-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirmation',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/two-factor-challenge' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.login.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/two-factor-authentication' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.enable',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.disable',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/confirmed-two-factor-authentication' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/two-factor-qr-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.qr-code',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/two-factor-secret-key' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.secret-key',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/two-factor-recovery-codes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.recovery-codes',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.regenerate-recovery-codes',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/health' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xsbgNIsOs5vGEMPR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/docs/openapi.json' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6T7plqb00DXNzBKB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/docs/postman.json' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YYue2eXxgHj0es1i',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/plans' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gJX0GCEScrxPS9r2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company/plan-selection' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8dP9k7WBJisQw5iN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/billing/checkout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RzYYPDnbnX4W54OB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/billing/portal' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qLhqhIRvFSGfKkAn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/billing/invoices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6wuv3rzYCGm5t7y8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/supplier-documents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hrfLDYP3VHaNLEfe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3sg0b8rSuSbxhIen',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JkoeLmQXydvKoi8B',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FCW7UagCFtBCguov',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/companies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LfqUQJoOLqc11IMz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/companies/switch' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A60hGalqCCxRWUdV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/supplier-application/status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HiA6W2zJXb441eMf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/supplier/visibility' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2bEG9nrBskLpfdr5',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/me/apply-supplier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FRQ5RibkmaIvwQYa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/plans' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'plans.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'plans.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/companies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U1dPEgZ2mkAgPwVB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/email-templates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'email-templates.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'email-templates.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/digital-twin-categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'digital-twin-categories.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'digital-twin-categories.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/digital-twins' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'digital-twins.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'digital-twins.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/api-keys' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::82oM1vjd0e6Cqffm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::72zXWpCNASIXaBay',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/rate-limits' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rate-limits.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'rate-limits.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/webhook-subscriptions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'webhook-subscriptions.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'webhook-subscriptions.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/webhook-deliveries' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5GWxCmarAql1Ep64',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/health' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cqo0OVkvnDfgmQI2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LkqMbQHpdBi10RqQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/audit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VWazyKifqIBG8Lu7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/company-approvals' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TBwcdORZOrXIvC3S',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/analytics/overview' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::o8B3CMPpFspvPLzZ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/supplier-applications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WiwyH3cYbSXClYaA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/suppliers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ckOfRiCw4gVHltdO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/supplier-applications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lFJMKl9nwq1E97Yy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SBcYl93w0lwmx65z',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/library/digital-twins' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4UMvZUVjK3C0TbmW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rfps' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vh2AExWFuztH53Vj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nGr81Wo3XG1Q5ayV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rfqs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0bxeYwYuNOsR3eUI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LO3UZxkwXgPfF0qw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/awards' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fPN44IrSrUnA8PO3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/quotes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KUB7HG9PtFNyLQlW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nW2Y45TomFn8R4D3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pos/from-awards' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::whL1TzFhBZk5HNoa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/buyer/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4BBj9CL6rZureXYT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/supplier/dashboard/metrics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XpBJKYZq6xJdPUzk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/supplier/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7EncuICUF8faZHAH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/supplier/invoices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7QkDu4Gk8qkrDDvh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/supplier/quotes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jpGMLz5PIGHV452h',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/supplier/rfqs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::No8mWZ4oL2r7zdd7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/purchase-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H1EKYm5fx2lbJixm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/receiving/grns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZqIa0hW565sQUo1T',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zJQvxrxrvwvEKr96',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/companies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ooiEgne63GqJjHFG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/invoices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ovmBLxygE0JFFBaM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/inventory/items' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::leKrbrFuJfglxLkn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kdBBmU1qzbJQ47Pf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/inventory/low-stock' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M0VSAPg6msbzag7o',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/inventory/movements' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mYgQA5S8msdySPYM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8JVLVfFsgsFKwG5i',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/inventory/locations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pvjxqdh8FNDsJLDM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/documents' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cCqTuwfF9GyWlaId',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company-invitations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tKOb6fNeSQl55PWy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iHEawvS5XqN7YbR5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company-members' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KDc8cAdzFaHPQkIF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/company-role-templates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uD1hwfAn6GN2HBJM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/settings/company' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::csg1kktVVvTNetUx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::o9KW5bBZ6LOEpbfa',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/settings/localization' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jhsBIcyWWLswj0kI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0zoUkKQFasvpIqaF',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/settings/numbering' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ujVuUPZxpf15IUoK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9lX9tdWZ8q6tQPkP',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/dashboard/metrics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NMxQ5Eh49c8cNva9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/localization/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RVQlC98VAggWg8jR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VQ1ZSiI46aazlPEY',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/localization/uoms' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HlBvckcfF0sZ9K5n',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PfkIc33ozGwCNMq8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/localization/uom/convert' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ESw45oa7EEIkHalc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/digital-twin/locations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'locations.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/digital-twin/systems' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'systems.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'systems.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/digital-twin/assets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assets.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'assets.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/digital-twin/procedures' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'procedures.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'procedures.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/search' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OIH2O1lMaEQfhE6g',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/saved-searches' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KVNSNRXeyLe6esK9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4OCAiCupQVxiCfrz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/analytics/overview' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mddk0SRNXdaU5dH3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/analytics/generate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hif8AHiV7wl32eFF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/copilot/analytics' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vDGuB5q8pKt8Fs2U',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/risk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UiCq2Ib3VyEb0Fra',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/notifications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XCGEPI2EXYis7tzO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/notifications/read' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::85YrfR6AZzdgVxIE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/notifications/mark-all-read' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jvuq8CFIQJOm5IOb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/events/deliveries' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QQszrA5dkNFtaHzq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/events/dlq/replay' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JZx9Oh7Wjk8MzaWi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/notification-preferences' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g6iTj3b1Xd816OwE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AFw1nGA9LvipVlFa',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/rmas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wWItQCVbauFcDgMu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/exports' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sCACUa5GkHRyAxtI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9FLFxwsxl78OKHQG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/downloads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aXOdJoKMmKZ62wo4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3Y07WpZCtNvNogi2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/credit-notes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lnNDPUOpPCz9ENQG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/money/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TgU77AQta6MAL03Z',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AcRG2hk7Nlk8YlTu',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/money/fx' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RsO3KaKYQxD4arpW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MrbX1qGUTrGsJxcI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/money/tax-codes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tax-codes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tax-codes.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/approvals/rules' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VSQCnlvvd2o53BmE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gvLr3Nm2u61oImwS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/approvals/requests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7kFKf67XieQN7li4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/approvals/delegations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3uyuEpmqg5jYEt75',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t5m4IoS125ETzzF0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/webhooks/stripe/invoice/payment-succeeded' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bWRojI29OpWSfn0e',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/webhooks/stripe/invoice/payment-failed' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YsDhZTkNTVuCpH8e',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/webhooks/stripe/customer/subscription-updated' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p7TJDmwhOu0b4da3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/billing/stripe/webhook' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7rNpHDecmB9yxX7R',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cdgXT97PCV0qUYdf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gwfDT0uuQTjDNgTw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VJvLJxGUAfWhG2Jz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dy5nwTCrcx5ZvqZ1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i6PwFkYIUq46ZFSR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/persona' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::84AOZAYUDoPX8mbm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oPMrMesyfmclGqAI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/auth/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f8SouP5b82ibBwFA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/company-registration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'company.registration',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'profile.destroy',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user-password.edit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'user-password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/two-factor' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/setup/plan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.setup.plan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/suppliers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'suppliers.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/rfqs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rfq.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/rfqs/new' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rfq.new',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'orders.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/purchase-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'purchase-orders.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/purchase-orders/supplier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'purchase-orders.supplier.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/supplier/company-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'supplier.company-profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/inventory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'inventory.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/inventory/items' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'inventory.items.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/inventory/items/new' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'inventory.items.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/admin/companies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.companies.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/broadcasting/auth' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ou89myVrERzcutHW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'POST' => 1,
            'HEAD' => 2,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/reset\\-password/([^/]++)(*:32)|/email/verify/([^/]++)/([^/]++)(*:70)|/ap(?|i/(?|c(?|ompan(?|y\\-(?|invitations/([^/]++)(?|/accept(*:136)|(*:144))|members/([^/]++)(?|(*:172)))|ies/([^/]++)(?|(*:197)|/documents(?|(*:218)|/([^/]++)(*:235))))|hange\\-orders/([^/]++)/(?|approve(*:279)|reject(*:293))|redit\\-notes/(?|invoices/([^/]++)(*:335)|([^/]++)(?|(*:354)|/(?|issue(*:371)|a(?|pprove(*:389)|ttachments(*:407))|lines(*:421)|recalculate(*:440)))))|m(?|e/supplier\\-documents/([^/]++)(*:486)|oney/tax\\-codes/([^/]++)(?|(*:521)))|a(?|dmin/(?|plans/([^/]++)(?|(*:560))|compan(?|ies/([^/]++)/(?|a(?|ssign\\-plan(*:609)|pprove(*:623))|status(*:638)|feature\\-flags(?|(*:663)|/([^/]++)(?|(*:683)))|reject(*:699))|y\\-approvals/([^/]++)/(?|approve(*:740)|reject(*:754)))|email\\-templates/([^/]++)(?|(*:792)|/preview(*:808))|digital\\-twin(?|\\-categories/([^/]++)(?|(*:857))|s/([^/]++)(?|(*:879)|/(?|publish(*:898)|a(?|rchive(*:916)|ssets(?|(*:932)|/([^/]++)(*:949))|udit\\-events(*:970)))))|api\\-keys/([^/]++)(?|/(?|rotate(*:1013)|toggle(*:1028))|(*:1038))|r(?|ate\\-limits/([^/]++)(?|(*:1075))|oles/([^/]++)(*:1098))|webhook\\-(?|subscriptions/([^/]++)(?|(*:1145)|/test(*:1159))|deliveries/([^/]++)/retry(*:1194))|supplier\\-applications/([^/]++)/(?|a(?|pprove(*:1249)|udit\\-logs(*:1268))|reject(*:1284)))|wards/([^/]++)(*:1309)|pprovals/(?|r(?|ules/([^/]++)(?|(*:1350))|equests/([^/]++)(?|(*:1379)|/action(*:1395)))|delegations/([^/]++)(?|(*:1429))))|files/(?|cad/([^/]++)(*:1462)|attachments/([^/]++)(*:1491))|s(?|upplier(?|s/([^/]++)(?|(*:1528)|/esg(?|(*:1544)|/(?|export(*:1563)|([^/]++)(?|(*:1583)))))|\\-applications/([^/]++)(?|(*:1622))|/(?|orders/([^/]++)(?|(*:1654)|/(?|ack(*:1670)|shipments(*:1688)))|invoices/([^/]++)(?|(*:1719)|/submit(*:1735))|purchase\\-orders/([^/]++)/invoices(*:1779)|shipments/([^/]++)/status(*:1813)))|aved\\-searches/([^/]++)(?|(*:1850)))|l(?|ibrary/digital\\-twins/([^/]++)(?|(*:1898)|/use\\-for\\-rfq(*:1921))|ocalization/(?|uoms/(?|([^/]++)(?|(*:1965))|conversions(?|(*:1989)))|parts/([^/]++)/convert(*:2022)))|r(?|f(?|ps/([^/]++)(?|(*:2055)|/(?|p(?|ublish(*:2078)|roposals(?|(*:2098)))|move\\-to\\-review(*:2125)|award(*:2139)|close\\-no\\-award(*:2164)))|q(?|s/([^/]++)(?|(*:2192)|/(?|lines(?|(*:2213)|/([^/]++)(?|(*:2234)))|a(?|ttachments(?|(*:2262))|ward(?|\\-(?|candidates(*:2294)|lines(*:2308))|(*:2318)))|publish(*:2336)|c(?|ancel(*:2354)|l(?|ose(*:2370)|arifications(?|(*:2394)|/(?|([^/]++)/attachments/([^/]++)(*:2436)|question(*:2453)|a(?|nswer(*:2471)|mendment(*:2488))))))|timeline(*:2510)|invitations(?|(*:2533))|quotes(?|(*:2552)|/(?|compare(*:2572)|([^/]++)(?|/(?|revisions(?|(*:2608))|draft(*:2623)|withdraw(*:2640))|(*:2650)))|(*:2661))|extend\\-deadline(*:2687))|(*:2697))|\\-quotes/([^/]++)(?|(*:2727))))|eceiving/(?|grns/([^/]++)(?|(*:2767)|/(?|attachments(*:2791)|ncrs(*:2804)))|ncrs/([^/]++)(*:2828))|isk/(?|([^/]++)(*:2853)|generate(*:2870))|mas/(?|purchase\\-orders/([^/]++)(*:2912)|([^/]++)(?|(*:2932)|/review(*:2948))))|quotes/([^/]++)(?|/(?|s(?|ubmit(*:2991)|hortlist(?|(*:3011)))|lines(?|(*:3030)|/([^/]++)(?|(*:3051)))|recalculate(*:3073))|(*:3083))|buyer/orders/([^/]++)(*:3114)|purchase\\-orders/([^/]++)(?|/(?|s(?|end(*:3162)|hipments(*:3179))|c(?|ancel(*:3198)|hange\\-orders(?|(*:3223)))|e(?|xport(*:3243)|vents(*:3257))|acknowledge(*:3278)|invoices(?|(*:3298))|grns(?|(*:3315)|/([^/]++)(?|(*:3336))|(*:3346))|documents/([^/]++)/download(*:3383)|recalculate(*:3403))|(*:3413))|inv(?|oices/(?|([^/]++)(?|(*:3449))|from\\-po(*:3467)|([^/]++)/(?|attachments(*:3499)|re(?|view/(?|approve(*:3528)|re(?|ject(*:3546)|quest\\-changes(*:3569)))|calculate(*:3589))|mark\\-paid(*:3609)))|entory/items/([0-9]+)(?|(*:3644)))|d(?|o(?|cuments/([^/]++)(?|(*:3682))|wnloads/([^/]++)(?|(*:3711)|/(?|retry(*:3729)|file(*:3742))))|igital\\-twin/(?|locations/([^/]++)(?|(*:3791))|systems/([^/]++)(?|(*:3820))|assets/([^/]++)(?|(*:3848)|/(?|status(*:3867)|bom(*:3879)|procedures/([^/]++)(?|(*:3910)|/complete(*:3928))))|procedures/([^/]++)(?|(*:3962))))|notifications/([^/]++)/read(*:4001)|e(?|vents/deliveries/([^/]++)/retry(*:4045)|xports/([^/]++)(?|(*:4072)|/download(*:4090))))|p/(?|rfqs/(?|([0-9]+)(*:4123)|([0-9]+)/open(*:4145)|([0-9]+)/compare(*:4170))|purchase\\-orders/(?|([0-9]+)/supplier(*:4217)|([0-9]+)(*:4234))|inventory/items/([A-Za-z0-9_-]+)(*:4276)|(.*)(*:4289)))|/s(?|ettings(?:/(.*))?(*:4322)|torage/(.*)(*:4342)))/?$}sDu',
    ),
    3 => 
    array (
      32 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      70 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.verify',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'hash',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      136 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eDNloxbduvcP2TPf',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      144 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IKZgUeMZyiLwfe6y',
          ),
          1 => 
          array (
            0 => 'invitation',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      172 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4sdCyElRIuijZLvr',
          ),
          1 => 
          array (
            0 => 'member',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::03ih5XwIovbm4Pov',
          ),
          1 => 
          array (
            0 => 'member',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      197 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jN7TheR08cRJEktA',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fxpQ3HVIxMff6A6W',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      218 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::16wvbfN0g4pZIgUX',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::71ze8EKiAkNIUDH1',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      235 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::E6WXfI02idP9CuSU',
          ),
          1 => 
          array (
            0 => 'company',
            1 => 'document',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      279 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ObWQZ516kXxV4Gsl',
          ),
          1 => 
          array (
            0 => 'changeOrder',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      293 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QRiufe3pW947E2yT',
          ),
          1 => 
          array (
            0 => 'changeOrder',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      335 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RFIvPHQfi3LRcHKt',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      354 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NIHtWcngkgEe7aO4',
          ),
          1 => 
          array (
            0 => 'creditNote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      371 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D11fcB4MYh8ouVOn',
          ),
          1 => 
          array (
            0 => 'creditNote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      389 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V9IeREvYEQQ0XYFn',
          ),
          1 => 
          array (
            0 => 'creditNote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1l0Axsf9Ai6uIHf2',
          ),
          1 => 
          array (
            0 => 'creditNote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      421 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FEiyIyCiETsuUk9H',
          ),
          1 => 
          array (
            0 => 'creditNote',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      440 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NIHbSMGDurD52dwg',
          ),
          1 => 
          array (
            0 => 'creditNote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      486 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8a4Ge3y5EQXaeZlN',
          ),
          1 => 
          array (
            0 => 'document',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      521 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tax-codes.show',
          ),
          1 => 
          array (
            0 => 'tax_code',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'tax-codes.update',
          ),
          1 => 
          array (
            0 => 'tax_code',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'tax-codes.destroy',
          ),
          1 => 
          array (
            0 => 'tax_code',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      560 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'plans.show',
          ),
          1 => 
          array (
            0 => 'plan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'plans.update',
          ),
          1 => 
          array (
            0 => 'plan',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'plans.destroy',
          ),
          1 => 
          array (
            0 => 'plan',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      609 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::be4ExU58KJk6vd8S',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      623 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rBVSnmbj6G3aYnez',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      638 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Wz0NWskNoEPjCH54',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      663 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sj9Izeu6RAnodg3P',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nlF7OzfCKXpXVmeQ',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      683 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H0mUgLE70kLGXEtA',
          ),
          1 => 
          array (
            0 => 'company',
            1 => 'flag',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TjvulbU3n3kOgUBp',
          ),
          1 => 
          array (
            0 => 'company',
            1 => 'flag',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      699 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::F3xxzc6BAuZxjhOU',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      740 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7SwylZH6THzvQTvY',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      754 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IcMwfvQNGzlYMx0Y',
          ),
          1 => 
          array (
            0 => 'company',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      792 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'email-templates.show',
          ),
          1 => 
          array (
            0 => 'email_template',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'email-templates.update',
          ),
          1 => 
          array (
            0 => 'email_template',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'email-templates.destroy',
          ),
          1 => 
          array (
            0 => 'email_template',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      808 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z8VkqBVQm30QubyZ',
          ),
          1 => 
          array (
            0 => 'email_template',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      857 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'digital-twin-categories.show',
          ),
          1 => 
          array (
            0 => 'digital_twin_category',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'digital-twin-categories.update',
          ),
          1 => 
          array (
            0 => 'digital_twin_category',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'digital-twin-categories.destroy',
          ),
          1 => 
          array (
            0 => 'digital_twin_category',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      879 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'digital-twins.show',
          ),
          1 => 
          array (
            0 => 'digital_twin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'digital-twins.update',
          ),
          1 => 
          array (
            0 => 'digital_twin',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'digital-twins.destroy',
          ),
          1 => 
          array (
            0 => 'digital_twin',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      898 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PuC9MBUmoRetbmFH',
          ),
          1 => 
          array (
            0 => 'digital_twin',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      916 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5U6vFpbktgTMXKDz',
          ),
          1 => 
          array (
            0 => 'digital_twin',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      932 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jmhDw7HtW0lFF0Ta',
          ),
          1 => 
          array (
            0 => 'digital_twin',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      949 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YPeSOCZRCB0NWQwD',
          ),
          1 => 
          array (
            0 => 'digital_twin',
            1 => 'asset',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      970 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SUqWMKgczQk0280Q',
          ),
          1 => 
          array (
            0 => 'digital_twin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1013 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wuxL9Y6F2ykowrRK',
          ),
          1 => 
          array (
            0 => 'key',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1028 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Uqoyvgrgjqd24sLL',
          ),
          1 => 
          array (
            0 => 'key',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1038 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fPVZyzDR0vOCdvkr',
          ),
          1 => 
          array (
            0 => 'key',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1075 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rate-limits.show',
          ),
          1 => 
          array (
            0 => 'rate_limit',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'rate-limits.update',
          ),
          1 => 
          array (
            0 => 'rate_limit',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'rate-limits.destroy',
          ),
          1 => 
          array (
            0 => 'rate_limit',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1098 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oV8gm9UvAq87VXzD',
          ),
          1 => 
          array (
            0 => 'roleTemplate',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1145 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'webhook-subscriptions.show',
          ),
          1 => 
          array (
            0 => 'webhook_subscription',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'webhook-subscriptions.update',
          ),
          1 => 
          array (
            0 => 'webhook_subscription',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'webhook-subscriptions.destroy',
          ),
          1 => 
          array (
            0 => 'webhook_subscription',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1159 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::phdeCRKBfRpZ3P45',
          ),
          1 => 
          array (
            0 => 'webhook_subscription',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1194 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2SgU0LolhbLw0JIA',
          ),
          1 => 
          array (
            0 => 'delivery',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fuOjIVvrUeRsjpZG',
          ),
          1 => 
          array (
            0 => 'application',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1268 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VE7Wv9kAUotDsyL2',
          ),
          1 => 
          array (
            0 => 'application',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1284 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KlRP1IKuJuEmrYt8',
          ),
          1 => 
          array (
            0 => 'application',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1309 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C2udCm72Lqdi6aK5',
          ),
          1 => 
          array (
            0 => 'award',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1350 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q8B4x0355pfhqJyT',
          ),
          1 => 
          array (
            0 => 'rule',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Xuzob6TZAX9DLgmV',
          ),
          1 => 
          array (
            0 => 'rule',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UvzTwDJb3pB16cLt',
          ),
          1 => 
          array (
            0 => 'rule',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1379 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TmnFrJMfAiPqWJge',
          ),
          1 => 
          array (
            0 => 'approval',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1395 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nDUNvBeHGKzID1Mp',
          ),
          1 => 
          array (
            0 => 'approval',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1429 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IQ2HNbzS6Ei395qH',
          ),
          1 => 
          array (
            0 => 'delegation',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::13aka9H2EJNgUbYl',
          ),
          1 => 
          array (
            0 => 'delegation',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1462 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3NTm1EGukTz7kYlg',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1491 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KaBcMklSJg4T3Ke7',
          ),
          1 => 
          array (
            0 => 'quote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1528 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::01OQcptaoZRXBDeJ',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1544 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fcJRa5GmZ3SDncsB',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h69DIuK5lePP1SLo',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1563 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1fVnlQTrK2JSe5L9',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1583 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mDU3GUGsI4QIipvd',
          ),
          1 => 
          array (
            0 => 'supplier',
            1 => 'record',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::49LPmyLsr7pIhaKn',
          ),
          1 => 
          array (
            0 => 'supplier',
            1 => 'record',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1622 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Cmg0axrXuKOfUw1J',
          ),
          1 => 
          array (
            0 => 'application',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oTPAelzpqZ5dtBGL',
          ),
          1 => 
          array (
            0 => 'application',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1654 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5Gf2UMItT6A4ZAzx',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1670 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sKhFTzJTW59RYjVT',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1688 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S4RlJ2vAXUtKuFe7',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1719 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Lg074bj6qUQSvbx4',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p1lYvvLuY7SaHUIF',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1735 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8o4Pbf1WAu3YYgAg',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1779 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JQdqFe5LiSsLL3Qn',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1813 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cRIZVJNNiWSuyZla',
          ),
          1 => 
          array (
            0 => 'shipment',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1850 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QEqkXWSOsDuG7eA4',
          ),
          1 => 
          array (
            0 => 'savedSearch',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uswMDrSXUShyiskC',
          ),
          1 => 
          array (
            0 => 'savedSearch',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EOeK63STk3Anhy19',
          ),
          1 => 
          array (
            0 => 'savedSearch',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1898 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bELsMW1XzUHFh7TE',
          ),
          1 => 
          array (
            0 => 'digital_twin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1921 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::StVjK8JJougnGXIC',
          ),
          1 => 
          array (
            0 => 'digital_twin',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1965 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g2qMOXkQee5JVg9L',
          ),
          1 => 
          array (
            0 => 'uom',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tcwuzZBweHISZTsD',
          ),
          1 => 
          array (
            0 => 'uom',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1989 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9ErEBfWBW1ZUGm12',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cOG5qrUBlaSix0ds',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2022 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QGa6QackwcrvWMQM',
          ),
          1 => 
          array (
            0 => 'part',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2055 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h9b4lJkCmtAw2xNR',
          ),
          1 => 
          array (
            0 => 'rfp',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yRtoLlS4YAWN25O7',
          ),
          1 => 
          array (
            0 => 'rfp',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2078 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::676sEK64X60lykhg',
          ),
          1 => 
          array (
            0 => 'rfp',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2098 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HjoqE1WHzLlz4Nbk',
          ),
          1 => 
          array (
            0 => 'rfp',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z2oFIgOYcsaZbGIc',
          ),
          1 => 
          array (
            0 => 'rfp',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2125 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tpdKlB0l9504ljnB',
          ),
          1 => 
          array (
            0 => 'rfp',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2139 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::E7162IgFxiKff6MN',
          ),
          1 => 
          array (
            0 => 'rfp',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2164 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D8FnMa9anYN7dRxq',
          ),
          1 => 
          array (
            0 => 'rfp',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2192 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FPeapvZNo2ABJ4io',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2213 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QKg6BRagaBS4FJzr',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VGQgtDvGffBuaaM2',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2234 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ImuZv7IHkrUoKimG',
          ),
          1 => 
          array (
            0 => 'rfq',
            1 => 'line',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UB4Vnz9uAJUqZhPF',
          ),
          1 => 
          array (
            0 => 'rfq',
            1 => 'line',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2262 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gLDgTN0soVoFwDAy',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rc2jFQmCIg4ZH3kV',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2294 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::afvZXKAcrxhFOn9e',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2308 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QtjETmdjleCk4fVJ',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2318 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qSG56Mc253FU4gkD',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2336 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hdETzYniz4AMPeRg',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2354 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XxjJXhE7M0uqxNfd',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2370 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7xtYf6qKDvdbkFM0',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2394 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jLAkai9t7bolPUlv',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2436 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rfqs.clarifications.attachments.download',
          ),
          1 => 
          array (
            0 => 'rfq',
            1 => 'clarification',
            2 => 'attachment',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2453 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1hXYHSKKalLanVxO',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2471 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nfg1fwzLAbtZZAn1',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2488 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PzWUjPvV87AYppM6',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2510 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hZNtPKIy2zHkZgKC',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2533 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::10D9qiMR2Sdf5ZUA',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::neo2TCT085CsIcM1',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2552 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gchrne5dcapFvQNQ',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2572 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Nmk3JhLxGOFBCbdv',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2608 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iMOw3jv8He4n9k0w',
          ),
          1 => 
          array (
            0 => 'rfq',
            1 => 'quote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rm2HLhSutpYeDULR',
          ),
          1 => 
          array (
            0 => 'rfq',
            1 => 'quote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2623 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::35zWL21hXXXr2jIT',
          ),
          1 => 
          array (
            0 => 'rfq',
            1 => 'quote',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2640 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ydcUxUrekgyjjjcZ',
          ),
          1 => 
          array (
            0 => 'rfq',
            1 => 'quote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2650 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Aulb0YuqR8JNNv8N',
          ),
          1 => 
          array (
            0 => 'rfq',
            1 => 'quote',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Qdj0SnTGJXituWTT',
          ),
          1 => 
          array (
            0 => 'rfq',
            1 => 'quote',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2661 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p6Kg0FhLb6wfFubb',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2687 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aPg8XiZnKNMR0E2D',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2697 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PYDKE8frHlfYPyBL',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UxXJWasa8VgCAMVt',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2727 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X9BTN7R2c2xmgo2N',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wdjKvnKkAuy0O2Pz',
          ),
          1 => 
          array (
            0 => 'rfq',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2767 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eOM0Q9inWCD2kCu9',
          ),
          1 => 
          array (
            0 => 'note',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2791 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FzCg2tqs2A34tQ8I',
          ),
          1 => 
          array (
            0 => 'note',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2804 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EGudNWNxeOPf46ln',
          ),
          1 => 
          array (
            0 => 'note',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2828 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iRkpjA0vrz9xVI2I',
          ),
          1 => 
          array (
            0 => 'ncr',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2853 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qC0ugj3bwEGsXjV9',
          ),
          1 => 
          array (
            0 => 'supplier',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2870 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mOJeeoJIkxXJJCNS',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2912 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BNqfMbRHXek2ql2k',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2932 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e6Kde2B5CZ83w40o',
          ),
          1 => 
          array (
            0 => 'rma',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2948 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5DttqMBAQ5rSU9qh',
          ),
          1 => 
          array (
            0 => 'rma',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2991 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O5SBBCEdUwxMrs9N',
          ),
          1 => 
          array (
            0 => 'quote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3011 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fLEHgPrOdAQ21iaS',
          ),
          1 => 
          array (
            0 => 'quote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8OkK9pOODyHwa0yJ',
          ),
          1 => 
          array (
            0 => 'quote',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3030 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jMkCDejHMZklGXFU',
          ),
          1 => 
          array (
            0 => 'quote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3051 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BoFQjzdtadPRmaMV',
          ),
          1 => 
          array (
            0 => 'quote',
            1 => 'quoteItem',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bbGq88bPjnotTze6',
          ),
          1 => 
          array (
            0 => 'quote',
            1 => 'quoteItem',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3073 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z9KtHCYVRzO5p2oE',
          ),
          1 => 
          array (
            0 => 'quote',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3083 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7xXxMhkdPLmpbin6',
          ),
          1 => 
          array (
            0 => 'quote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3114 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RRAn2OpMHhLj3nyC',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3162 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Qgv10KvZ8GzORUyo',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3179 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fNsZjDH5pkNjvfzX',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3198 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gBjDZh2Gos10NmKy',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3223 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ELWIoojlKVr7UmVK',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a8riGXbAhoFou16d',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3243 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nP5F9LYFB5SyYKzj',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3257 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::c7qlynCDOeL81Me3',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3278 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::169DEMkE4f9RbuyT',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3298 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qMc6VuMJ3qpjBcCV',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lKDRDKJpeWwdIw25',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3315 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z8jVUE9E6AevcCIh',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3336 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PdvEyDK1yfi3c4Sd',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
            1 => 'note',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gJeO8B6nxMRvdsKK',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
            1 => 'note',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NC5csQGAOD0RxFfm',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
            1 => 'note',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3346 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8gnubLjaUVpXTzMo',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3383 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'purchase-orders.pdf.download',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
            1 => 'document',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3403 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::obGchxC0E3KqEBF3',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3413 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::crKS42Pq24NdjYuM',
          ),
          1 => 
          array (
            0 => 'purchaseOrder',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3449 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aNW3FaZNm4AzSgPT',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JfyDur84NXyhNm34',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iLpuLKeqofycHpfr',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3467 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b6WfKJewmSWmC1MH',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3499 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::95RO6xp2M6KATujO',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3528 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZEvOwWFCRFXwgWge',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3546 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5Ds5QIhVtKV2ArXF',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3569 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6P6LRuS8w4Uf23cF',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3589 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sfYRycmRFqY7NJrv',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3609 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4sLb7ia9exIgRz12',
          ),
          1 => 
          array (
            0 => 'invoice',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3644 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vf3ZTbzUjnFbjcC3',
          ),
          1 => 
          array (
            0 => 'item',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nFEujvrWNBYr1CSf',
          ),
          1 => 
          array (
            0 => 'item',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3682 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wEzaUTYk31K34Pzl',
          ),
          1 => 
          array (
            0 => 'document',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f00VPJMGwMAWEvXp',
          ),
          1 => 
          array (
            0 => 'document',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3711 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L7DxySyI9WDxH9bT',
          ),
          1 => 
          array (
            0 => 'downloadJob',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3729 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SJBZmdNsJQOurvIm',
          ),
          1 => 
          array (
            0 => 'downloadJob',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3742 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'downloads.file',
          ),
          1 => 
          array (
            0 => 'downloadJob',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3791 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locations.show',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'locations.update',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'locations.destroy',
          ),
          1 => 
          array (
            0 => 'location',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3820 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'systems.show',
          ),
          1 => 
          array (
            0 => 'system',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'systems.update',
          ),
          1 => 
          array (
            0 => 'system',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'systems.destroy',
          ),
          1 => 
          array (
            0 => 'system',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3848 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assets.show',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'assets.update',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'assets.destroy',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3867 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4yofsvdF4S8LF48E',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3879 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qF5FvjTlotf7ETBj',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3910 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h4mDJEP1MwuvkgwN',
          ),
          1 => 
          array (
            0 => 'asset',
            1 => 'procedure',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2IOMXZEIN9HCY1Pr',
          ),
          1 => 
          array (
            0 => 'asset',
            1 => 'procedure',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3928 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A0Ebewi40HhAaKCI',
          ),
          1 => 
          array (
            0 => 'asset',
            1 => 'procedure',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3962 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'procedures.show',
          ),
          1 => 
          array (
            0 => 'procedure',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'procedures.update',
          ),
          1 => 
          array (
            0 => 'procedure',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'procedures.destroy',
          ),
          1 => 
          array (
            0 => 'procedure',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4001 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JDr7bpIzgmU9cXMu',
          ),
          1 => 
          array (
            0 => 'notification',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4045 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wcxmlcvO2AZmzO7n',
          ),
          1 => 
          array (
            0 => 'delivery',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4072 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aiodxjTYM07JDrYW',
          ),
          1 => 
          array (
            0 => 'exportRequest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4090 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'exports.download',
          ),
          1 => 
          array (
            0 => 'exportRequest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4123 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rfq.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4145 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rfq.open',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4170 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'rfq.compare',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4217 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'purchase-orders.supplier.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4234 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'purchase-orders.show',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4276 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'inventory.items.show',
          ),
          1 => 
          array (
            0 => 'itemId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4289 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wZy1WehFSct4kSqA',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4322 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g08qnuEFKMTwBHtr',
            'any' => NULL,
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4342 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@create',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@create',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'throttle:login',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@destroy',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@destroy',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\PasswordResetLinkController@create',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\PasswordResetLinkController@create',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reset-password/{token}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\NewPasswordController@create',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\NewPasswordController@create',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\PasswordResetLinkController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\PasswordResetLinkController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reset-password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\NewPasswordController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\NewPasswordController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\RegisteredUserController@create',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\RegisteredUserController@create',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\RegisteredUserController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\RegisteredUserController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.notice' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'email/verify',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\EmailVerificationPromptController@__invoke',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\EmailVerificationPromptController@__invoke',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.notice',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.verify' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'email/verify/{id}/{hash}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'signed',
          3 => 'throttle:6,1',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\VerifyEmailController@__invoke',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\VerifyEmailController@__invoke',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.verify',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'verification.send' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'email/verification-notification',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'throttle:6,1',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\EmailVerificationNotificationController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\EmailVerificationNotificationController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'verification.send',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/confirm-password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmablePasswordController@show',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmablePasswordController@show',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirmation' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/confirmed-password-status',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmedPasswordStatusController@show',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmedPasswordStatusController@show',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirmation',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirm.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/confirm-password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmablePasswordController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmablePasswordController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirm.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'two-factor-challenge',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticatedSessionController@create',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticatedSessionController@create',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.login.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'two-factor-challenge',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
          2 => 'throttle:two-factor',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticatedSessionController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticatedSessionController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.login.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.enable' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/two-factor-authentication',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticationController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticationController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.enable',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/confirmed-two-factor-authentication',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmedTwoFactorAuthenticationController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmedTwoFactorAuthenticationController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.disable' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'user/two-factor-authentication',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticationController@destroy',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticationController@destroy',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.disable',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.qr-code' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/two-factor-qr-code',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorQrCodeController@show',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorQrCodeController@show',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.qr-code',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.secret-key' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/two-factor-secret-key',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorSecretKeyController@show',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorSecretKeyController@show',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.secret-key',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.recovery-codes' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/two-factor-recovery-codes',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\RecoveryCodeController@index',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\RecoveryCodeController@index',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.recovery-codes',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.regenerate-recovery-codes' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/two-factor-recovery-codes',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\RecoveryCodeController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\RecoveryCodeController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.regenerate-recovery-codes',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xsbgNIsOs5vGEMPR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/health',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\HealthController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Api\\HealthController@__invoke',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::xsbgNIsOs5vGEMPR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6T7plqb00DXNzBKB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/docs/openapi.json',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DocsController@openApi',
        'controller' => 'App\\Http\\Controllers\\Api\\DocsController@openApi',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::6T7plqb00DXNzBKB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YYue2eXxgHj0es1i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/docs/postman.json',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DocsController@postman',
        'controller' => 'App\\Http\\Controllers\\Api\\DocsController@postman',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::YYue2eXxgHj0es1i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gJX0GCEScrxPS9r2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/plans',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PlanCatalogController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\PlanCatalogController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::gJX0GCEScrxPS9r2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eDNloxbduvcP2TPf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company-invitations/{token}/accept',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInvitationController@accept',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInvitationController@accept',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'excluded_middleware' => 
        array (
          0 => 'auth',
          1 => 'Illuminate\\Auth\\Middleware\\Authenticate',
          2 => 'App\\Http\\Middleware\\AuthenticateApiSession',
        ),
        'as' => 'generated::eDNloxbduvcP2TPf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8dP9k7WBJisQw5iN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company/plan-selection',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyPlanController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyPlanController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::8dP9k7WBJisQw5iN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RzYYPDnbnX4W54OB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/billing/checkout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Billing\\PlanCheckoutController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Billing\\PlanCheckoutController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::RzYYPDnbnX4W54OB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qLhqhIRvFSGfKkAn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/billing/portal',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Billing\\BillingPortalController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Billing\\BillingPortalController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::qLhqhIRvFSGfKkAn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6wuv3rzYCGm5t7y8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/billing/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'billing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Billing\\BillingInvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Billing\\BillingInvoiceController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::6wuv3rzYCGm5t7y8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hrfLDYP3VHaNLEfe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/supplier-documents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierDocumentController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierDocumentController@index',
        'namespace' => NULL,
        'prefix' => 'api/me/supplier-documents',
        'where' => 
        array (
        ),
        'as' => 'generated::hrfLDYP3VHaNLEfe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3sg0b8rSuSbxhIen' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/me/supplier-documents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierDocumentController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierDocumentController@store',
        'namespace' => NULL,
        'prefix' => 'api/me/supplier-documents',
        'where' => 
        array (
        ),
        'as' => 'generated::3sg0b8rSuSbxhIen',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8a4Ge3y5EQXaeZlN' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/me/supplier-documents/{document}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierDocumentController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierDocumentController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/me/supplier-documents',
        'where' => 
        array (
        ),
        'as' => 'generated::8a4Ge3y5EQXaeZlN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JkoeLmQXydvKoi8B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UserProfileController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\UserProfileController@show',
        'namespace' => NULL,
        'prefix' => 'api/me',
        'where' => 
        array (
        ),
        'as' => 'generated::JkoeLmQXydvKoi8B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FCW7UagCFtBCguov' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/me/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UserProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\UserProfileController@update',
        'namespace' => NULL,
        'prefix' => 'api/me',
        'where' => 
        array (
        ),
        'as' => 'generated::FCW7UagCFtBCguov',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LfqUQJoOLqc11IMz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UserCompanyController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\UserCompanyController@index',
        'namespace' => NULL,
        'prefix' => 'api/me',
        'where' => 
        array (
        ),
        'as' => 'generated::LfqUQJoOLqc11IMz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A60hGalqCCxRWUdV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/me/companies/switch',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\UserCompanyController@switch',
        'controller' => 'App\\Http\\Controllers\\Api\\UserCompanyController@switch',
        'namespace' => NULL,
        'prefix' => 'api/me',
        'where' => 
        array (
        ),
        'as' => 'generated::A60hGalqCCxRWUdV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HiA6W2zJXb441eMf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/me/supplier-application/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierSelfServiceController@status',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierSelfServiceController@status',
        'namespace' => NULL,
        'prefix' => 'api/me',
        'where' => 
        array (
        ),
        'as' => 'generated::HiA6W2zJXb441eMf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2bEG9nrBskLpfdr5' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/me/supplier/visibility',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierSelfServiceController@updateVisibility',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierSelfServiceController@updateVisibility',
        'namespace' => NULL,
        'prefix' => 'api/me',
        'where' => 
        array (
        ),
        'as' => 'generated::2bEG9nrBskLpfdr5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FRQ5RibkmaIvwQYa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/me/apply-supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierApplicationController@selfApply',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierApplicationController@selfApply',
        'namespace' => NULL,
        'prefix' => 'api/me',
        'where' => 
        array (
        ),
        'as' => 'generated::FRQ5RibkmaIvwQYa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'plans.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/plans',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'plans.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\PlanController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlanController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'plans.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/plans',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'plans.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\PlanController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlanController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'plans.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/plans/{plan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'plans.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\PlanController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlanController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'plans.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/admin/plans/{plan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'plans.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\PlanController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlanController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'plans.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/plans/{plan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'plans.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\PlanController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\PlanController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::be4ExU58KJk6vd8S' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/companies/{company}/assign-plan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CompanyController@assignPlan',
        'controller' => 'App\\Http\\Controllers\\Admin\\CompanyController@assignPlan',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::be4ExU58KJk6vd8S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Wz0NWskNoEPjCH54' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/admin/companies/{company}/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CompanyController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\CompanyController@updateStatus',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Wz0NWskNoEPjCH54',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sj9Izeu6RAnodg3P' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/companies/{company}/feature-flags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CompanyFeatureFlagController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CompanyFeatureFlagController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Sj9Izeu6RAnodg3P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nlF7OzfCKXpXVmeQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/companies/{company}/feature-flags',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CompanyFeatureFlagController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\CompanyFeatureFlagController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::nlF7OzfCKXpXVmeQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H0mUgLE70kLGXEtA' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/admin/companies/{company}/feature-flags/{flag}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CompanyFeatureFlagController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\CompanyFeatureFlagController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::H0mUgLE70kLGXEtA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TjvulbU3n3kOgUBp' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/companies/{company}/feature-flags/{flag}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CompanyFeatureFlagController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\CompanyFeatureFlagController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::TjvulbU3n3kOgUBp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::U1dPEgZ2mkAgPwVB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::U1dPEgZ2mkAgPwVB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rBVSnmbj6G3aYnez' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/companies/{company}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@approve',
        'controller' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@approve',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::rBVSnmbj6G3aYnez',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::F3xxzc6BAuZxjhOU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/companies/{company}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@reject',
        'controller' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@reject',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::F3xxzc6BAuZxjhOU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'email-templates.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/email-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'email-templates.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'email-templates.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/email-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'email-templates.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'email-templates.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/email-templates/{email_template}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'email-templates.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'email-templates.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/admin/email-templates/{email_template}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'email-templates.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'email-templates.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/email-templates/{email_template}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'email-templates.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z8VkqBVQm30QubyZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/email-templates/{email_template}/preview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@preview',
        'controller' => 'App\\Http\\Controllers\\Admin\\EmailTemplateController@preview',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::z8VkqBVQm30QubyZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'digital-twin-categories.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/digital-twin-categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'digital-twin-categories.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinCategoryController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinCategoryController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'digital-twin-categories.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/digital-twin-categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'digital-twin-categories.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinCategoryController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinCategoryController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'digital-twin-categories.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/digital-twin-categories/{digital_twin_category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'digital-twin-categories.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinCategoryController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinCategoryController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'digital-twin-categories.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/admin/digital-twin-categories/{digital_twin_category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'digital-twin-categories.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinCategoryController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinCategoryController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'digital-twin-categories.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/digital-twin-categories/{digital_twin_category}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'digital-twin-categories.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinCategoryController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinCategoryController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'digital-twins.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/digital-twins',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'digital-twins.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'digital-twins.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/digital-twins',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'digital-twins.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'digital-twins.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/digital-twins/{digital_twin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'digital-twins.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'digital-twins.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/admin/digital-twins/{digital_twin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'digital-twins.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'digital-twins.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/digital-twins/{digital_twin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'digital-twins.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PuC9MBUmoRetbmFH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/digital-twins/{digital_twin}/publish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@publish',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@publish',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::PuC9MBUmoRetbmFH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5U6vFpbktgTMXKDz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/digital-twins/{digital_twin}/archive',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@archive',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinController@archive',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::5U6vFpbktgTMXKDz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jmhDw7HtW0lFF0Ta' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/digital-twins/{digital_twin}/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinAssetController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinAssetController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::jmhDw7HtW0lFF0Ta',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YPeSOCZRCB0NWQwD' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/digital-twins/{digital_twin}/assets/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinAssetController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinAssetController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::YPeSOCZRCB0NWQwD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SUqWMKgczQk0280Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/digital-twins/{digital_twin}/audit-events',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DigitalTwinAuditEventController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DigitalTwinAuditEventController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::SUqWMKgczQk0280Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::82oM1vjd0e6Cqffm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/api-keys',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ApiKeyController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ApiKeyController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::82oM1vjd0e6Cqffm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::72zXWpCNASIXaBay' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/api-keys',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ApiKeyController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ApiKeyController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::72zXWpCNASIXaBay',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wuxL9Y6F2ykowrRK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/api-keys/{key}/rotate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ApiKeyController@rotate',
        'controller' => 'App\\Http\\Controllers\\Admin\\ApiKeyController@rotate',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::wuxL9Y6F2ykowrRK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Uqoyvgrgjqd24sLL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/api-keys/{key}/toggle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ApiKeyController@toggle',
        'controller' => 'App\\Http\\Controllers\\Admin\\ApiKeyController@toggle',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Uqoyvgrgjqd24sLL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fPVZyzDR0vOCdvkr' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/api-keys/{key}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ApiKeyController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\ApiKeyController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::fPVZyzDR0vOCdvkr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rate-limits.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/rate-limits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'rate-limits.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\RateLimitController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\RateLimitController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rate-limits.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/rate-limits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'rate-limits.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\RateLimitController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\RateLimitController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rate-limits.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/rate-limits/{rate_limit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'rate-limits.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\RateLimitController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\RateLimitController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rate-limits.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/admin/rate-limits/{rate_limit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'rate-limits.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\RateLimitController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\RateLimitController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rate-limits.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/rate-limits/{rate_limit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'rate-limits.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\RateLimitController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\RateLimitController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'webhook-subscriptions.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/webhook-subscriptions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'webhook-subscriptions.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'webhook-subscriptions.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/webhook-subscriptions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'webhook-subscriptions.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@store',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'webhook-subscriptions.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/webhook-subscriptions/{webhook_subscription}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'webhook-subscriptions.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'webhook-subscriptions.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/admin/webhook-subscriptions/{webhook_subscription}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'webhook-subscriptions.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'webhook-subscriptions.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/webhook-subscriptions/{webhook_subscription}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'as' => 'webhook-subscriptions.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::phdeCRKBfRpZ3P45' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/webhook-subscriptions/{webhook_subscription}/test',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@test',
        'controller' => 'App\\Http\\Controllers\\Admin\\WebhookSubscriptionController@test',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::phdeCRKBfRpZ3P45',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5GWxCmarAql1Ep64' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/webhook-deliveries',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\WebhookDeliveryController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\WebhookDeliveryController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::5GWxCmarAql1Ep64',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2SgU0LolhbLw0JIA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/webhook-deliveries/{delivery}/retry',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\WebhookDeliveryController@retry',
        'controller' => 'App\\Http\\Controllers\\Admin\\WebhookDeliveryController@retry',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::2SgU0LolhbLw0JIA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cqo0OVkvnDfgmQI2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/health',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\HealthController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\HealthController@show',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::cqo0OVkvnDfgmQI2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LkqMbQHpdBi10RqQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleTemplateController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleTemplateController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::LkqMbQHpdBi10RqQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oV8gm9UvAq87VXzD' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/admin/roles/{roleTemplate}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleTemplateController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleTemplateController@update',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::oV8gm9UvAq87VXzD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VWazyKifqIBG8Lu7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/audit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AuditLogController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\AuditLogController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::VWazyKifqIBG8Lu7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TBwcdORZOrXIvC3S' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/company-approvals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::TBwcdORZOrXIvC3S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7SwylZH6THzvQTvY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/company-approvals/{company}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@approve',
        'controller' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@approve',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::7SwylZH6THzvQTvY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IcMwfvQNGzlYMx0Y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/company-approvals/{company}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@reject',
        'controller' => 'App\\Http\\Controllers\\Api\\Admin\\CompanyApprovalController@reject',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::IcMwfvQNGzlYMx0Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::o8B3CMPpFspvPLzZ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/analytics/overview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminAnalyticsController@overview',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminAnalyticsController@overview',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::o8B3CMPpFspvPLzZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WiwyH3cYbSXClYaA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/supplier-applications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Admin\\SupplierApplicationReviewController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Admin\\SupplierApplicationReviewController@index',
        'namespace' => NULL,
        'prefix' => 'api/admin/supplier-applications',
        'where' => 
        array (
        ),
        'as' => 'generated::WiwyH3cYbSXClYaA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fuOjIVvrUeRsjpZG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/supplier-applications/{application}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Admin\\SupplierApplicationReviewController@approve',
        'controller' => 'App\\Http\\Controllers\\Api\\Admin\\SupplierApplicationReviewController@approve',
        'namespace' => NULL,
        'prefix' => 'api/admin/supplier-applications',
        'where' => 
        array (
        ),
        'as' => 'generated::fuOjIVvrUeRsjpZG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KlRP1IKuJuEmrYt8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/supplier-applications/{application}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Admin\\SupplierApplicationReviewController@reject',
        'controller' => 'App\\Http\\Controllers\\Api\\Admin\\SupplierApplicationReviewController@reject',
        'namespace' => NULL,
        'prefix' => 'api/admin/supplier-applications',
        'where' => 
        array (
        ),
        'as' => 'generated::KlRP1IKuJuEmrYt8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VE7Wv9kAUotDsyL2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/supplier-applications/{application}/audit-logs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'admin.guard',
          3 => 'App\\Http\\Middleware\\BypassCompanyContext',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Admin\\SupplierApplicationReviewController@auditLogs',
        'controller' => 'App\\Http\\Controllers\\Api\\Admin\\SupplierApplicationReviewController@auditLogs',
        'namespace' => NULL,
        'prefix' => 'api/admin/supplier-applications',
        'where' => 
        array (
        ),
        'as' => 'generated::VE7Wv9kAUotDsyL2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3NTm1EGukTz7kYlg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/files/cad/{rfq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FileController@cad',
        'controller' => 'App\\Http\\Controllers\\Api\\FileController@cad',
        'namespace' => NULL,
        'prefix' => 'api/files',
        'where' => 
        array (
        ),
        'as' => 'generated::3NTm1EGukTz7kYlg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KaBcMklSJg4T3Ke7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/files/attachments/{quote}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FileController@attachment',
        'controller' => 'App\\Http\\Controllers\\Api\\FileController@attachment',
        'namespace' => NULL,
        'prefix' => 'api/files',
        'where' => 
        array (
        ),
        'as' => 'generated::KaBcMklSJg4T3Ke7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ckOfRiCw4gVHltdO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierController@index',
        'namespace' => NULL,
        'prefix' => 'api/suppliers',
        'where' => 
        array (
        ),
        'as' => 'generated::ckOfRiCw4gVHltdO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::01OQcptaoZRXBDeJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/suppliers/{supplier}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierController@show',
        'namespace' => NULL,
        'prefix' => 'api/suppliers',
        'where' => 
        array (
        ),
        'as' => 'generated::01OQcptaoZRXBDeJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fcJRa5GmZ3SDncsB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/suppliers/{supplier}/esg',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.risk.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierEsgController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierEsgController@index',
        'namespace' => NULL,
        'prefix' => 'api/suppliers/{supplier}/esg',
        'where' => 
        array (
        ),
        'as' => 'generated::fcJRa5GmZ3SDncsB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h69DIuK5lePP1SLo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/suppliers/{supplier}/esg',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.risk.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierEsgController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierEsgController@store',
        'namespace' => NULL,
        'prefix' => 'api/suppliers/{supplier}/esg',
        'where' => 
        array (
        ),
        'as' => 'generated::h69DIuK5lePP1SLo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1fVnlQTrK2JSe5L9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/suppliers/{supplier}/esg/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.risk.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierEsgController@export',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierEsgController@export',
        'namespace' => NULL,
        'prefix' => 'api/suppliers/{supplier}/esg',
        'where' => 
        array (
        ),
        'as' => 'generated::1fVnlQTrK2JSe5L9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mDU3GUGsI4QIipvd' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/suppliers/{supplier}/esg/{record}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.risk.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierEsgController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierEsgController@update',
        'namespace' => NULL,
        'prefix' => 'api/suppliers/{supplier}/esg',
        'where' => 
        array (
        ),
        'as' => 'generated::mDU3GUGsI4QIipvd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::49LPmyLsr7pIhaKn' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/suppliers/{supplier}/esg/{record}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.risk.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierEsgController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierEsgController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/suppliers/{supplier}/esg',
        'where' => 
        array (
        ),
        'as' => 'generated::49LPmyLsr7pIhaKn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lFJMKl9nwq1E97Yy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/supplier-applications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierApplicationController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierApplicationController@index',
        'namespace' => NULL,
        'prefix' => 'api/supplier-applications',
        'where' => 
        array (
        ),
        'as' => 'generated::lFJMKl9nwq1E97Yy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SBcYl93w0lwmx65z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/supplier-applications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierApplicationController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierApplicationController@store',
        'namespace' => NULL,
        'prefix' => 'api/supplier-applications',
        'where' => 
        array (
        ),
        'as' => 'generated::SBcYl93w0lwmx65z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Cmg0axrXuKOfUw1J' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/supplier-applications/{application}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierApplicationController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierApplicationController@show',
        'namespace' => NULL,
        'prefix' => 'api/supplier-applications',
        'where' => 
        array (
        ),
        'as' => 'generated::Cmg0axrXuKOfUw1J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oTPAelzpqZ5dtBGL' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/supplier-applications/{application}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierApplicationController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierApplicationController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/supplier-applications',
        'where' => 
        array (
        ),
        'as' => 'generated::oTPAelzpqZ5dtBGL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4UMvZUVjK3C0TbmW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/library/digital-twins',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
          4 => 'buyer_access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Library\\DigitalTwinController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Library\\DigitalTwinController@index',
        'namespace' => NULL,
        'prefix' => 'api/library',
        'where' => 
        array (
        ),
        'as' => 'generated::4UMvZUVjK3C0TbmW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bELsMW1XzUHFh7TE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/library/digital-twins/{digital_twin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
          4 => 'buyer_access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Library\\DigitalTwinController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Library\\DigitalTwinController@show',
        'namespace' => NULL,
        'prefix' => 'api/library',
        'where' => 
        array (
        ),
        'as' => 'generated::bELsMW1XzUHFh7TE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::StVjK8JJougnGXIC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/library/digital-twins/{digital_twin}/use-for-rfq',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
          4 => 'buyer_access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Library\\DigitalTwinController@useForRfq',
        'controller' => 'App\\Http\\Controllers\\Api\\Library\\DigitalTwinController@useForRfq',
        'namespace' => NULL,
        'prefix' => 'api/library',
        'where' => 
        array (
        ),
        'as' => 'generated::StVjK8JJougnGXIC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Vh2AExWFuztH53Vj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfps',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'rfp_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfpController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RfpController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfps',
        'where' => 
        array (
        ),
        'as' => 'generated::Vh2AExWFuztH53Vj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nGr81Wo3XG1Q5ayV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfps',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'rfp_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfpController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\RfpController@store',
        'namespace' => NULL,
        'prefix' => 'api/rfps',
        'where' => 
        array (
        ),
        'as' => 'generated::nGr81Wo3XG1Q5ayV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h9b4lJkCmtAw2xNR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfps/{rfp}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'rfp_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfpController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\RfpController@show',
        'namespace' => NULL,
        'prefix' => 'api/rfps',
        'where' => 
        array (
        ),
        'as' => 'generated::h9b4lJkCmtAw2xNR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yRtoLlS4YAWN25O7' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/rfps/{rfp}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'rfp_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfpController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\RfpController@update',
        'namespace' => NULL,
        'prefix' => 'api/rfps',
        'where' => 
        array (
        ),
        'as' => 'generated::yRtoLlS4YAWN25O7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::676sEK64X60lykhg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfps/{rfp}/publish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'rfp_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfpController@publish',
        'controller' => 'App\\Http\\Controllers\\Api\\RfpController@publish',
        'namespace' => NULL,
        'prefix' => 'api/rfps',
        'where' => 
        array (
        ),
        'as' => 'generated::676sEK64X60lykhg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tpdKlB0l9504ljnB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfps/{rfp}/move-to-review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'rfp_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfpController@moveToReview',
        'controller' => 'App\\Http\\Controllers\\Api\\RfpController@moveToReview',
        'namespace' => NULL,
        'prefix' => 'api/rfps',
        'where' => 
        array (
        ),
        'as' => 'generated::tpdKlB0l9504ljnB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::E7162IgFxiKff6MN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfps/{rfp}/award',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'rfp_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfpController@award',
        'controller' => 'App\\Http\\Controllers\\Api\\RfpController@award',
        'namespace' => NULL,
        'prefix' => 'api/rfps',
        'where' => 
        array (
        ),
        'as' => 'generated::E7162IgFxiKff6MN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D8FnMa9anYN7dRxq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfps/{rfp}/close-no-award',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'rfp_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfpController@closeWithoutAward',
        'controller' => 'App\\Http\\Controllers\\Api\\RfpController@closeWithoutAward',
        'namespace' => NULL,
        'prefix' => 'api/rfps',
        'where' => 
        array (
        ),
        'as' => 'generated::D8FnMa9anYN7dRxq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HjoqE1WHzLlz4Nbk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfps/{rfp}/proposals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'rfp_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfpProposalController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RfpProposalController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfps',
        'where' => 
        array (
        ),
        'as' => 'generated::HjoqE1WHzLlz4Nbk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Z2oFIgOYcsaZbGIc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfps/{rfp}/proposals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.subscribed',
          2 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfpProposalController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\RfpProposalController@store',
        'namespace' => NULL,
        'prefix' => 'api/rfps',
        'where' => 
        array (
        ),
        'as' => 'generated::Z2oFIgOYcsaZbGIc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0bxeYwYuNOsR3eUI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::0bxeYwYuNOsR3eUI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LO3UZxkwXgPfF0qw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQController@store',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::LO3UZxkwXgPfF0qw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FPeapvZNo2ABJ4io' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQController@show',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::FPeapvZNo2ABJ4io',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QKg6BRagaBS4FJzr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}/lines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqLineController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqLineController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::QKg6BRagaBS4FJzr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VGQgtDvGffBuaaM2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/lines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqLineController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqLineController@store',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::VGQgtDvGffBuaaM2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ImuZv7IHkrUoKimG' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/rfqs/{rfq}/lines/{line}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqLineController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqLineController@update',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::ImuZv7IHkrUoKimG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UB4Vnz9uAJUqZhPF' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/rfqs/{rfq}/lines/{line}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqLineController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqLineController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::UB4Vnz9uAJUqZhPF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gLDgTN0soVoFwDAy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}/attachments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqAttachmentController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqAttachmentController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::gLDgTN0soVoFwDAy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rc2jFQmCIg4ZH3kV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/attachments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqAttachmentController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqAttachmentController@store',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::rc2jFQmCIg4ZH3kV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hdETzYniz4AMPeRg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/publish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQController@publish',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQController@publish',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::hdETzYniz4AMPeRg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XxjJXhE7M0uqxNfd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQController@cancel',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQController@cancel',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::XxjJXhE7M0uqxNfd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7xtYf6qKDvdbkFM0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/close',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQController@close',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQController@close',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::7xtYf6qKDvdbkFM0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hZNtPKIy2zHkZgKC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}/timeline',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqTimelineController@__invoke',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqTimelineController',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::hZNtPKIy2zHkZgKC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PYDKE8frHlfYPyBL' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/rfqs/{rfq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQController@update',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::PYDKE8frHlfYPyBL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UxXJWasa8VgCAMVt' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/rfqs/{rfq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::UxXJWasa8VgCAMVt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::10D9qiMR2Sdf5ZUA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}/invitations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqInvitationController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqInvitationController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::10D9qiMR2Sdf5ZUA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::neo2TCT085CsIcM1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/invitations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqInvitationController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqInvitationController@store',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::neo2TCT085CsIcM1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Gchrne5dcapFvQNQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::Gchrne5dcapFvQNQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Nmk3JhLxGOFBCbdv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}/quotes/compare',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteController@compare',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteController@compare',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::Nmk3JhLxGOFBCbdv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::afvZXKAcrxhFOn9e' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}/award-candidates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqAwardCandidateController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqAwardCandidateController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::afvZXKAcrxhFOn9e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iMOw3jv8He4n9k0w' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}/quotes/{quote}/revisions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteRevisionController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteRevisionController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/quotes/{quote}',
        'where' => 
        array (
        ),
        'excluded_middleware' => 
        array (
          0 => 'ensure.supplier.approved',
        ),
        'as' => 'generated::iMOw3jv8He4n9k0w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rm2HLhSutpYeDULR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/quotes/{quote}/revisions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteRevisionController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteRevisionController@store',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/quotes/{quote}',
        'where' => 
        array (
        ),
        'as' => 'generated::rm2HLhSutpYeDULR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qSG56Mc253FU4gkD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/award',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AwardController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AwardController@store',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::qSG56Mc253FU4gkD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QtjETmdjleCk4fVJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/award-lines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqAwardController@awardLines',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqAwardController@awardLines',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::QtjETmdjleCk4fVJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aPg8XiZnKNMR0E2D' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/extend-deadline',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQController@extendDeadline',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQController@extendDeadline',
        'namespace' => NULL,
        'prefix' => 'api/rfqs',
        'where' => 
        array (
        ),
        'as' => 'generated::aPg8XiZnKNMR0E2D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jLAkai9t7bolPUlv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}/clarifications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqClarificationController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqClarificationController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/clarifications',
        'where' => 
        array (
        ),
        'as' => 'generated::jLAkai9t7bolPUlv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rfqs.clarifications.attachments.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfqs/{rfq}/clarifications/{clarification}/attachments/{attachment}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqClarificationController@downloadAttachment',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqClarificationController@downloadAttachment',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/clarifications',
        'where' => 
        array (
        ),
        'as' => 'rfqs.clarifications.attachments.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1hXYHSKKalLanVxO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/clarifications/question',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqClarificationController@storeQuestion',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqClarificationController@storeQuestion',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/clarifications',
        'where' => 
        array (
        ),
        'as' => 'generated::1hXYHSKKalLanVxO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nfg1fwzLAbtZZAn1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/clarifications/answer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:read',
          5 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqClarificationController@storeAnswer',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqClarificationController@storeAnswer',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/clarifications',
        'where' => 
        array (
        ),
        'as' => 'generated::nfg1fwzLAbtZZAn1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PzWUjPvV87AYppM6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/clarifications/amendment',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded:strict',
          2 => 'ensure.company.approved',
          3 => 'ensure.subscribed',
          4 => 'sourcing_access:read',
          5 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RfqClarificationController@storeAmendment',
        'controller' => 'App\\Http\\Controllers\\Api\\RfqClarificationController@storeAmendment',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/clarifications',
        'where' => 
        array (
        ),
        'as' => 'generated::PzWUjPvV87AYppM6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::X9BTN7R2c2xmgo2N' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rfq-quotes/{rfq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQQuoteController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQQuoteController@index',
        'namespace' => NULL,
        'prefix' => 'api/rfq-quotes',
        'where' => 
        array (
        ),
        'as' => 'generated::X9BTN7R2c2xmgo2N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wdjKvnKkAuy0O2Pz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfq-quotes/{rfq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RFQQuoteController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\RFQQuoteController@store',
        'namespace' => NULL,
        'prefix' => 'api/rfq-quotes',
        'where' => 
        array (
        ),
        'as' => 'generated::wdjKvnKkAuy0O2Pz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fPN44IrSrUnA8PO3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/awards',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AwardLineController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\AwardLineController@store',
        'namespace' => NULL,
        'prefix' => 'api/awards',
        'where' => 
        array (
        ),
        'as' => 'generated::fPN44IrSrUnA8PO3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C2udCm72Lqdi6aK5' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/awards/{award}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AwardLineController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\AwardLineController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/awards',
        'where' => 
        array (
        ),
        'as' => 'generated::C2udCm72Lqdi6aK5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KUB7HG9PtFNyLQlW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.subscribed',
          2 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteController@storeStandalone',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteController@storeStandalone',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::KUB7HG9PtFNyLQlW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::O5SBBCEdUwxMrs9N' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/quotes/{quote}/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.subscribed',
          2 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteController@submitStandalone',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteController@submitStandalone',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::O5SBBCEdUwxMrs9N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fLEHgPrOdAQ21iaS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/quotes/{quote}/shortlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded:strict',
          3 => 'ensure.company.approved',
          4 => 'ensure.subscribed',
          5 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteShortlistController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteShortlistController@store',
        'namespace' => NULL,
        'prefix' => 'api/quotes',
        'where' => 
        array (
        ),
        'as' => 'generated::fLEHgPrOdAQ21iaS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8OkK9pOODyHwa0yJ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/quotes/{quote}/shortlist',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded:strict',
          3 => 'ensure.company.approved',
          4 => 'ensure.subscribed',
          5 => 'sourcing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteShortlistController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteShortlistController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/quotes',
        'where' => 
        array (
        ),
        'as' => 'generated::8OkK9pOODyHwa0yJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p6Kg0FhLb6wfFubb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.subscribed',
          2 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteController@store',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/quotes',
        'where' => 
        array (
        ),
        'as' => 'generated::p6Kg0FhLb6wfFubb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Aulb0YuqR8JNNv8N' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/rfqs/{rfq}/quotes/{quote}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.subscribed',
          2 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteController@submit',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteController@submit',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/quotes',
        'where' => 
        array (
        ),
        'as' => 'generated::Aulb0YuqR8JNNv8N',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::35zWL21hXXXr2jIT' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/rfqs/{rfq}/quotes/{quote}/draft',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.subscribed',
          2 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteController@updateDraft',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteController@updateDraft',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/quotes',
        'where' => 
        array (
        ),
        'as' => 'generated::35zWL21hXXXr2jIT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Qdj0SnTGJXituWTT' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/rfqs/{rfq}/quotes/{quote}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.subscribed',
          2 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteController@withdraw',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteController@withdraw',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/quotes',
        'where' => 
        array (
        ),
        'as' => 'generated::Qdj0SnTGJXituWTT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ydcUxUrekgyjjjcZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rfqs/{rfq}/quotes/{quote}/withdraw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteController@withdraw',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteController@withdraw',
        'namespace' => NULL,
        'prefix' => 'api/rfqs/{rfq}/quotes',
        'where' => 
        array (
        ),
        'as' => 'generated::ydcUxUrekgyjjjcZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::whL1TzFhBZk5HNoa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pos/from-awards',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'orders_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@createFromAwards',
        'controller' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@createFromAwards',
        'namespace' => NULL,
        'prefix' => 'api/pos',
        'where' => 
        array (
        ),
        'as' => 'generated::whL1TzFhBZk5HNoa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4BBj9CL6rZureXYT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/buyer/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
          4 => 'orders_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Orders\\BuyerOrderController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Orders\\BuyerOrderController@index',
        'namespace' => NULL,
        'prefix' => 'api/buyer/orders',
        'where' => 
        array (
        ),
        'as' => 'generated::4BBj9CL6rZureXYT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RRAn2OpMHhLj3nyC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/buyer/orders/{order}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
          4 => 'orders_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Orders\\BuyerOrderController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Orders\\BuyerOrderController@show',
        'namespace' => NULL,
        'prefix' => 'api/buyer/orders',
        'where' => 
        array (
        ),
        'as' => 'generated::RRAn2OpMHhLj3nyC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XpBJKYZq6xJdPUzk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/supplier/dashboard/metrics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierDashboardController@metrics',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierDashboardController@metrics',
        'namespace' => NULL,
        'prefix' => 'api/supplier/dashboard',
        'where' => 
        array (
        ),
        'as' => 'generated::XpBJKYZq6xJdPUzk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7EncuICUF8faZHAH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/supplier/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
          3 => 'orders_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Orders\\SupplierOrderController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Orders\\SupplierOrderController@index',
        'namespace' => NULL,
        'prefix' => 'api/supplier/orders',
        'where' => 
        array (
        ),
        'as' => 'generated::7EncuICUF8faZHAH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5Gf2UMItT6A4ZAzx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/supplier/orders/{order}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
          3 => 'orders_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Orders\\SupplierOrderController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Orders\\SupplierOrderController@show',
        'namespace' => NULL,
        'prefix' => 'api/supplier/orders',
        'where' => 
        array (
        ),
        'as' => 'generated::5Gf2UMItT6A4ZAzx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sKhFTzJTW59RYjVT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/supplier/orders/{order}/ack',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
          3 => 'orders_access:read',
          4 => 'orders_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Orders\\SupplierOrderController@acknowledge',
        'controller' => 'App\\Http\\Controllers\\Api\\Orders\\SupplierOrderController@acknowledge',
        'namespace' => NULL,
        'prefix' => 'api/supplier/orders',
        'where' => 
        array (
        ),
        'as' => 'generated::sKhFTzJTW59RYjVT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::S4RlJ2vAXUtKuFe7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/supplier/orders/{order}/shipments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
          3 => 'orders_access:read',
          4 => 'orders_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Orders\\SupplierShipmentController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Orders\\SupplierShipmentController@store',
        'namespace' => NULL,
        'prefix' => 'api/supplier/orders',
        'where' => 
        array (
        ),
        'as' => 'generated::S4RlJ2vAXUtKuFe7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7QkDu4Gk8qkrDDvh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/supplier/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
          3 => 'orders_access:read',
          4 => 'supplier_invoicing_access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Supplier\\SupplierInvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Supplier\\SupplierInvoiceController@index',
        'namespace' => NULL,
        'prefix' => 'api/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::7QkDu4Gk8qkrDDvh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Lg074bj6qUQSvbx4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/supplier/invoices/{invoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
          3 => 'orders_access:read',
          4 => 'supplier_invoicing_access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Supplier\\SupplierInvoiceController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Supplier\\SupplierInvoiceController@show',
        'namespace' => NULL,
        'prefix' => 'api/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::Lg074bj6qUQSvbx4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p1lYvvLuY7SaHUIF' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/supplier/invoices/{invoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
          3 => 'orders_access:read',
          4 => 'supplier_invoicing_access',
          5 => 'supplier_invoicing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Supplier\\SupplierInvoiceController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Supplier\\SupplierInvoiceController@update',
        'namespace' => NULL,
        'prefix' => 'api/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::p1lYvvLuY7SaHUIF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8o4Pbf1WAu3YYgAg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/supplier/invoices/{invoice}/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
          3 => 'orders_access:read',
          4 => 'supplier_invoicing_access',
          5 => 'supplier_invoicing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Supplier\\SupplierInvoiceController@submit',
        'controller' => 'App\\Http\\Controllers\\Api\\Supplier\\SupplierInvoiceController@submit',
        'namespace' => NULL,
        'prefix' => 'api/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::8o4Pbf1WAu3YYgAg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JQdqFe5LiSsLL3Qn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/supplier/purchase-orders/{purchaseOrder}/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
          3 => 'orders_access:read',
          4 => 'supplier_invoicing_access',
          5 => 'orders_access:write',
          6 => 'supplier_invoicing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Supplier\\SupplierInvoiceController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Supplier\\SupplierInvoiceController@store',
        'namespace' => NULL,
        'prefix' => 'api/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::JQdqFe5LiSsLL3Qn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cRIZVJNNiWSuyZla' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/supplier/shipments/{shipment}/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
          3 => 'orders_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Orders\\SupplierShipmentController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\Api\\Orders\\SupplierShipmentController@updateStatus',
        'namespace' => NULL,
        'prefix' => 'api/supplier/shipments',
        'where' => 
        array (
        ),
        'as' => 'generated::cRIZVJNNiWSuyZla',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nW2Y45TomFn8R4D3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteInboxController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteInboxController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::nW2Y45TomFn8R4D3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7xXxMhkdPLmpbin6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/quotes/{quote}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::7xXxMhkdPLmpbin6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jMkCDejHMZklGXFU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/quotes/{quote}/lines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteLineController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteLineController@store',
        'namespace' => NULL,
        'prefix' => 'api/quotes/{quote}',
        'where' => 
        array (
        ),
        'as' => 'generated::jMkCDejHMZklGXFU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BoFQjzdtadPRmaMV' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/quotes/{quote}/lines/{quoteItem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteLineController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteLineController@update',
        'namespace' => NULL,
        'prefix' => 'api/quotes/{quote}',
        'where' => 
        array (
        ),
        'as' => 'generated::BoFQjzdtadPRmaMV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bbGq88bPjnotTze6' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/quotes/{quote}/lines/{quoteItem}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteLineController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteLineController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/quotes/{quote}',
        'where' => 
        array (
        ),
        'as' => 'generated::bbGq88bPjnotTze6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jpGMLz5PIGHV452h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/supplier/quotes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierQuoteController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierQuoteController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::jpGMLz5PIGHV452h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::No8mWZ4oL2r7zdd7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/supplier/rfqs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.supplier.approved',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierRfqInboxController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierRfqInboxController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::No8mWZ4oL2r7zdd7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H1EKYm5fx2lbJixm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'orders_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@index',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::H1EKYm5fx2lbJixm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Qgv10KvZ8GzORUyo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/send',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'ensure.company.approved',
          5 => 'ensure.subscribed',
          6 => 'orders_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@send',
        'controller' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@send',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::Qgv10KvZ8GzORUyo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gBjDZh2Gos10NmKy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'ensure.company.approved',
          5 => 'ensure.subscribed',
          6 => 'orders_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@cancel',
        'controller' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@cancel',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::gBjDZh2Gos10NmKy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nP5F9LYFB5SyYKzj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'ensure.company.approved',
          5 => 'ensure.subscribed',
          6 => 'orders_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@export',
        'controller' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@export',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::nP5F9LYFB5SyYKzj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::169DEMkE4f9RbuyT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/acknowledge',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.supplier.approved',
          4 => 'orders_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@acknowledge',
        'controller' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@acknowledge',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::169DEMkE4f9RbuyT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ELWIoojlKVr7UmVK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/change-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PoChangeOrderController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\PoChangeOrderController@index',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::ELWIoojlKVr7UmVK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a8riGXbAhoFou16d' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/change-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'ensure.company.approved',
          5 => 'ensure.subscribed',
          6 => 'orders_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PoChangeOrderController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\PoChangeOrderController@store',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::a8riGXbAhoFou16d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qMc6VuMJ3qpjBcCV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'billing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@index',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::qMc6VuMJ3qpjBcCV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lKDRDKJpeWwdIw25' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'ensure.subscribed',
          5 => 'billing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@store',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::lKDRDKJpeWwdIw25',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z8jVUE9E6AevcCIh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/grns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@index',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders/{purchaseOrder}/grns',
        'where' => 
        array (
        ),
        'as' => 'generated::z8jVUE9E6AevcCIh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PdvEyDK1yfi3c4Sd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/grns/{note}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@show',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders/{purchaseOrder}/grns',
        'where' => 
        array (
        ),
        'as' => 'generated::PdvEyDK1yfi3c4Sd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8gnubLjaUVpXTzMo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/grns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'ensure.inventory.access',
          5 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@store',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders/{purchaseOrder}/grns',
        'where' => 
        array (
        ),
        'as' => 'generated::8gnubLjaUVpXTzMo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gJeO8B6nxMRvdsKK' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/grns/{note}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'ensure.inventory.access',
          5 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@update',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders/{purchaseOrder}/grns',
        'where' => 
        array (
        ),
        'as' => 'generated::gJeO8B6nxMRvdsKK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NC5csQGAOD0RxFfm' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/grns/{note}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'ensure.inventory.access',
          5 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders/{purchaseOrder}/grns',
        'where' => 
        array (
        ),
        'as' => 'generated::NC5csQGAOD0RxFfm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'purchase-orders.pdf.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/documents/{document}/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'signed',
          4 => 'orders_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@downloadPdf',
        'controller' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@downloadPdf',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'purchase-orders.pdf.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::c7qlynCDOeL81Me3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/events',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'orders_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@events',
        'controller' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@events',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::c7qlynCDOeL81Me3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fNsZjDH5pkNjvfzX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/shipments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'ensure.company.onboarded',
          4 => 'orders_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PurchaseOrderShipmentController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\PurchaseOrderShipmentController@index',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::fNsZjDH5pkNjvfzX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::crKS42Pq24NdjYuM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'auth',
          3 => 'orders_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\PurchaseOrderController@show',
        'namespace' => NULL,
        'prefix' => 'api/purchase-orders',
        'where' => 
        array (
        ),
        'as' => 'generated::crKS42Pq24NdjYuM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZqIa0hW565sQUo1T' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/receiving/grns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@companyIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@companyIndex',
        'namespace' => NULL,
        'prefix' => 'api/receiving/grns',
        'where' => 
        array (
        ),
        'as' => 'generated::ZqIa0hW565sQUo1T',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eOM0Q9inWCD2kCu9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/receiving/grns/{note}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@companyShow',
        'controller' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@companyShow',
        'namespace' => NULL,
        'prefix' => 'api/receiving/grns',
        'where' => 
        array (
        ),
        'as' => 'generated::eOM0Q9inWCD2kCu9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zJQvxrxrvwvEKr96' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/receiving/grns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
          4 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@companyStore',
        'controller' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@companyStore',
        'namespace' => NULL,
        'prefix' => 'api/receiving/grns',
        'where' => 
        array (
        ),
        'as' => 'generated::zJQvxrxrvwvEKr96',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FzCg2tqs2A34tQ8I' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/receiving/grns/{note}/attachments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
          4 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@companyAttachFile',
        'controller' => 'App\\Http\\Controllers\\Api\\GoodsReceiptNoteController@companyAttachFile',
        'namespace' => NULL,
        'prefix' => 'api/receiving/grns',
        'where' => 
        array (
        ),
        'as' => 'generated::FzCg2tqs2A34tQ8I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EGudNWNxeOPf46ln' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/receiving/grns/{note}/ncrs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
          4 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NcrController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\NcrController@store',
        'namespace' => NULL,
        'prefix' => 'api/receiving/grns',
        'where' => 
        array (
        ),
        'as' => 'generated::EGudNWNxeOPf46ln',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iRkpjA0vrz9xVI2I' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/receiving/ncrs/{ncr}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
          4 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NcrController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\NcrController@update',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::iRkpjA0vrz9xVI2I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ObWQZ516kXxV4Gsl' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/change-orders/{changeOrder}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'ensure.company.onboarded',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PoChangeOrderController@approve',
        'controller' => 'App\\Http\\Controllers\\Api\\PoChangeOrderController@approve',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ObWQZ516kXxV4Gsl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QRiufe3pW947E2yT' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/change-orders/{changeOrder}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
          2 => 'ensure.company.onboarded',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PoChangeOrderController@reject',
        'controller' => 'App\\Http\\Controllers\\Api\\PoChangeOrderController@reject',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::QRiufe3pW947E2yT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ooiEgne63GqJjHFG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyRegistrationController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyRegistrationController@store',
        'namespace' => NULL,
        'prefix' => 'api/companies',
        'where' => 
        array (
        ),
        'as' => 'generated::ooiEgne63GqJjHFG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jN7TheR08cRJEktA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/companies/{company}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyRegistrationController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyRegistrationController@show',
        'namespace' => NULL,
        'prefix' => 'api/companies',
        'where' => 
        array (
        ),
        'as' => 'generated::jN7TheR08cRJEktA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fxpQ3HVIxMff6A6W' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/companies/{company}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyRegistrationController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyRegistrationController@update',
        'namespace' => NULL,
        'prefix' => 'api/companies',
        'where' => 
        array (
        ),
        'as' => 'generated::fxpQ3HVIxMff6A6W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::16wvbfN0g4pZIgUX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/companies/{company}/documents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyDocumentController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyDocumentController@index',
        'namespace' => NULL,
        'prefix' => 'api/companies',
        'where' => 
        array (
        ),
        'as' => 'generated::16wvbfN0g4pZIgUX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::71ze8EKiAkNIUDH1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/companies/{company}/documents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyDocumentController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyDocumentController@store',
        'namespace' => NULL,
        'prefix' => 'api/companies',
        'where' => 
        array (
        ),
        'as' => 'generated::71ze8EKiAkNIUDH1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::E6WXfI02idP9CuSU' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/companies/{company}/documents/{document}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyDocumentController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyDocumentController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/companies',
        'where' => 
        array (
        ),
        'as' => 'generated::E6WXfI02idP9CuSU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ovmBLxygE0JFFBaM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/invoices',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'billing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@list',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@list',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::ovmBLxygE0JFFBaM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aNW3FaZNm4AzSgPT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/invoices/{invoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'billing_access:read',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@show',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::aNW3FaZNm4AzSgPT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JfyDur84NXyhNm34' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/invoices/{invoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
          4 => 'billing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@update',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::JfyDur84NXyhNm34',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iLpuLKeqofycHpfr' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/invoices/{invoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
          4 => 'billing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::iLpuLKeqofycHpfr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::b6WfKJewmSWmC1MH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/invoices/from-po',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
          4 => 'billing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@storeFromPo',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@storeFromPo',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::b6WfKJewmSWmC1MH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::95RO6xp2M6KATujO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/invoices/{invoice}/attachments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
          4 => 'billing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@attachFile',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@attachFile',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::95RO6xp2M6KATujO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZEvOwWFCRFXwgWge' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/invoices/{invoice}/review/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
          4 => 'billing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@approve',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@approve',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::ZEvOwWFCRFXwgWge',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5Ds5QIhVtKV2ArXF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/invoices/{invoice}/review/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
          4 => 'billing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@reject',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@reject',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::5Ds5QIhVtKV2ArXF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6P6LRuS8w4Uf23cF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/invoices/{invoice}/review/request-changes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
          4 => 'billing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@requestChanges',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@requestChanges',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::6P6LRuS8w4Uf23cF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4sLb7ia9exIgRz12' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/invoices/{invoice}/mark-paid',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
          4 => 'billing_access:write',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceController@markPaid',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceController@markPaid',
        'namespace' => NULL,
        'prefix' => 'api/invoices',
        'where' => 
        array (
        ),
        'as' => 'generated::4sLb7ia9exIgRz12',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::leKrbrFuJfglxLkn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/inventory/items',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryItemController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryItemController@index',
        'namespace' => NULL,
        'prefix' => 'api/inventory',
        'where' => 
        array (
        ),
        'as' => 'generated::leKrbrFuJfglxLkn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kdBBmU1qzbJQ47Pf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/inventory/items',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryItemController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryItemController@store',
        'namespace' => NULL,
        'prefix' => 'api/inventory',
        'where' => 
        array (
        ),
        'as' => 'generated::kdBBmU1qzbJQ47Pf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vf3ZTbzUjnFbjcC3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/inventory/items/{item}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryItemController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryItemController@show',
        'namespace' => NULL,
        'prefix' => 'api/inventory',
        'where' => 
        array (
        ),
        'as' => 'generated::vf3ZTbzUjnFbjcC3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'item' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nFEujvrWNBYr1CSf' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/inventory/items/{item}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryItemController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryItemController@update',
        'namespace' => NULL,
        'prefix' => 'api/inventory',
        'where' => 
        array (
        ),
        'as' => 'generated::nFEujvrWNBYr1CSf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'item' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M0VSAPg6msbzag7o' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/inventory/low-stock',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryLowStockController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryLowStockController@index',
        'namespace' => NULL,
        'prefix' => 'api/inventory',
        'where' => 
        array (
        ),
        'as' => 'generated::M0VSAPg6msbzag7o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mYgQA5S8msdySPYM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/inventory/movements',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryMovementController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryMovementController@index',
        'namespace' => NULL,
        'prefix' => 'api/inventory',
        'where' => 
        array (
        ),
        'as' => 'generated::mYgQA5S8msdySPYM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8JVLVfFsgsFKwG5i' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/inventory/movements',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryMovementController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryMovementController@store',
        'namespace' => NULL,
        'prefix' => 'api/inventory',
        'where' => 
        array (
        ),
        'as' => 'generated::8JVLVfFsgsFKwG5i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pvjxqdh8FNDsJLDM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/inventory/locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.inventory.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryLocationController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Inventory\\InventoryLocationController@index',
        'namespace' => NULL,
        'prefix' => 'api/inventory',
        'where' => 
        array (
        ),
        'as' => 'generated::pvjxqdh8FNDsJLDM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cCqTuwfF9GyWlaId' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/documents',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DocumentController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\DocumentController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::cCqTuwfF9GyWlaId',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wEzaUTYk31K34Pzl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/documents/{document}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DocumentController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\DocumentController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::wEzaUTYk31K34Pzl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f00VPJMGwMAWEvXp' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/documents/{document}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DocumentController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\DocumentController@destroy',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::f00VPJMGwMAWEvXp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tKOb6fNeSQl55PWy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company-invitations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInvitationController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInvitationController@index',
        'namespace' => NULL,
        'prefix' => 'api/company-invitations',
        'where' => 
        array (
        ),
        'as' => 'generated::tKOb6fNeSQl55PWy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iHEawvS5XqN7YbR5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/company-invitations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInvitationController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInvitationController@store',
        'namespace' => NULL,
        'prefix' => 'api/company-invitations',
        'where' => 
        array (
        ),
        'as' => 'generated::iHEawvS5XqN7YbR5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IKZgUeMZyiLwfe6y' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/company-invitations/{invitation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyInvitationController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyInvitationController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/company-invitations',
        'where' => 
        array (
        ),
        'as' => 'generated::IKZgUeMZyiLwfe6y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KDc8cAdzFaHPQkIF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company-members',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyMemberController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyMemberController@index',
        'namespace' => NULL,
        'prefix' => 'api/company-members',
        'where' => 
        array (
        ),
        'as' => 'generated::KDc8cAdzFaHPQkIF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4sdCyElRIuijZLvr' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/company-members/{member}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyMemberController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyMemberController@update',
        'namespace' => NULL,
        'prefix' => 'api/company-members',
        'where' => 
        array (
        ),
        'as' => 'generated::4sdCyElRIuijZLvr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::03ih5XwIovbm4Pov' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/company-members/{member}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyMemberController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyMemberController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/company-members',
        'where' => 
        array (
        ),
        'as' => 'generated::03ih5XwIovbm4Pov',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uD1hwfAn6GN2HBJM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/company-role-templates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CompanyRoleTemplateController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CompanyRoleTemplateController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::uD1hwfAn6GN2HBJM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::csg1kktVVvTNetUx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/settings/company',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Settings\\CompanySettingsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Settings\\CompanySettingsController@show',
        'namespace' => NULL,
        'prefix' => 'api/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::csg1kktVVvTNetUx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::o9KW5bBZ6LOEpbfa' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/settings/company',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Settings\\CompanySettingsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Settings\\CompanySettingsController@update',
        'namespace' => NULL,
        'prefix' => 'api/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::o9KW5bBZ6LOEpbfa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jhsBIcyWWLswj0kI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/settings/localization',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'buyer_admin_only',
          4 => 'ensure.localization.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\LocaleSettingsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\LocaleSettingsController@show',
        'namespace' => NULL,
        'prefix' => 'api/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::jhsBIcyWWLswj0kI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0zoUkKQFasvpIqaF' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/settings/localization',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'buyer_admin_only',
          4 => 'ensure.localization.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\LocaleSettingsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\LocaleSettingsController@update',
        'namespace' => NULL,
        'prefix' => 'api/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::0zoUkKQFasvpIqaF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ujVuUPZxpf15IUoK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/settings/numbering',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Settings\\NumberingSettingsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Settings\\NumberingSettingsController@show',
        'namespace' => NULL,
        'prefix' => 'api/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::ujVuUPZxpf15IUoK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9lX9tdWZ8q6tQPkP' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/settings/numbering',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Settings\\NumberingSettingsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Settings\\NumberingSettingsController@update',
        'namespace' => NULL,
        'prefix' => 'api/settings',
        'where' => 
        array (
        ),
        'as' => 'generated::9lX9tdWZ8q6tQPkP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NMxQ5Eh49c8cNva9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/dashboard/metrics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.analytics.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DashboardController@metrics',
        'controller' => 'App\\Http\\Controllers\\Api\\DashboardController@metrics',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::NMxQ5Eh49c8cNva9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RVQlC98VAggWg8jR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/localization/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.localization.access',
          3 => 'apply.company.locale',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\LocaleSettingsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\LocaleSettingsController@show',
        'namespace' => NULL,
        'prefix' => 'api/localization',
        'where' => 
        array (
        ),
        'as' => 'generated::RVQlC98VAggWg8jR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VQ1ZSiI46aazlPEY' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/localization/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.localization.access',
          3 => 'apply.company.locale',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\LocaleSettingsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\LocaleSettingsController@update',
        'namespace' => NULL,
        'prefix' => 'api/localization',
        'where' => 
        array (
        ),
        'as' => 'generated::VQ1ZSiI46aazlPEY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HlBvckcfF0sZ9K5n' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/localization/uoms',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.localization.access',
          3 => 'apply.company.locale',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\UomController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\UomController@index',
        'namespace' => NULL,
        'prefix' => 'api/localization',
        'where' => 
        array (
        ),
        'as' => 'generated::HlBvckcfF0sZ9K5n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PfkIc33ozGwCNMq8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/localization/uoms',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.localization.access',
          3 => 'apply.company.locale',
          4 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\UomController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\UomController@store',
        'namespace' => NULL,
        'prefix' => 'api/localization',
        'where' => 
        array (
        ),
        'as' => 'generated::PfkIc33ozGwCNMq8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::g2qMOXkQee5JVg9L' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/localization/uoms/{uom}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.localization.access',
          3 => 'apply.company.locale',
          4 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\UomController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\UomController@update',
        'namespace' => NULL,
        'prefix' => 'api/localization',
        'where' => 
        array (
        ),
        'as' => 'generated::g2qMOXkQee5JVg9L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tcwuzZBweHISZTsD' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/localization/uoms/{uom}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.localization.access',
          3 => 'apply.company.locale',
          4 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\UomController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\UomController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/localization',
        'where' => 
        array (
        ),
        'as' => 'generated::tcwuzZBweHISZTsD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9ErEBfWBW1ZUGm12' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/localization/uoms/conversions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.localization.access',
          3 => 'apply.company.locale',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\UomConversionController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\UomConversionController@index',
        'namespace' => NULL,
        'prefix' => 'api/localization',
        'where' => 
        array (
        ),
        'as' => 'generated::9ErEBfWBW1ZUGm12',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cOG5qrUBlaSix0ds' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/localization/uoms/conversions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.localization.access',
          3 => 'apply.company.locale',
          4 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\UomConversionController@upsert',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\UomConversionController@upsert',
        'namespace' => NULL,
        'prefix' => 'api/localization',
        'where' => 
        array (
        ),
        'as' => 'generated::cOG5qrUBlaSix0ds',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ESw45oa7EEIkHalc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/localization/uom/convert',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.localization.access',
          3 => 'apply.company.locale',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\UomConversionController@convert',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\UomConversionController@convert',
        'namespace' => NULL,
        'prefix' => 'api/localization',
        'where' => 
        array (
        ),
        'as' => 'generated::ESw45oa7EEIkHalc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QGa6QackwcrvWMQM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/localization/parts/{part}/convert',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.localization.access',
          3 => 'apply.company.locale',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Localization\\UomConversionController@convertForPart',
        'controller' => 'App\\Http\\Controllers\\Api\\Localization\\UomConversionController@convertForPart',
        'namespace' => NULL,
        'prefix' => 'api/localization',
        'where' => 
        array (
        ),
        'as' => 'generated::QGa6QackwcrvWMQM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/digital-twin/locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'locations.index',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\LocationController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\LocationController@index',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/digital-twin/locations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'locations.store',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\LocationController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\LocationController@store',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/digital-twin/locations/{location}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'locations.show',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\LocationController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\LocationController@show',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/digital-twin/locations/{location}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'locations.update',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\LocationController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\LocationController@update',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locations.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/digital-twin/locations/{location}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'locations.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\LocationController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\LocationController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'systems.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/digital-twin/systems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'systems.index',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\SystemController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\SystemController@index',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'systems.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/digital-twin/systems',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'systems.store',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\SystemController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\SystemController@store',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'systems.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/digital-twin/systems/{system}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'systems.show',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\SystemController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\SystemController@show',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'systems.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/digital-twin/systems/{system}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'systems.update',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\SystemController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\SystemController@update',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'systems.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/digital-twin/systems/{system}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'systems.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\SystemController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\SystemController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/digital-twin/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'assets.index',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@index',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/digital-twin/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'assets.store',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@store',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/digital-twin/assets/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'assets.show',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@show',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/digital-twin/assets/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'assets.update',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@update',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assets.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/digital-twin/assets/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'assets.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4yofsvdF4S8LF48E' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/digital-twin/assets/{asset}/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@setStatus',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetController@setStatus',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
        'as' => 'generated::4yofsvdF4S8LF48E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qF5FvjTlotf7ETBj' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/digital-twin/assets/{asset}/bom',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetBomController@sync',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetBomController@sync',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
        'as' => 'generated::qF5FvjTlotf7ETBj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h4mDJEP1MwuvkgwN' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/digital-twin/assets/{asset}/procedures/{procedure}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetMaintenanceController@link',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetMaintenanceController@link',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
        'as' => 'generated::h4mDJEP1MwuvkgwN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2IOMXZEIN9HCY1Pr' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/digital-twin/assets/{asset}/procedures/{procedure}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetMaintenanceController@detach',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetMaintenanceController@detach',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
        'as' => 'generated::2IOMXZEIN9HCY1Pr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A0Ebewi40HhAaKCI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/digital-twin/assets/{asset}/procedures/{procedure}/complete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetMaintenanceController@complete',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\AssetMaintenanceController@complete',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
        'as' => 'generated::A0Ebewi40HhAaKCI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'procedures.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/digital-twin/procedures',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'procedures.index',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\MaintenanceProcedureController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\MaintenanceProcedureController@index',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'procedures.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/digital-twin/procedures',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'procedures.store',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\MaintenanceProcedureController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\MaintenanceProcedureController@store',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'procedures.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/digital-twin/procedures/{procedure}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'procedures.show',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\MaintenanceProcedureController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\MaintenanceProcedureController@show',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'procedures.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/digital-twin/procedures/{procedure}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'procedures.update',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\MaintenanceProcedureController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\MaintenanceProcedureController@update',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'procedures.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/digital-twin/procedures/{procedure}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.digital_twin.access',
        ),
        'as' => 'procedures.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\MaintenanceProcedureController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\DigitalTwin\\MaintenanceProcedureController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/digital-twin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OIH2O1lMaEQfhE6g' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/search',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.search.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SearchController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SearchController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::OIH2O1lMaEQfhE6g',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KVNSNRXeyLe6esK9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/saved-searches',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.search.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SavedSearchController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SavedSearchController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::KVNSNRXeyLe6esK9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4OCAiCupQVxiCfrz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/saved-searches',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.search.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SavedSearchController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\SavedSearchController@store',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::4OCAiCupQVxiCfrz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QEqkXWSOsDuG7eA4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/saved-searches/{savedSearch}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.search.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SavedSearchController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\SavedSearchController@show',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::QEqkXWSOsDuG7eA4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uswMDrSXUShyiskC' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/saved-searches/{savedSearch}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.search.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SavedSearchController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\SavedSearchController@update',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::uswMDrSXUShyiskC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EOeK63STk3Anhy19' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/saved-searches/{savedSearch}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.search.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SavedSearchController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\SavedSearchController@destroy',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::EOeK63STk3Anhy19',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mddk0SRNXdaU5dH3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/analytics/overview',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.analytics.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AnalyticsController@overview',
        'controller' => 'App\\Http\\Controllers\\Api\\AnalyticsController@overview',
        'namespace' => NULL,
        'prefix' => 'api/analytics',
        'where' => 
        array (
        ),
        'as' => 'generated::mddk0SRNXdaU5dH3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hif8AHiV7wl32eFF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/analytics/generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.analytics.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AnalyticsController@generate',
        'controller' => 'App\\Http\\Controllers\\Api\\AnalyticsController@generate',
        'namespace' => NULL,
        'prefix' => 'api/analytics',
        'where' => 
        array (
        ),
        'as' => 'generated::hif8AHiV7wl32eFF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vDGuB5q8pKt8Fs2U' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/copilot/analytics',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.analytics.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CopilotController@handle',
        'controller' => 'App\\Http\\Controllers\\Api\\CopilotController@handle',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::vDGuB5q8pKt8Fs2U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UiCq2Ib3VyEb0Fra' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/risk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.risk.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierRiskController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierRiskController@index',
        'namespace' => NULL,
        'prefix' => 'api/risk',
        'where' => 
        array (
        ),
        'as' => 'generated::UiCq2Ib3VyEb0Fra',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qC0ugj3bwEGsXjV9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/risk/{supplier}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.risk.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierRiskController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierRiskController@show',
        'namespace' => NULL,
        'prefix' => 'api/risk',
        'where' => 
        array (
        ),
        'as' => 'generated::qC0ugj3bwEGsXjV9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mOJeeoJIkxXJJCNS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/risk/generate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.risk.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SupplierRiskController@generate',
        'controller' => 'App\\Http\\Controllers\\Api\\SupplierRiskController@generate',
        'namespace' => NULL,
        'prefix' => 'api/risk',
        'where' => 
        array (
        ),
        'as' => 'generated::mOJeeoJIkxXJJCNS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XCGEPI2EXYis7tzO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/notifications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.notifications.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NotificationController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\NotificationController@index',
        'namespace' => NULL,
        'prefix' => 'api/notifications',
        'where' => 
        array (
        ),
        'as' => 'generated::XCGEPI2EXYis7tzO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::85YrfR6AZzdgVxIE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/notifications/read',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.notifications.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NotificationController@markSelectedRead',
        'controller' => 'App\\Http\\Controllers\\Api\\NotificationController@markSelectedRead',
        'namespace' => NULL,
        'prefix' => 'api/notifications',
        'where' => 
        array (
        ),
        'as' => 'generated::85YrfR6AZzdgVxIE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jvuq8CFIQJOm5IOb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/notifications/mark-all-read',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.notifications.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NotificationController@markAllRead',
        'controller' => 'App\\Http\\Controllers\\Api\\NotificationController@markAllRead',
        'namespace' => NULL,
        'prefix' => 'api/notifications',
        'where' => 
        array (
        ),
        'as' => 'generated::jvuq8CFIQJOm5IOb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JDr7bpIzgmU9cXMu' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/notifications/{notification}/read',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.notifications.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NotificationController@markRead',
        'controller' => 'App\\Http\\Controllers\\Api\\NotificationController@markRead',
        'namespace' => NULL,
        'prefix' => 'api/notifications',
        'where' => 
        array (
        ),
        'as' => 'generated::JDr7bpIzgmU9cXMu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QQszrA5dkNFtaHzq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/events/deliveries',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.events.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\EventDeliveryController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\EventDeliveryController@index',
        'namespace' => NULL,
        'prefix' => 'api/events',
        'where' => 
        array (
        ),
        'as' => 'generated::QQszrA5dkNFtaHzq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wcxmlcvO2AZmzO7n' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/events/deliveries/{delivery}/retry',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.events.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\EventDeliveryController@retry',
        'controller' => 'App\\Http\\Controllers\\Api\\EventDeliveryController@retry',
        'namespace' => NULL,
        'prefix' => 'api/events',
        'where' => 
        array (
        ),
        'as' => 'generated::wcxmlcvO2AZmzO7n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JZx9Oh7Wjk8MzaWi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/events/dlq/replay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.events.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\EventDeliveryController@replay',
        'controller' => 'App\\Http\\Controllers\\Api\\EventDeliveryController@replay',
        'namespace' => NULL,
        'prefix' => 'api/events',
        'where' => 
        array (
        ),
        'as' => 'generated::JZx9Oh7Wjk8MzaWi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::g6iTj3b1Xd816OwE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/notification-preferences',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.notifications.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NotificationPreferenceController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\NotificationPreferenceController@index',
        'namespace' => NULL,
        'prefix' => 'api/notification-preferences',
        'where' => 
        array (
        ),
        'as' => 'generated::g6iTj3b1Xd816OwE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AFw1nGA9LvipVlFa' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/notification-preferences',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.notifications.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\NotificationPreferenceController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\NotificationPreferenceController@update',
        'namespace' => NULL,
        'prefix' => 'api/notification-preferences',
        'where' => 
        array (
        ),
        'as' => 'generated::AFw1nGA9LvipVlFa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wWItQCVbauFcDgMu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rmas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.rma.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RmaController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\RmaController@index',
        'namespace' => NULL,
        'prefix' => 'api/rmas',
        'where' => 
        array (
        ),
        'as' => 'generated::wWItQCVbauFcDgMu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BNqfMbRHXek2ql2k' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rmas/purchase-orders/{purchaseOrder}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.rma.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RmaController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\RmaController@store',
        'namespace' => NULL,
        'prefix' => 'api/rmas',
        'where' => 
        array (
        ),
        'as' => 'generated::BNqfMbRHXek2ql2k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e6Kde2B5CZ83w40o' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/rmas/{rma}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.rma.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RmaController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\RmaController@show',
        'namespace' => NULL,
        'prefix' => 'api/rmas',
        'where' => 
        array (
        ),
        'as' => 'generated::e6Kde2B5CZ83w40o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5DttqMBAQ5rSU9qh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/rmas/{rma}/review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.rma.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\RmaController@review',
        'controller' => 'App\\Http\\Controllers\\Api\\RmaController@review',
        'namespace' => NULL,
        'prefix' => 'api/rmas',
        'where' => 
        array (
        ),
        'as' => 'generated::5DttqMBAQ5rSU9qh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sCACUa5GkHRyAxtI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/exports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.export.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportController@index',
        'namespace' => NULL,
        'prefix' => 'api/exports',
        'where' => 
        array (
        ),
        'as' => 'generated::sCACUa5GkHRyAxtI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9FLFxwsxl78OKHQG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/exports',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.export.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportController@store',
        'namespace' => NULL,
        'prefix' => 'api/exports',
        'where' => 
        array (
        ),
        'as' => 'generated::9FLFxwsxl78OKHQG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aiodxjTYM07JDrYW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/exports/{exportRequest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.export.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportController@show',
        'namespace' => NULL,
        'prefix' => 'api/exports',
        'where' => 
        array (
        ),
        'as' => 'generated::aiodxjTYM07JDrYW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'exports.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/exports/{exportRequest}/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.export.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ExportController@download',
        'controller' => 'App\\Http\\Controllers\\Api\\ExportController@download',
        'namespace' => NULL,
        'prefix' => 'api/exports',
        'where' => 
        array (
        ),
        'as' => 'exports.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aXOdJoKMmKZ62wo4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/downloads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DownloadJobController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\DownloadJobController@index',
        'namespace' => NULL,
        'prefix' => 'api/downloads',
        'where' => 
        array (
        ),
        'as' => 'generated::aXOdJoKMmKZ62wo4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3Y07WpZCtNvNogi2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/downloads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DownloadJobController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\DownloadJobController@store',
        'namespace' => NULL,
        'prefix' => 'api/downloads',
        'where' => 
        array (
        ),
        'as' => 'generated::3Y07WpZCtNvNogi2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::L7DxySyI9WDxH9bT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/downloads/{downloadJob}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DownloadJobController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\DownloadJobController@show',
        'namespace' => NULL,
        'prefix' => 'api/downloads',
        'where' => 
        array (
        ),
        'as' => 'generated::L7DxySyI9WDxH9bT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SJBZmdNsJQOurvIm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/downloads/{downloadJob}/retry',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DownloadJobController@retry',
        'controller' => 'App\\Http\\Controllers\\Api\\DownloadJobController@retry',
        'namespace' => NULL,
        'prefix' => 'api/downloads',
        'where' => 
        array (
        ),
        'as' => 'generated::SJBZmdNsJQOurvIm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'downloads.file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/downloads/{downloadJob}/file',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.company.onboarded',
          3 => 'ensure.subscribed',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DownloadJobController@download',
        'controller' => 'App\\Http\\Controllers\\Api\\DownloadJobController@download',
        'namespace' => NULL,
        'prefix' => 'api/downloads',
        'where' => 
        array (
        ),
        'as' => 'downloads.file',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lnNDPUOpPCz9ENQG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/credit-notes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.credit_notes.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CreditNoteController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\CreditNoteController@index',
        'namespace' => NULL,
        'prefix' => 'api/credit-notes',
        'where' => 
        array (
        ),
        'as' => 'generated::lnNDPUOpPCz9ENQG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RFIvPHQfi3LRcHKt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/credit-notes/invoices/{invoice}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.credit_notes.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CreditNoteController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\CreditNoteController@store',
        'namespace' => NULL,
        'prefix' => 'api/credit-notes',
        'where' => 
        array (
        ),
        'as' => 'generated::RFIvPHQfi3LRcHKt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NIHtWcngkgEe7aO4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/credit-notes/{creditNote}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.credit_notes.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CreditNoteController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\CreditNoteController@show',
        'namespace' => NULL,
        'prefix' => 'api/credit-notes',
        'where' => 
        array (
        ),
        'as' => 'generated::NIHtWcngkgEe7aO4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D11fcB4MYh8ouVOn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/credit-notes/{creditNote}/issue',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.credit_notes.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CreditNoteController@issue',
        'controller' => 'App\\Http\\Controllers\\Api\\CreditNoteController@issue',
        'namespace' => NULL,
        'prefix' => 'api/credit-notes',
        'where' => 
        array (
        ),
        'as' => 'generated::D11fcB4MYh8ouVOn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::V9IeREvYEQQ0XYFn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/credit-notes/{creditNote}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.credit_notes.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CreditNoteController@approve',
        'controller' => 'App\\Http\\Controllers\\Api\\CreditNoteController@approve',
        'namespace' => NULL,
        'prefix' => 'api/credit-notes',
        'where' => 
        array (
        ),
        'as' => 'generated::V9IeREvYEQQ0XYFn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FEiyIyCiETsuUk9H' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/credit-notes/{creditNote}/lines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.credit_notes.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CreditNoteController@updateLines',
        'controller' => 'App\\Http\\Controllers\\Api\\CreditNoteController@updateLines',
        'namespace' => NULL,
        'prefix' => 'api/credit-notes',
        'where' => 
        array (
        ),
        'as' => 'generated::FEiyIyCiETsuUk9H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1l0Axsf9Ai6uIHf2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/credit-notes/{creditNote}/attachments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.credit_notes.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CreditNoteController@attachFile',
        'controller' => 'App\\Http\\Controllers\\Api\\CreditNoteController@attachFile',
        'namespace' => NULL,
        'prefix' => 'api/credit-notes',
        'where' => 
        array (
        ),
        'as' => 'generated::1l0Axsf9Ai6uIHf2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TgU77AQta6MAL03Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/money/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MoneySettingsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\MoneySettingsController@show',
        'namespace' => NULL,
        'prefix' => 'api/money',
        'where' => 
        array (
        ),
        'as' => 'generated::TgU77AQta6MAL03Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AcRG2hk7Nlk8YlTu' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/money/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\MoneySettingsController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\MoneySettingsController@update',
        'namespace' => NULL,
        'prefix' => 'api/money',
        'where' => 
        array (
        ),
        'as' => 'generated::AcRG2hk7Nlk8YlTu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RsO3KaKYQxD4arpW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/money/fx',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FxRateController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\FxRateController@index',
        'namespace' => NULL,
        'prefix' => 'api/money',
        'where' => 
        array (
        ),
        'as' => 'generated::RsO3KaKYQxD4arpW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MrbX1qGUTrGsJxcI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/money/fx',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\FxRateController@upsert',
        'controller' => 'App\\Http\\Controllers\\Api\\FxRateController@upsert',
        'namespace' => NULL,
        'prefix' => 'api/money',
        'where' => 
        array (
        ),
        'as' => 'generated::MrbX1qGUTrGsJxcI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tax-codes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/money/tax-codes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'as' => 'tax-codes.index',
        'uses' => 'App\\Http\\Controllers\\Api\\TaxCodeController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\TaxCodeController@index',
        'namespace' => NULL,
        'prefix' => 'api/money',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tax-codes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/money/tax-codes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'as' => 'tax-codes.store',
        'uses' => 'App\\Http\\Controllers\\Api\\TaxCodeController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\TaxCodeController@store',
        'namespace' => NULL,
        'prefix' => 'api/money',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tax-codes.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/money/tax-codes/{tax_code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'as' => 'tax-codes.show',
        'uses' => 'App\\Http\\Controllers\\Api\\TaxCodeController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\TaxCodeController@show',
        'namespace' => NULL,
        'prefix' => 'api/money',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tax-codes.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'api/money/tax-codes/{tax_code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'as' => 'tax-codes.update',
        'uses' => 'App\\Http\\Controllers\\Api\\TaxCodeController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\TaxCodeController@update',
        'namespace' => NULL,
        'prefix' => 'api/money',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tax-codes.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/money/tax-codes/{tax_code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'as' => 'tax-codes.destroy',
        'uses' => 'App\\Http\\Controllers\\Api\\TaxCodeController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\TaxCodeController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/money',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z9KtHCYVRzO5p2oE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/quotes/{quote}/recalculate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\QuoteTotalsController@recalculate',
        'controller' => 'App\\Http\\Controllers\\Api\\QuoteTotalsController@recalculate',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::z9KtHCYVRzO5p2oE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::obGchxC0E3KqEBF3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/purchase-orders/{purchaseOrder}/recalculate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\PoTotalsController@recalculate',
        'controller' => 'App\\Http\\Controllers\\Api\\PoTotalsController@recalculate',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::obGchxC0E3KqEBF3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sfYRycmRFqY7NJrv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/invoices/{invoice}/recalculate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\InvoiceTotalsController@recalculate',
        'controller' => 'App\\Http\\Controllers\\Api\\InvoiceTotalsController@recalculate',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::sfYRycmRFqY7NJrv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NIHbSMGDurD52dwg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/credit-notes/{creditNote}/recalculate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.subscribed',
          3 => 'ensure.money.access:billing',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\CreditTotalsController@recalculate',
        'controller' => 'App\\Http\\Controllers\\Api\\CreditTotalsController@recalculate',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::NIHbSMGDurD52dwg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VSQCnlvvd2o53BmE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/approvals/rules',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApprovalRuleController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ApprovalRuleController@index',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::VSQCnlvvd2o53BmE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q8B4x0355pfhqJyT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/approvals/rules/{rule}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApprovalRuleController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ApprovalRuleController@show',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::q8B4x0355pfhqJyT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gvLr3Nm2u61oImwS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/approvals/rules',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
          3 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApprovalRuleController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\ApprovalRuleController@store',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::gvLr3Nm2u61oImwS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Xuzob6TZAX9DLgmV' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/approvals/rules/{rule}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
          3 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApprovalRuleController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\ApprovalRuleController@update',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::Xuzob6TZAX9DLgmV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UvzTwDJb3pB16cLt' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/approvals/rules/{rule}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
          3 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApprovalRuleController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\ApprovalRuleController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::UvzTwDJb3pB16cLt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7kFKf67XieQN7li4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/approvals/requests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApprovalRequestController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ApprovalRequestController@index',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::7kFKf67XieQN7li4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TmnFrJMfAiPqWJge' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/approvals/requests/{approval}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApprovalRequestController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\ApprovalRequestController@show',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::TmnFrJMfAiPqWJge',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nDUNvBeHGKzID1Mp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/approvals/requests/{approval}/action',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApprovalRequestController@action',
        'controller' => 'App\\Http\\Controllers\\Api\\ApprovalRequestController@action',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::nDUNvBeHGKzID1Mp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3uyuEpmqg5jYEt75' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/approvals/delegations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DelegationController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\DelegationController@index',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::3uyuEpmqg5jYEt75',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::t5m4IoS125ETzzF0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/approvals/delegations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
          3 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DelegationController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\DelegationController@store',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::t5m4IoS125ETzzF0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IQ2HNbzS6Ei395qH' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/approvals/delegations/{delegation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
          3 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DelegationController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\DelegationController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::IQ2HNbzS6Ei395qH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::13aka9H2EJNgUbYl' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/approvals/delegations/{delegation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'ensure.company.onboarded',
          2 => 'ensure.approvals.access',
          3 => 'buyer_admin_only',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DelegationController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\DelegationController@store',
        'namespace' => NULL,
        'prefix' => 'api/approvals',
        'where' => 
        array (
        ),
        'as' => 'generated::13aka9H2EJNgUbYl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bWRojI29OpWSfn0e' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/webhooks/stripe/invoice/payment-succeeded',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Billing\\StripeWebhookController@invoicePaymentSucceeded',
        'controller' => 'App\\Http\\Controllers\\Api\\Billing\\StripeWebhookController@invoicePaymentSucceeded',
        'namespace' => NULL,
        'prefix' => 'api/webhooks/stripe',
        'where' => 
        array (
        ),
        'as' => 'generated::bWRojI29OpWSfn0e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YsDhZTkNTVuCpH8e' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/webhooks/stripe/invoice/payment-failed',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Billing\\StripeWebhookController@invoicePaymentFailed',
        'controller' => 'App\\Http\\Controllers\\Api\\Billing\\StripeWebhookController@invoicePaymentFailed',
        'namespace' => NULL,
        'prefix' => 'api/webhooks/stripe',
        'where' => 
        array (
        ),
        'as' => 'generated::YsDhZTkNTVuCpH8e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p7TJDmwhOu0b4da3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/webhooks/stripe/customer/subscription-updated',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Billing\\StripeWebhookController@customerSubscriptionUpdated',
        'controller' => 'App\\Http\\Controllers\\Api\\Billing\\StripeWebhookController@customerSubscriptionUpdated',
        'namespace' => NULL,
        'prefix' => 'api/webhooks/stripe',
        'where' => 
        array (
        ),
        'as' => 'generated::p7TJDmwhOu0b4da3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7rNpHDecmB9yxX7R' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/billing/stripe/webhook',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Billing\\StripeWebhookController@catchAll',
        'controller' => 'App\\Http\\Controllers\\Api\\Billing\\StripeWebhookController@catchAll',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::7rNpHDecmB9yxX7R',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cdgXT97PCV0qUYdf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:843:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'C:\\\\Users\\\\sadhu\\\\Herd\\\\elements-supply-ai\\\\vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Foundation\\\\Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"00000000000006700000000000000000";}}',
        'as' => 'generated::cdgXT97PCV0qUYdf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gwfDT0uuQTjDNgTw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\AuthSessionController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\AuthSessionController@store',
        'namespace' => NULL,
        'prefix' => '/api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::gwfDT0uuQTjDNgTw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VJvLJxGUAfWhG2Jz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\SelfRegistrationController@register',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\SelfRegistrationController@register',
        'namespace' => NULL,
        'prefix' => '/api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::VJvLJxGUAfWhG2Jz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Dy5nwTCrcx5ZvqZ1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/auth/me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\AuthSessionController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\AuthSessionController@show',
        'namespace' => NULL,
        'prefix' => '/api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::Dy5nwTCrcx5ZvqZ1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i6PwFkYIUq46ZFSR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\AuthSessionController@destroy',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\AuthSessionController@destroy',
        'namespace' => NULL,
        'prefix' => '/api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::i6PwFkYIUq46ZFSR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::84AOZAYUDoPX8mbm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/persona',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\ActivePersonaController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\ActivePersonaController@store',
        'namespace' => NULL,
        'prefix' => '/api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::84AOZAYUDoPX8mbm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oPMrMesyfmclGqAI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\PasswordResetController@sendResetLink',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\PasswordResetController@sendResetLink',
        'namespace' => NULL,
        'prefix' => '/api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::oPMrMesyfmclGqAI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f8SouP5b82ibBwFA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/auth/reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\Auth\\PasswordResetController@reset',
        'controller' => 'App\\Http\\Controllers\\Api\\Auth\\PasswordResetController@reset',
        'namespace' => NULL,
        'prefix' => '/api/auth',
        'where' => 
        array (
        ),
        'as' => 'generated::f8SouP5b82ibBwFA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'company.registration' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'company-registration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'company.registration',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Settings\\ProfileController@edit',
        'controller' => 'App\\Http\\Controllers\\Settings\\ProfileController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'profile.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Settings\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Settings\\ProfileController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'profile.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Settings\\ProfileController@destroy',
        'controller' => 'App\\Http\\Controllers\\Settings\\ProfileController@destroy',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'profile.destroy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user-password.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Settings\\PasswordController@edit',
        'controller' => 'App\\Http\\Controllers\\Settings\\PasswordController@edit',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'user-password.edit',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user-password.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'user/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Settings\\PasswordController@update',
        'controller' => 'App\\Http\\Controllers\\Settings\\PasswordController@update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'user-password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'two-factor',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Settings\\TwoFactorAuthenticationController@show',
        'controller' => 'App\\Http\\Controllers\\Settings\\TwoFactorAuthenticationController@show',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.setup.plan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/setup/plan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'app.setup.plan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'suppliers.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/suppliers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'suppliers.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rfq.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/rfqs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'rfq.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rfq.new' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/rfqs/new',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'rfq.new',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rfq.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/rfqs/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'rfq.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rfq.open' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/rfqs/{id}/open',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'rfq.open',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'rfq.compare' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/rfqs/{id}/compare',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'rfq.compare',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'orders.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'orders.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'purchase-orders.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/purchase-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'purchase-orders.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'purchase-orders.supplier.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/purchase-orders/supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'purchase-orders.supplier.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'purchase-orders.supplier.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/purchase-orders/{id}/supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'purchase-orders.supplier.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'purchase-orders.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/purchase-orders/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'purchase-orders.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'supplier.company-profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/supplier/company-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'supplier.company-profile',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'inventory.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/inventory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'inventory.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'inventory.items.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/inventory/items',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'inventory.items.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'inventory.items.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/inventory/items/new',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'inventory.items.create',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'inventory.items.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/inventory/items/{itemId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'inventory.items.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
        'itemId' => '[A-Za-z0-9_-]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.companies.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/admin/companies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'admin.companies.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wZy1WehFSct4kSqA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/{any}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
          3 => 'ensure.company.registered',
        ),
        'uses' => '\\Illuminate\\Routing\\ViewController@__invoke',
        'controller' => '\\Illuminate\\Routing\\ViewController',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wZy1WehFSct4kSqA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
        'view' => 'app',
        'data' => 
        array (
        ),
        'status' => 200,
        'headers' => 
        array (
        ),
      ),
      'wheres' => 
      array (
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::g08qnuEFKMTwBHtr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'settings/{any?}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:155:"function (?string $any = null) {
        $suffix = $any !== null && $any !== \'\' ? \'/\'.$any : \'\';

        return \\redirect("/app/settings{$suffix}");
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000a740000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::g08qnuEFKMTwBHtr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ou89myVrERzcutHW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'POST',
        2 => 'HEAD',
      ),
      'uri' => 'broadcasting/auth',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'App\\Http\\Middleware\\AuthenticateApiSession',
          1 => 'Illuminate\\Session\\Middleware\\StartSession',
          2 => 'App\\Http\\Middleware\\ResolveCompanyContext',
          3 => 'Illuminate\\Auth\\Middleware\\Authenticate',
        ),
        'uses' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'controller' => '\\Illuminate\\Broadcasting\\BroadcastController@authenticate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'excluded_middleware' => 
        array (
          0 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
        ),
        'as' => 'generated::ou89myVrERzcutHW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:58:"C:\\Users\\sadhu\\Herd\\elements-supply-ai\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000a890000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
