<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table): void {
            $table->id();
            $table->string('number')->unique();
            $table->enum('party_type', ['supplier', 'customer'])->index();
            $table->string('party_name');
            $table->string('item_name');
            $table->unsignedInteger('quantity');
            $table->decimal('total_usd', 12, 2);
            $table->timestamp('ordered_at')->index();
            $table->enum('status', ['pending', 'confirmed', 'in_production', 'delivered', 'cancelled'])->index();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
