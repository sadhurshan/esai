# UI Branding Guidelines

- Brand: Elements Supply AI
- Primary logo: `/public/logo-colored-dark-text-transparent-bg.png`
- Symbol: `/public/logo-symbol.png`
- Light background → dark-text version
- Dark background → white-text version
- SVG logos preferred for scalable components
- Favicon = `/public/logo-symbol.png`
