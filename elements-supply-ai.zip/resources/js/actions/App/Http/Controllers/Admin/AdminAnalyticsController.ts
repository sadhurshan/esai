import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::overview
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:18
 * @route '/api/admin/analytics/overview'
 */
export const overview = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: overview.url(options),
    method: 'get',
})

overview.definition = {
    methods: ["get","head"],
    url: '/api/admin/analytics/overview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::overview
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:18
 * @route '/api/admin/analytics/overview'
 */
overview.url = (options?: RouteQueryOptions) => {
    return overview.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::overview
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:18
 * @route '/api/admin/analytics/overview'
 */
overview.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: overview.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::overview
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:18
 * @route '/api/admin/analytics/overview'
 */
overview.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: overview.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::overview
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:18
 * @route '/api/admin/analytics/overview'
 */
    const overviewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: overview.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::overview
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:18
 * @route '/api/admin/analytics/overview'
 */
        overviewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: overview.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminAnalyticsController::overview
 * @see app/Http/Controllers/Admin/AdminAnalyticsController.php:18
 * @route '/api/admin/analytics/overview'
 */
        overviewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: overview.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    overview.form = overviewForm
const AdminAnalyticsController = { overview }

export default AdminAnalyticsController