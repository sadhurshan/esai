import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ApiKeyController::index
 * @see app/Http/Controllers/Admin/ApiKeyController.php:22
 * @route '/api/admin/api-keys'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/api-keys',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ApiKeyController::index
 * @see app/Http/Controllers/Admin/ApiKeyController.php:22
 * @route '/api/admin/api-keys'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApiKeyController::index
 * @see app/Http/Controllers/Admin/ApiKeyController.php:22
 * @route '/api/admin/api-keys'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ApiKeyController::index
 * @see app/Http/Controllers/Admin/ApiKeyController.php:22
 * @route '/api/admin/api-keys'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ApiKeyController::index
 * @see app/Http/Controllers/Admin/ApiKeyController.php:22
 * @route '/api/admin/api-keys'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ApiKeyController::index
 * @see app/Http/Controllers/Admin/ApiKeyController.php:22
 * @route '/api/admin/api-keys'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ApiKeyController::index
 * @see app/Http/Controllers/Admin/ApiKeyController.php:22
 * @route '/api/admin/api-keys'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\ApiKeyController::store
 * @see app/Http/Controllers/Admin/ApiKeyController.php:43
 * @route '/api/admin/api-keys'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/api-keys',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ApiKeyController::store
 * @see app/Http/Controllers/Admin/ApiKeyController.php:43
 * @route '/api/admin/api-keys'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApiKeyController::store
 * @see app/Http/Controllers/Admin/ApiKeyController.php:43
 * @route '/api/admin/api-keys'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ApiKeyController::store
 * @see app/Http/Controllers/Admin/ApiKeyController.php:43
 * @route '/api/admin/api-keys'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ApiKeyController::store
 * @see app/Http/Controllers/Admin/ApiKeyController.php:43
 * @route '/api/admin/api-keys'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\ApiKeyController::rotate
 * @see app/Http/Controllers/Admin/ApiKeyController.php:56
 * @route '/api/admin/api-keys/{key}/rotate'
 */
export const rotate = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rotate.url(args, options),
    method: 'post',
})

rotate.definition = {
    methods: ["post"],
    url: '/api/admin/api-keys/{key}/rotate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ApiKeyController::rotate
 * @see app/Http/Controllers/Admin/ApiKeyController.php:56
 * @route '/api/admin/api-keys/{key}/rotate'
 */
rotate.url = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { key: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { key: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    key: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        key: typeof args.key === 'object'
                ? args.key.id
                : args.key,
                }

    return rotate.definition.url
            .replace('{key}', parsedArgs.key.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApiKeyController::rotate
 * @see app/Http/Controllers/Admin/ApiKeyController.php:56
 * @route '/api/admin/api-keys/{key}/rotate'
 */
rotate.post = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rotate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ApiKeyController::rotate
 * @see app/Http/Controllers/Admin/ApiKeyController.php:56
 * @route '/api/admin/api-keys/{key}/rotate'
 */
    const rotateForm = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: rotate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ApiKeyController::rotate
 * @see app/Http/Controllers/Admin/ApiKeyController.php:56
 * @route '/api/admin/api-keys/{key}/rotate'
 */
        rotateForm.post = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rotate.url(args, options),
            method: 'post',
        })
    
    rotate.form = rotateForm
/**
* @see \App\Http\Controllers\Admin\ApiKeyController::toggle
 * @see app/Http/Controllers/Admin/ApiKeyController.php:67
 * @route '/api/admin/api-keys/{key}/toggle'
 */
export const toggle = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

toggle.definition = {
    methods: ["post"],
    url: '/api/admin/api-keys/{key}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ApiKeyController::toggle
 * @see app/Http/Controllers/Admin/ApiKeyController.php:67
 * @route '/api/admin/api-keys/{key}/toggle'
 */
toggle.url = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { key: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { key: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    key: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        key: typeof args.key === 'object'
                ? args.key.id
                : args.key,
                }

    return toggle.definition.url
            .replace('{key}', parsedArgs.key.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApiKeyController::toggle
 * @see app/Http/Controllers/Admin/ApiKeyController.php:67
 * @route '/api/admin/api-keys/{key}/toggle'
 */
toggle.post = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\ApiKeyController::toggle
 * @see app/Http/Controllers/Admin/ApiKeyController.php:67
 * @route '/api/admin/api-keys/{key}/toggle'
 */
    const toggleForm = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggle.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ApiKeyController::toggle
 * @see app/Http/Controllers/Admin/ApiKeyController.php:67
 * @route '/api/admin/api-keys/{key}/toggle'
 */
        toggleForm.post = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggle.url(args, options),
            method: 'post',
        })
    
    toggle.form = toggleForm
/**
* @see \App\Http\Controllers\Admin\ApiKeyController::destroy
 * @see app/Http/Controllers/Admin/ApiKeyController.php:76
 * @route '/api/admin/api-keys/{key}'
 */
export const destroy = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/api-keys/{key}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\ApiKeyController::destroy
 * @see app/Http/Controllers/Admin/ApiKeyController.php:76
 * @route '/api/admin/api-keys/{key}'
 */
destroy.url = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { key: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { key: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    key: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        key: typeof args.key === 'object'
                ? args.key.id
                : args.key,
                }

    return destroy.definition.url
            .replace('{key}', parsedArgs.key.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ApiKeyController::destroy
 * @see app/Http/Controllers/Admin/ApiKeyController.php:76
 * @route '/api/admin/api-keys/{key}'
 */
destroy.delete = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\ApiKeyController::destroy
 * @see app/Http/Controllers/Admin/ApiKeyController.php:76
 * @route '/api/admin/api-keys/{key}'
 */
    const destroyForm = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\ApiKeyController::destroy
 * @see app/Http/Controllers/Admin/ApiKeyController.php:76
 * @route '/api/admin/api-keys/{key}'
 */
        destroyForm.delete = (args: { key: number | { id: number } } | [key: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ApiKeyController = { index, store, rotate, toggle, destroy }

export default ApiKeyController