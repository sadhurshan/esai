import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DigitalTwinAssetController::store
 * @see app/Http/Controllers/Admin/DigitalTwinAssetController.php:22
 * @route '/api/admin/digital-twins/{digital_twin}/assets'
 */
export const store = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/digital-twins/{digital_twin}/assets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DigitalTwinAssetController::store
 * @see app/Http/Controllers/Admin/DigitalTwinAssetController.php:22
 * @route '/api/admin/digital-twins/{digital_twin}/assets'
 */
store.url = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { digital_twin: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    digital_twin: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        digital_twin: args.digital_twin,
                }

    return store.definition.url
            .replace('{digital_twin}', parsedArgs.digital_twin.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DigitalTwinAssetController::store
 * @see app/Http/Controllers/Admin/DigitalTwinAssetController.php:22
 * @route '/api/admin/digital-twins/{digital_twin}/assets'
 */
store.post = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DigitalTwinAssetController::store
 * @see app/Http/Controllers/Admin/DigitalTwinAssetController.php:22
 * @route '/api/admin/digital-twins/{digital_twin}/assets'
 */
    const storeForm = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DigitalTwinAssetController::store
 * @see app/Http/Controllers/Admin/DigitalTwinAssetController.php:22
 * @route '/api/admin/digital-twins/{digital_twin}/assets'
 */
        storeForm.post = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\DigitalTwinAssetController::destroy
 * @see app/Http/Controllers/Admin/DigitalTwinAssetController.php:42
 * @route '/api/admin/digital-twins/{digital_twin}/assets/{asset}'
 */
export const destroy = (args: { digital_twin: string | number, asset: number | { id: number } } | [digital_twin: string | number, asset: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/digital-twins/{digital_twin}/assets/{asset}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\DigitalTwinAssetController::destroy
 * @see app/Http/Controllers/Admin/DigitalTwinAssetController.php:42
 * @route '/api/admin/digital-twins/{digital_twin}/assets/{asset}'
 */
destroy.url = (args: { digital_twin: string | number, asset: number | { id: number } } | [digital_twin: string | number, asset: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    digital_twin: args[0],
                    asset: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        digital_twin: args.digital_twin,
                                asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                }

    return destroy.definition.url
            .replace('{digital_twin}', parsedArgs.digital_twin.toString())
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DigitalTwinAssetController::destroy
 * @see app/Http/Controllers/Admin/DigitalTwinAssetController.php:42
 * @route '/api/admin/digital-twins/{digital_twin}/assets/{asset}'
 */
destroy.delete = (args: { digital_twin: string | number, asset: number | { id: number } } | [digital_twin: string | number, asset: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\DigitalTwinAssetController::destroy
 * @see app/Http/Controllers/Admin/DigitalTwinAssetController.php:42
 * @route '/api/admin/digital-twins/{digital_twin}/assets/{asset}'
 */
    const destroyForm = (args: { digital_twin: string | number, asset: number | { id: number } } | [digital_twin: string | number, asset: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DigitalTwinAssetController::destroy
 * @see app/Http/Controllers/Admin/DigitalTwinAssetController.php:42
 * @route '/api/admin/digital-twins/{digital_twin}/assets/{asset}'
 */
        destroyForm.delete = (args: { digital_twin: string | number, asset: number | { id: number } } | [digital_twin: string | number, asset: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DigitalTwinAssetController = { store, destroy }

export default DigitalTwinAssetController