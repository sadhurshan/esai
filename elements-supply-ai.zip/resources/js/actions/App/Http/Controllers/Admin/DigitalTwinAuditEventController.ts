import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DigitalTwinAuditEventController::index
 * @see app/Http/Controllers/Admin/DigitalTwinAuditEventController.php:13
 * @route '/api/admin/digital-twins/{digital_twin}/audit-events'
 */
export const index = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/digital-twins/{digital_twin}/audit-events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DigitalTwinAuditEventController::index
 * @see app/Http/Controllers/Admin/DigitalTwinAuditEventController.php:13
 * @route '/api/admin/digital-twins/{digital_twin}/audit-events'
 */
index.url = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { digital_twin: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    digital_twin: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        digital_twin: args.digital_twin,
                }

    return index.definition.url
            .replace('{digital_twin}', parsedArgs.digital_twin.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DigitalTwinAuditEventController::index
 * @see app/Http/Controllers/Admin/DigitalTwinAuditEventController.php:13
 * @route '/api/admin/digital-twins/{digital_twin}/audit-events'
 */
index.get = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DigitalTwinAuditEventController::index
 * @see app/Http/Controllers/Admin/DigitalTwinAuditEventController.php:13
 * @route '/api/admin/digital-twins/{digital_twin}/audit-events'
 */
index.head = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DigitalTwinAuditEventController::index
 * @see app/Http/Controllers/Admin/DigitalTwinAuditEventController.php:13
 * @route '/api/admin/digital-twins/{digital_twin}/audit-events'
 */
    const indexForm = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DigitalTwinAuditEventController::index
 * @see app/Http/Controllers/Admin/DigitalTwinAuditEventController.php:13
 * @route '/api/admin/digital-twins/{digital_twin}/audit-events'
 */
        indexForm.get = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DigitalTwinAuditEventController::index
 * @see app/Http/Controllers/Admin/DigitalTwinAuditEventController.php:13
 * @route '/api/admin/digital-twins/{digital_twin}/audit-events'
 */
        indexForm.head = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const DigitalTwinAuditEventController = { index }

export default DigitalTwinAuditEventController