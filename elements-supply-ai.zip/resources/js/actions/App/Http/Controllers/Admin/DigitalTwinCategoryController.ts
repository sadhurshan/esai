import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::index
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:24
 * @route '/api/admin/digital-twin-categories'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/digital-twin-categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::index
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:24
 * @route '/api/admin/digital-twin-categories'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::index
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:24
 * @route '/api/admin/digital-twin-categories'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::index
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:24
 * @route '/api/admin/digital-twin-categories'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::index
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:24
 * @route '/api/admin/digital-twin-categories'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::index
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:24
 * @route '/api/admin/digital-twin-categories'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::index
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:24
 * @route '/api/admin/digital-twin-categories'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::store
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:56
 * @route '/api/admin/digital-twin-categories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/digital-twin-categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::store
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:56
 * @route '/api/admin/digital-twin-categories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::store
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:56
 * @route '/api/admin/digital-twin-categories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::store
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:56
 * @route '/api/admin/digital-twin-categories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::store
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:56
 * @route '/api/admin/digital-twin-categories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::show
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:67
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
export const show = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/admin/digital-twin-categories/{digital_twin_category}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::show
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:67
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
show.url = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { digital_twin_category: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    digital_twin_category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        digital_twin_category: args.digital_twin_category,
                }

    return show.definition.url
            .replace('{digital_twin_category}', parsedArgs.digital_twin_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::show
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:67
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
show.get = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::show
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:67
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
show.head = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::show
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:67
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
    const showForm = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::show
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:67
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
        showForm.get = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::show
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:67
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
        showForm.head = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::update
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:76
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
export const update = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/admin/digital-twin-categories/{digital_twin_category}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::update
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:76
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
update.url = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { digital_twin_category: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    digital_twin_category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        digital_twin_category: args.digital_twin_category,
                }

    return update.definition.url
            .replace('{digital_twin_category}', parsedArgs.digital_twin_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::update
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:76
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
update.put = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::update
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:76
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
update.patch = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::update
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:76
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
    const updateForm = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::update
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:76
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
        updateForm.put = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::update
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:76
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
        updateForm.patch = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::destroy
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:87
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
export const destroy = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/digital-twin-categories/{digital_twin_category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::destroy
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:87
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
destroy.url = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { digital_twin_category: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    digital_twin_category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        digital_twin_category: args.digital_twin_category,
                }

    return destroy.definition.url
            .replace('{digital_twin_category}', parsedArgs.digital_twin_category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::destroy
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:87
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
destroy.delete = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::destroy
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:87
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
    const destroyForm = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DigitalTwinCategoryController::destroy
 * @see app/Http/Controllers/Admin/DigitalTwinCategoryController.php:87
 * @route '/api/admin/digital-twin-categories/{digital_twin_category}'
 */
        destroyForm.delete = (args: { digital_twin_category: string | number } | [digital_twin_category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DigitalTwinCategoryController = { index, store, show, update, destroy }

export default DigitalTwinCategoryController