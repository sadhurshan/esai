import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\RoleTemplateController::index
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:14
 * @route '/api/admin/roles'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/roles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\RoleTemplateController::index
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:14
 * @route '/api/admin/roles'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RoleTemplateController::index
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:14
 * @route '/api/admin/roles'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\RoleTemplateController::index
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:14
 * @route '/api/admin/roles'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\RoleTemplateController::index
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:14
 * @route '/api/admin/roles'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\RoleTemplateController::index
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:14
 * @route '/api/admin/roles'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\RoleTemplateController::index
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:14
 * @route '/api/admin/roles'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\RoleTemplateController::update
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:26
 * @route '/api/admin/roles/{roleTemplate}'
 */
export const update = (args: { roleTemplate: string | { slug: string } } | [roleTemplate: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/api/admin/roles/{roleTemplate}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\RoleTemplateController::update
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:26
 * @route '/api/admin/roles/{roleTemplate}'
 */
update.url = (args: { roleTemplate: string | { slug: string } } | [roleTemplate: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { roleTemplate: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { roleTemplate: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    roleTemplate: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        roleTemplate: typeof args.roleTemplate === 'object'
                ? args.roleTemplate.slug
                : args.roleTemplate,
                }

    return update.definition.url
            .replace('{roleTemplate}', parsedArgs.roleTemplate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RoleTemplateController::update
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:26
 * @route '/api/admin/roles/{roleTemplate}'
 */
update.patch = (args: { roleTemplate: string | { slug: string } } | [roleTemplate: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\RoleTemplateController::update
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:26
 * @route '/api/admin/roles/{roleTemplate}'
 */
    const updateForm = (args: { roleTemplate: string | { slug: string } } | [roleTemplate: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\RoleTemplateController::update
 * @see app/Http/Controllers/Admin/RoleTemplateController.php:26
 * @route '/api/admin/roles/{roleTemplate}'
 */
        updateForm.patch = (args: { roleTemplate: string | { slug: string } } | [roleTemplate: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const RoleTemplateController = { index, update }

export default RoleTemplateController