import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::index
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:19
 * @route '/api/admin/webhook-deliveries'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/webhook-deliveries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::index
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:19
 * @route '/api/admin/webhook-deliveries'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::index
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:19
 * @route '/api/admin/webhook-deliveries'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::index
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:19
 * @route '/api/admin/webhook-deliveries'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::index
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:19
 * @route '/api/admin/webhook-deliveries'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::index
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:19
 * @route '/api/admin/webhook-deliveries'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::index
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:19
 * @route '/api/admin/webhook-deliveries'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::retry
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:44
 * @route '/api/admin/webhook-deliveries/{delivery}/retry'
 */
export const retry = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retry.url(args, options),
    method: 'post',
})

retry.definition = {
    methods: ["post"],
    url: '/api/admin/webhook-deliveries/{delivery}/retry',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::retry
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:44
 * @route '/api/admin/webhook-deliveries/{delivery}/retry'
 */
retry.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { delivery: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    delivery: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        delivery: typeof args.delivery === 'object'
                ? args.delivery.id
                : args.delivery,
                }

    return retry.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::retry
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:44
 * @route '/api/admin/webhook-deliveries/{delivery}/retry'
 */
retry.post = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retry.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::retry
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:44
 * @route '/api/admin/webhook-deliveries/{delivery}/retry'
 */
    const retryForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: retry.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WebhookDeliveryController::retry
 * @see app/Http/Controllers/Admin/WebhookDeliveryController.php:44
 * @route '/api/admin/webhook-deliveries/{delivery}/retry'
 */
        retryForm.post = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: retry.url(args, options),
            method: 'post',
        })
    
    retry.form = retryForm
const WebhookDeliveryController = { index, retry }

export default WebhookDeliveryController