import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::index
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:22
 * @route '/api/admin/webhook-subscriptions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/webhook-subscriptions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::index
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:22
 * @route '/api/admin/webhook-subscriptions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::index
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:22
 * @route '/api/admin/webhook-subscriptions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::index
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:22
 * @route '/api/admin/webhook-subscriptions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::index
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:22
 * @route '/api/admin/webhook-subscriptions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::index
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:22
 * @route '/api/admin/webhook-subscriptions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::index
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:22
 * @route '/api/admin/webhook-subscriptions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::store
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:43
 * @route '/api/admin/webhook-subscriptions'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/webhook-subscriptions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::store
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:43
 * @route '/api/admin/webhook-subscriptions'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::store
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:43
 * @route '/api/admin/webhook-subscriptions'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::store
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:43
 * @route '/api/admin/webhook-subscriptions'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::store
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:43
 * @route '/api/admin/webhook-subscriptions'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::show
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:54
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
export const show = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/admin/webhook-subscriptions/{webhook_subscription}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::show
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:54
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
show.url = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { webhook_subscription: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    webhook_subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        webhook_subscription: args.webhook_subscription,
                }

    return show.definition.url
            .replace('{webhook_subscription}', parsedArgs.webhook_subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::show
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:54
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
show.get = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::show
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:54
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
show.head = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::show
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:54
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
    const showForm = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::show
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:54
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
        showForm.get = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::show
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:54
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
        showForm.head = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::update
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:63
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
export const update = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/admin/webhook-subscriptions/{webhook_subscription}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::update
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:63
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
update.url = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { webhook_subscription: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    webhook_subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        webhook_subscription: args.webhook_subscription,
                }

    return update.definition.url
            .replace('{webhook_subscription}', parsedArgs.webhook_subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::update
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:63
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
update.put = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::update
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:63
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
update.patch = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::update
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:63
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
    const updateForm = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::update
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:63
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
        updateForm.put = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::update
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:63
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
        updateForm.patch = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::destroy
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:72
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
export const destroy = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/webhook-subscriptions/{webhook_subscription}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::destroy
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:72
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
destroy.url = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { webhook_subscription: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    webhook_subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        webhook_subscription: args.webhook_subscription,
                }

    return destroy.definition.url
            .replace('{webhook_subscription}', parsedArgs.webhook_subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::destroy
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:72
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
destroy.delete = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::destroy
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:72
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
    const destroyForm = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::destroy
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:72
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}'
 */
        destroyForm.delete = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::test
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:81
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}/test'
 */
export const test = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(args, options),
    method: 'post',
})

test.definition = {
    methods: ["post"],
    url: '/api/admin/webhook-subscriptions/{webhook_subscription}/test',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::test
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:81
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}/test'
 */
test.url = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { webhook_subscription: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    webhook_subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        webhook_subscription: args.webhook_subscription,
                }

    return test.definition.url
            .replace('{webhook_subscription}', parsedArgs.webhook_subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::test
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:81
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}/test'
 */
test.post = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: test.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::test
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:81
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}/test'
 */
    const testForm = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: test.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\WebhookSubscriptionController::test
 * @see app/Http/Controllers/Admin/WebhookSubscriptionController.php:81
 * @route '/api/admin/webhook-subscriptions/{webhook_subscription}/test'
 */
        testForm.post = (args: { webhook_subscription: string | number } | [webhook_subscription: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: test.url(args, options),
            method: 'post',
        })
    
    test.form = testForm
const WebhookSubscriptionController = { index, store, show, update, destroy, test }

export default WebhookSubscriptionController