import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:22
 * @route '/api/admin/companies'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/companies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:22
 * @route '/api/admin/companies'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:22
 * @route '/api/admin/companies'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:22
 * @route '/api/admin/companies'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:22
 * @route '/api/admin/companies'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:22
 * @route '/api/admin/companies'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:22
 * @route '/api/admin/companies'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:53
 * @route '/api/admin/companies/{company}/approve'
 */
export const approve = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/admin/companies/{company}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:53
 * @route '/api/admin/companies/{company}/approve'
 */
approve.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return approve.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:53
 * @route '/api/admin/companies/{company}/approve'
 */
approve.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:53
 * @route '/api/admin/companies/{company}/approve'
 */
    const approveForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:53
 * @route '/api/admin/companies/{company}/approve'
 */
        approveForm.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:75
 * @route '/api/admin/companies/{company}/reject'
 */
export const reject = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/api/admin/companies/{company}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:75
 * @route '/api/admin/companies/{company}/reject'
 */
reject.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return reject.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:75
 * @route '/api/admin/companies/{company}/reject'
 */
reject.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:75
 * @route '/api/admin/companies/{company}/reject'
 */
    const rejectForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:75
 * @route '/api/admin/companies/{company}/reject'
 */
        rejectForm.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
const CompanyApprovalController = { index, approve, reject }

export default CompanyApprovalController