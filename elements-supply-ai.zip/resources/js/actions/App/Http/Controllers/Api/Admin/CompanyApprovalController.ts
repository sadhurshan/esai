import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/companies'
 */
const index9b8d03355d23eec0f4113aafb1da2d0a = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index9b8d03355d23eec0f4113aafb1da2d0a.url(options),
    method: 'get',
})

index9b8d03355d23eec0f4113aafb1da2d0a.definition = {
    methods: ["get","head"],
    url: '/api/admin/companies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/companies'
 */
index9b8d03355d23eec0f4113aafb1da2d0a.url = (options?: RouteQueryOptions) => {
    return index9b8d03355d23eec0f4113aafb1da2d0a.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/companies'
 */
index9b8d03355d23eec0f4113aafb1da2d0a.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index9b8d03355d23eec0f4113aafb1da2d0a.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/companies'
 */
index9b8d03355d23eec0f4113aafb1da2d0a.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index9b8d03355d23eec0f4113aafb1da2d0a.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/companies'
 */
    const index9b8d03355d23eec0f4113aafb1da2d0aForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index9b8d03355d23eec0f4113aafb1da2d0a.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/companies'
 */
        index9b8d03355d23eec0f4113aafb1da2d0aForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index9b8d03355d23eec0f4113aafb1da2d0a.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/companies'
 */
        index9b8d03355d23eec0f4113aafb1da2d0aForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index9b8d03355d23eec0f4113aafb1da2d0a.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index9b8d03355d23eec0f4113aafb1da2d0a.form = index9b8d03355d23eec0f4113aafb1da2d0aForm
    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/company-approvals'
 */
const index6c490ad250b2d30fd49ca04e8554644b = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index6c490ad250b2d30fd49ca04e8554644b.url(options),
    method: 'get',
})

index6c490ad250b2d30fd49ca04e8554644b.definition = {
    methods: ["get","head"],
    url: '/api/admin/company-approvals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/company-approvals'
 */
index6c490ad250b2d30fd49ca04e8554644b.url = (options?: RouteQueryOptions) => {
    return index6c490ad250b2d30fd49ca04e8554644b.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/company-approvals'
 */
index6c490ad250b2d30fd49ca04e8554644b.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index6c490ad250b2d30fd49ca04e8554644b.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/company-approvals'
 */
index6c490ad250b2d30fd49ca04e8554644b.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index6c490ad250b2d30fd49ca04e8554644b.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/company-approvals'
 */
    const index6c490ad250b2d30fd49ca04e8554644bForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index6c490ad250b2d30fd49ca04e8554644b.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/company-approvals'
 */
        index6c490ad250b2d30fd49ca04e8554644bForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index6c490ad250b2d30fd49ca04e8554644b.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::index
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:27
 * @route '/api/admin/company-approvals'
 */
        index6c490ad250b2d30fd49ca04e8554644bForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index6c490ad250b2d30fd49ca04e8554644b.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index6c490ad250b2d30fd49ca04e8554644b.form = index6c490ad250b2d30fd49ca04e8554644bForm

export const index = {
    '/api/admin/companies': index9b8d03355d23eec0f4113aafb1da2d0a,
    '/api/admin/company-approvals': index6c490ad250b2d30fd49ca04e8554644b,
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:67
 * @route '/api/admin/companies/{company}/approve'
 */
const approve58eed6142d7731efe35bfd12bc09214c = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve58eed6142d7731efe35bfd12bc09214c.url(args, options),
    method: 'post',
})

approve58eed6142d7731efe35bfd12bc09214c.definition = {
    methods: ["post"],
    url: '/api/admin/companies/{company}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:67
 * @route '/api/admin/companies/{company}/approve'
 */
approve58eed6142d7731efe35bfd12bc09214c.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return approve58eed6142d7731efe35bfd12bc09214c.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:67
 * @route '/api/admin/companies/{company}/approve'
 */
approve58eed6142d7731efe35bfd12bc09214c.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve58eed6142d7731efe35bfd12bc09214c.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:67
 * @route '/api/admin/companies/{company}/approve'
 */
    const approve58eed6142d7731efe35bfd12bc09214cForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve58eed6142d7731efe35bfd12bc09214c.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:67
 * @route '/api/admin/companies/{company}/approve'
 */
        approve58eed6142d7731efe35bfd12bc09214cForm.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve58eed6142d7731efe35bfd12bc09214c.url(args, options),
            method: 'post',
        })
    
    approve58eed6142d7731efe35bfd12bc09214c.form = approve58eed6142d7731efe35bfd12bc09214cForm
    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:67
 * @route '/api/admin/company-approvals/{company}/approve'
 */
const approvec33ff99ce8ca7e44a46ced07731f024d = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approvec33ff99ce8ca7e44a46ced07731f024d.url(args, options),
    method: 'post',
})

approvec33ff99ce8ca7e44a46ced07731f024d.definition = {
    methods: ["post"],
    url: '/api/admin/company-approvals/{company}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:67
 * @route '/api/admin/company-approvals/{company}/approve'
 */
approvec33ff99ce8ca7e44a46ced07731f024d.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return approvec33ff99ce8ca7e44a46ced07731f024d.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:67
 * @route '/api/admin/company-approvals/{company}/approve'
 */
approvec33ff99ce8ca7e44a46ced07731f024d.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approvec33ff99ce8ca7e44a46ced07731f024d.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:67
 * @route '/api/admin/company-approvals/{company}/approve'
 */
    const approvec33ff99ce8ca7e44a46ced07731f024dForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approvec33ff99ce8ca7e44a46ced07731f024d.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::approve
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:67
 * @route '/api/admin/company-approvals/{company}/approve'
 */
        approvec33ff99ce8ca7e44a46ced07731f024dForm.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approvec33ff99ce8ca7e44a46ced07731f024d.url(args, options),
            method: 'post',
        })
    
    approvec33ff99ce8ca7e44a46ced07731f024d.form = approvec33ff99ce8ca7e44a46ced07731f024dForm

export const approve = {
    '/api/admin/companies/{company}/approve': approve58eed6142d7731efe35bfd12bc09214c,
    '/api/admin/company-approvals/{company}/approve': approvec33ff99ce8ca7e44a46ced07731f024d,
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:88
 * @route '/api/admin/companies/{company}/reject'
 */
const reject0affd34b766f6631e42f3d543bcc32b4 = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject0affd34b766f6631e42f3d543bcc32b4.url(args, options),
    method: 'post',
})

reject0affd34b766f6631e42f3d543bcc32b4.definition = {
    methods: ["post"],
    url: '/api/admin/companies/{company}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:88
 * @route '/api/admin/companies/{company}/reject'
 */
reject0affd34b766f6631e42f3d543bcc32b4.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return reject0affd34b766f6631e42f3d543bcc32b4.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:88
 * @route '/api/admin/companies/{company}/reject'
 */
reject0affd34b766f6631e42f3d543bcc32b4.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject0affd34b766f6631e42f3d543bcc32b4.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:88
 * @route '/api/admin/companies/{company}/reject'
 */
    const reject0affd34b766f6631e42f3d543bcc32b4Form = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject0affd34b766f6631e42f3d543bcc32b4.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:88
 * @route '/api/admin/companies/{company}/reject'
 */
        reject0affd34b766f6631e42f3d543bcc32b4Form.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject0affd34b766f6631e42f3d543bcc32b4.url(args, options),
            method: 'post',
        })
    
    reject0affd34b766f6631e42f3d543bcc32b4.form = reject0affd34b766f6631e42f3d543bcc32b4Form
    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:88
 * @route '/api/admin/company-approvals/{company}/reject'
 */
const reject5140cde1b5e6d3aa5754f3911b357a9b = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject5140cde1b5e6d3aa5754f3911b357a9b.url(args, options),
    method: 'post',
})

reject5140cde1b5e6d3aa5754f3911b357a9b.definition = {
    methods: ["post"],
    url: '/api/admin/company-approvals/{company}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:88
 * @route '/api/admin/company-approvals/{company}/reject'
 */
reject5140cde1b5e6d3aa5754f3911b357a9b.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return reject5140cde1b5e6d3aa5754f3911b357a9b.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:88
 * @route '/api/admin/company-approvals/{company}/reject'
 */
reject5140cde1b5e6d3aa5754f3911b357a9b.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject5140cde1b5e6d3aa5754f3911b357a9b.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:88
 * @route '/api/admin/company-approvals/{company}/reject'
 */
    const reject5140cde1b5e6d3aa5754f3911b357a9bForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject5140cde1b5e6d3aa5754f3911b357a9b.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\CompanyApprovalController::reject
 * @see app/Http/Controllers/Api/Admin/CompanyApprovalController.php:88
 * @route '/api/admin/company-approvals/{company}/reject'
 */
        reject5140cde1b5e6d3aa5754f3911b357a9bForm.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject5140cde1b5e6d3aa5754f3911b357a9b.url(args, options),
            method: 'post',
        })
    
    reject5140cde1b5e6d3aa5754f3911b357a9b.form = reject5140cde1b5e6d3aa5754f3911b357a9bForm

export const reject = {
    '/api/admin/companies/{company}/reject': reject0affd34b766f6631e42f3d543bcc32b4,
    '/api/admin/company-approvals/{company}/reject': reject5140cde1b5e6d3aa5754f3911b357a9b,
}

const CompanyApprovalController = { index, approve, reject }

export default CompanyApprovalController