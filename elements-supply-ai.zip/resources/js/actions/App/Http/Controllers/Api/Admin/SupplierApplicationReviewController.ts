import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::index
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:18
 * @route '/api/admin/supplier-applications'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/supplier-applications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::index
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:18
 * @route '/api/admin/supplier-applications'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::index
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:18
 * @route '/api/admin/supplier-applications'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::index
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:18
 * @route '/api/admin/supplier-applications'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::index
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:18
 * @route '/api/admin/supplier-applications'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::index
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:18
 * @route '/api/admin/supplier-applications'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::index
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:18
 * @route '/api/admin/supplier-applications'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::approve
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:54
 * @route '/api/admin/supplier-applications/{application}/approve'
 */
export const approve = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/admin/supplier-applications/{application}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::approve
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:54
 * @route '/api/admin/supplier-applications/{application}/approve'
 */
approve.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { application: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    application: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        application: typeof args.application === 'object'
                ? args.application.id
                : args.application,
                }

    return approve.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::approve
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:54
 * @route '/api/admin/supplier-applications/{application}/approve'
 */
approve.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::approve
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:54
 * @route '/api/admin/supplier-applications/{application}/approve'
 */
    const approveForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::approve
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:54
 * @route '/api/admin/supplier-applications/{application}/approve'
 */
        approveForm.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::reject
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:84
 * @route '/api/admin/supplier-applications/{application}/reject'
 */
export const reject = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/api/admin/supplier-applications/{application}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::reject
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:84
 * @route '/api/admin/supplier-applications/{application}/reject'
 */
reject.url = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { application: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { application: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    application: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        application: typeof args.application === 'object'
                ? args.application.id
                : args.application,
                }

    return reject.definition.url
            .replace('{application}', parsedArgs.application.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::reject
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:84
 * @route '/api/admin/supplier-applications/{application}/reject'
 */
reject.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::reject
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:84
 * @route '/api/admin/supplier-applications/{application}/reject'
 */
    const rejectForm = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\SupplierApplicationReviewController::reject
 * @see app/Http/Controllers/Api/Admin/SupplierApplicationReviewController.php:84
 * @route '/api/admin/supplier-applications/{application}/reject'
 */
        rejectForm.post = (args: { application: number | { id: number } } | [application: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
const SupplierApplicationReviewController = { index, approve, reject }

export default SupplierApplicationReviewController