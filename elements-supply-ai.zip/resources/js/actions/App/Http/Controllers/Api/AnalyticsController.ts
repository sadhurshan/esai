import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\AnalyticsController::overview
 * @see app/Http/Controllers/Api/AnalyticsController.php:25
 * @route '/api/analytics/overview'
 */
export const overview = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: overview.url(options),
    method: 'get',
})

overview.definition = {
    methods: ["get","head"],
    url: '/api/analytics/overview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AnalyticsController::overview
 * @see app/Http/Controllers/Api/AnalyticsController.php:25
 * @route '/api/analytics/overview'
 */
overview.url = (options?: RouteQueryOptions) => {
    return overview.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AnalyticsController::overview
 * @see app/Http/Controllers/Api/AnalyticsController.php:25
 * @route '/api/analytics/overview'
 */
overview.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: overview.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\AnalyticsController::overview
 * @see app/Http/Controllers/Api/AnalyticsController.php:25
 * @route '/api/analytics/overview'
 */
overview.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: overview.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\AnalyticsController::overview
 * @see app/Http/Controllers/Api/AnalyticsController.php:25
 * @route '/api/analytics/overview'
 */
    const overviewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: overview.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\AnalyticsController::overview
 * @see app/Http/Controllers/Api/AnalyticsController.php:25
 * @route '/api/analytics/overview'
 */
        overviewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: overview.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\AnalyticsController::overview
 * @see app/Http/Controllers/Api/AnalyticsController.php:25
 * @route '/api/analytics/overview'
 */
        overviewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: overview.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    overview.form = overviewForm
/**
* @see \App\Http\Controllers\Api\AnalyticsController::generate
 * @see app/Http/Controllers/Api/AnalyticsController.php:95
 * @route '/api/analytics/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/api/analytics/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AnalyticsController::generate
 * @see app/Http/Controllers/Api/AnalyticsController.php:95
 * @route '/api/analytics/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AnalyticsController::generate
 * @see app/Http/Controllers/Api/AnalyticsController.php:95
 * @route '/api/analytics/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AnalyticsController::generate
 * @see app/Http/Controllers/Api/AnalyticsController.php:95
 * @route '/api/analytics/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AnalyticsController::generate
 * @see app/Http/Controllers/Api/AnalyticsController.php:95
 * @route '/api/analytics/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
const AnalyticsController = { overview, generate }

export default AnalyticsController