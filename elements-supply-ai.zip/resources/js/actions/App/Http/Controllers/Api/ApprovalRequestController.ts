import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::index
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:27
 * @route '/api/approvals/requests'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/approvals/requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::index
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:27
 * @route '/api/approvals/requests'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::index
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:27
 * @route '/api/approvals/requests'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::index
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:27
 * @route '/api/approvals/requests'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ApprovalRequestController::index
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:27
 * @route '/api/approvals/requests'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ApprovalRequestController::index
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:27
 * @route '/api/approvals/requests'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ApprovalRequestController::index
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:27
 * @route '/api/approvals/requests'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::show
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:114
 * @route '/api/approvals/requests/{approval}'
 */
export const show = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/approvals/requests/{approval}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::show
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:114
 * @route '/api/approvals/requests/{approval}'
 */
show.url = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approval: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { approval: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    approval: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        approval: typeof args.approval === 'object'
                ? args.approval.id
                : args.approval,
                }

    return show.definition.url
            .replace('{approval}', parsedArgs.approval.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::show
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:114
 * @route '/api/approvals/requests/{approval}'
 */
show.get = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::show
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:114
 * @route '/api/approvals/requests/{approval}'
 */
show.head = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ApprovalRequestController::show
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:114
 * @route '/api/approvals/requests/{approval}'
 */
    const showForm = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ApprovalRequestController::show
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:114
 * @route '/api/approvals/requests/{approval}'
 */
        showForm.get = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ApprovalRequestController::show
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:114
 * @route '/api/approvals/requests/{approval}'
 */
        showForm.head = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::action
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:123
 * @route '/api/approvals/requests/{approval}/action'
 */
export const action = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: action.url(args, options),
    method: 'post',
})

action.definition = {
    methods: ["post"],
    url: '/api/approvals/requests/{approval}/action',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::action
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:123
 * @route '/api/approvals/requests/{approval}/action'
 */
action.url = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { approval: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { approval: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    approval: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        approval: typeof args.approval === 'object'
                ? args.approval.id
                : args.approval,
                }

    return action.definition.url
            .replace('{approval}', parsedArgs.approval.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalRequestController::action
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:123
 * @route '/api/approvals/requests/{approval}/action'
 */
action.post = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: action.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ApprovalRequestController::action
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:123
 * @route '/api/approvals/requests/{approval}/action'
 */
    const actionForm = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: action.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ApprovalRequestController::action
 * @see app/Http/Controllers/Api/ApprovalRequestController.php:123
 * @route '/api/approvals/requests/{approval}/action'
 */
        actionForm.post = (args: { approval: number | { id: number } } | [approval: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: action.url(args, options),
            method: 'post',
        })
    
    action.form = actionForm
const ApprovalRequestController = { index, show, action }

export default ApprovalRequestController