import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::index
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:19
 * @route '/api/approvals/rules'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/approvals/rules',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::index
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:19
 * @route '/api/approvals/rules'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::index
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:19
 * @route '/api/approvals/rules'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::index
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:19
 * @route '/api/approvals/rules'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::index
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:19
 * @route '/api/approvals/rules'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::index
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:19
 * @route '/api/approvals/rules'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::index
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:19
 * @route '/api/approvals/rules'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::show
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:91
 * @route '/api/approvals/rules/{rule}'
 */
export const show = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/approvals/rules/{rule}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::show
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:91
 * @route '/api/approvals/rules/{rule}'
 */
show.url = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rule: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rule: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rule: typeof args.rule === 'object'
                ? args.rule.id
                : args.rule,
                }

    return show.definition.url
            .replace('{rule}', parsedArgs.rule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::show
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:91
 * @route '/api/approvals/rules/{rule}'
 */
show.get = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::show
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:91
 * @route '/api/approvals/rules/{rule}'
 */
show.head = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::show
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:91
 * @route '/api/approvals/rules/{rule}'
 */
    const showForm = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::show
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:91
 * @route '/api/approvals/rules/{rule}'
 */
        showForm.get = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::show
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:91
 * @route '/api/approvals/rules/{rule}'
 */
        showForm.head = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::store
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:64
 * @route '/api/approvals/rules'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/approvals/rules',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::store
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:64
 * @route '/api/approvals/rules'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::store
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:64
 * @route '/api/approvals/rules'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::store
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:64
 * @route '/api/approvals/rules'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::store
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:64
 * @route '/api/approvals/rules'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::update
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:102
 * @route '/api/approvals/rules/{rule}'
 */
export const update = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/approvals/rules/{rule}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::update
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:102
 * @route '/api/approvals/rules/{rule}'
 */
update.url = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rule: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rule: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rule: typeof args.rule === 'object'
                ? args.rule.id
                : args.rule,
                }

    return update.definition.url
            .replace('{rule}', parsedArgs.rule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::update
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:102
 * @route '/api/approvals/rules/{rule}'
 */
update.put = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::update
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:102
 * @route '/api/approvals/rules/{rule}'
 */
    const updateForm = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::update
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:102
 * @route '/api/approvals/rules/{rule}'
 */
        updateForm.put = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::destroy
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:122
 * @route '/api/approvals/rules/{rule}'
 */
export const destroy = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/approvals/rules/{rule}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::destroy
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:122
 * @route '/api/approvals/rules/{rule}'
 */
destroy.url = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rule: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rule: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rule: typeof args.rule === 'object'
                ? args.rule.id
                : args.rule,
                }

    return destroy.definition.url
            .replace('{rule}', parsedArgs.rule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ApprovalRuleController::destroy
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:122
 * @route '/api/approvals/rules/{rule}'
 */
destroy.delete = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::destroy
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:122
 * @route '/api/approvals/rules/{rule}'
 */
    const destroyForm = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ApprovalRuleController::destroy
 * @see app/Http/Controllers/Api/ApprovalRuleController.php:122
 * @route '/api/approvals/rules/{rule}'
 */
        destroyForm.delete = (args: { rule: number | { id: number } } | [rule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ApprovalRuleController = { index, show, store, update, destroy }

export default ApprovalRuleController