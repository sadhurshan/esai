import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\AwardLineController::store
 * @see app/Http/Controllers/Api/AwardLineController.php:25
 * @route '/api/awards'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/awards',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AwardLineController::store
 * @see app/Http/Controllers/Api/AwardLineController.php:25
 * @route '/api/awards'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AwardLineController::store
 * @see app/Http/Controllers/Api/AwardLineController.php:25
 * @route '/api/awards'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AwardLineController::store
 * @see app/Http/Controllers/Api/AwardLineController.php:25
 * @route '/api/awards'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AwardLineController::store
 * @see app/Http/Controllers/Api/AwardLineController.php:25
 * @route '/api/awards'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\AwardLineController::destroy
 * @see app/Http/Controllers/Api/AwardLineController.php:66
 * @route '/api/awards/{award}'
 */
export const destroy = (args: { award: number | { id: number } } | [award: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/awards/{award}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\AwardLineController::destroy
 * @see app/Http/Controllers/Api/AwardLineController.php:66
 * @route '/api/awards/{award}'
 */
destroy.url = (args: { award: number | { id: number } } | [award: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { award: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { award: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    award: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        award: typeof args.award === 'object'
                ? args.award.id
                : args.award,
                }

    return destroy.definition.url
            .replace('{award}', parsedArgs.award.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AwardLineController::destroy
 * @see app/Http/Controllers/Api/AwardLineController.php:66
 * @route '/api/awards/{award}'
 */
destroy.delete = (args: { award: number | { id: number } } | [award: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\AwardLineController::destroy
 * @see app/Http/Controllers/Api/AwardLineController.php:66
 * @route '/api/awards/{award}'
 */
    const destroyForm = (args: { award: number | { id: number } } | [award: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AwardLineController::destroy
 * @see app/Http/Controllers/Api/AwardLineController.php:66
 * @route '/api/awards/{award}'
 */
        destroyForm.delete = (args: { award: number | { id: number } } | [award: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const AwardLineController = { store, destroy }

export default AwardLineController