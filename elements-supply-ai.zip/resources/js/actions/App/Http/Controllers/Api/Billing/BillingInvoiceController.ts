import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Billing\BillingInvoiceController::index
 * @see app/Http/Controllers/Api/Billing/BillingInvoiceController.php:18
 * @route '/api/billing/invoices'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/billing/invoices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Billing\BillingInvoiceController::index
 * @see app/Http/Controllers/Api/Billing/BillingInvoiceController.php:18
 * @route '/api/billing/invoices'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Billing\BillingInvoiceController::index
 * @see app/Http/Controllers/Api/Billing/BillingInvoiceController.php:18
 * @route '/api/billing/invoices'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Billing\BillingInvoiceController::index
 * @see app/Http/Controllers/Api/Billing/BillingInvoiceController.php:18
 * @route '/api/billing/invoices'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Billing\BillingInvoiceController::index
 * @see app/Http/Controllers/Api/Billing/BillingInvoiceController.php:18
 * @route '/api/billing/invoices'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Billing\BillingInvoiceController::index
 * @see app/Http/Controllers/Api/Billing/BillingInvoiceController.php:18
 * @route '/api/billing/invoices'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Billing\BillingInvoiceController::index
 * @see app/Http/Controllers/Api/Billing/BillingInvoiceController.php:18
 * @route '/api/billing/invoices'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const BillingInvoiceController = { index }

export default BillingInvoiceController