import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Billing\BillingPortalController::store
 * @see app/Http/Controllers/Api/Billing/BillingPortalController.php:18
 * @route '/api/billing/portal'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/billing/portal',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Billing\BillingPortalController::store
 * @see app/Http/Controllers/Api/Billing/BillingPortalController.php:18
 * @route '/api/billing/portal'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Billing\BillingPortalController::store
 * @see app/Http/Controllers/Api/Billing/BillingPortalController.php:18
 * @route '/api/billing/portal'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Billing\BillingPortalController::store
 * @see app/Http/Controllers/Api/Billing/BillingPortalController.php:18
 * @route '/api/billing/portal'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Billing\BillingPortalController::store
 * @see app/Http/Controllers/Api/Billing/BillingPortalController.php:18
 * @route '/api/billing/portal'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const BillingPortalController = { store }

export default BillingPortalController