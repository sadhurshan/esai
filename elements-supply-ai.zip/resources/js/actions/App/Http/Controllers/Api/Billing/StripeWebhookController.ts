import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::invoicePaymentSucceeded
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:12
 * @route '/api/webhooks/stripe/invoice/payment-succeeded'
 */
export const invoicePaymentSucceeded = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invoicePaymentSucceeded.url(options),
    method: 'post',
})

invoicePaymentSucceeded.definition = {
    methods: ["post"],
    url: '/api/webhooks/stripe/invoice/payment-succeeded',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::invoicePaymentSucceeded
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:12
 * @route '/api/webhooks/stripe/invoice/payment-succeeded'
 */
invoicePaymentSucceeded.url = (options?: RouteQueryOptions) => {
    return invoicePaymentSucceeded.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::invoicePaymentSucceeded
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:12
 * @route '/api/webhooks/stripe/invoice/payment-succeeded'
 */
invoicePaymentSucceeded.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invoicePaymentSucceeded.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::invoicePaymentSucceeded
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:12
 * @route '/api/webhooks/stripe/invoice/payment-succeeded'
 */
    const invoicePaymentSucceededForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: invoicePaymentSucceeded.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::invoicePaymentSucceeded
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:12
 * @route '/api/webhooks/stripe/invoice/payment-succeeded'
 */
        invoicePaymentSucceededForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: invoicePaymentSucceeded.url(options),
            method: 'post',
        })
    
    invoicePaymentSucceeded.form = invoicePaymentSucceededForm
/**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::invoicePaymentFailed
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:20
 * @route '/api/webhooks/stripe/invoice/payment-failed'
 */
export const invoicePaymentFailed = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invoicePaymentFailed.url(options),
    method: 'post',
})

invoicePaymentFailed.definition = {
    methods: ["post"],
    url: '/api/webhooks/stripe/invoice/payment-failed',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::invoicePaymentFailed
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:20
 * @route '/api/webhooks/stripe/invoice/payment-failed'
 */
invoicePaymentFailed.url = (options?: RouteQueryOptions) => {
    return invoicePaymentFailed.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::invoicePaymentFailed
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:20
 * @route '/api/webhooks/stripe/invoice/payment-failed'
 */
invoicePaymentFailed.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: invoicePaymentFailed.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::invoicePaymentFailed
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:20
 * @route '/api/webhooks/stripe/invoice/payment-failed'
 */
    const invoicePaymentFailedForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: invoicePaymentFailed.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::invoicePaymentFailed
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:20
 * @route '/api/webhooks/stripe/invoice/payment-failed'
 */
        invoicePaymentFailedForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: invoicePaymentFailed.url(options),
            method: 'post',
        })
    
    invoicePaymentFailed.form = invoicePaymentFailedForm
/**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::customerSubscriptionUpdated
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:28
 * @route '/api/webhooks/stripe/customer/subscription-updated'
 */
export const customerSubscriptionUpdated = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: customerSubscriptionUpdated.url(options),
    method: 'post',
})

customerSubscriptionUpdated.definition = {
    methods: ["post"],
    url: '/api/webhooks/stripe/customer/subscription-updated',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::customerSubscriptionUpdated
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:28
 * @route '/api/webhooks/stripe/customer/subscription-updated'
 */
customerSubscriptionUpdated.url = (options?: RouteQueryOptions) => {
    return customerSubscriptionUpdated.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::customerSubscriptionUpdated
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:28
 * @route '/api/webhooks/stripe/customer/subscription-updated'
 */
customerSubscriptionUpdated.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: customerSubscriptionUpdated.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::customerSubscriptionUpdated
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:28
 * @route '/api/webhooks/stripe/customer/subscription-updated'
 */
    const customerSubscriptionUpdatedForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: customerSubscriptionUpdated.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Billing\StripeWebhookController::customerSubscriptionUpdated
 * @see app/Http/Controllers/Api/Billing/StripeWebhookController.php:28
 * @route '/api/webhooks/stripe/customer/subscription-updated'
 */
        customerSubscriptionUpdatedForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: customerSubscriptionUpdated.url(options),
            method: 'post',
        })
    
    customerSubscriptionUpdated.form = customerSubscriptionUpdatedForm
const StripeWebhookController = { invoicePaymentSucceeded, invoicePaymentFailed, customerSubscriptionUpdated }

export default StripeWebhookController