import StripeWebhookController from './StripeWebhookController'
const Billing = {
    StripeWebhookController: Object.assign(StripeWebhookController, StripeWebhookController),
}

export default Billing