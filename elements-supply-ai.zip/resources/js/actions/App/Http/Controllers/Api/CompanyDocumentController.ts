import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CompanyDocumentController::index
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:21
 * @route '/api/companies/{company}/documents'
 */
export const index = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/companies/{company}/documents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CompanyDocumentController::index
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:21
 * @route '/api/companies/{company}/documents'
 */
index.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return index.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyDocumentController::index
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:21
 * @route '/api/companies/{company}/documents'
 */
index.get = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\CompanyDocumentController::index
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:21
 * @route '/api/companies/{company}/documents'
 */
index.head = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\CompanyDocumentController::index
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:21
 * @route '/api/companies/{company}/documents'
 */
    const indexForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyDocumentController::index
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:21
 * @route '/api/companies/{company}/documents'
 */
        indexForm.get = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\CompanyDocumentController::index
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:21
 * @route '/api/companies/{company}/documents'
 */
        indexForm.head = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\CompanyDocumentController::store
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:40
 * @route '/api/companies/{company}/documents'
 */
export const store = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/companies/{company}/documents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CompanyDocumentController::store
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:40
 * @route '/api/companies/{company}/documents'
 */
store.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return store.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyDocumentController::store
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:40
 * @route '/api/companies/{company}/documents'
 */
store.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CompanyDocumentController::store
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:40
 * @route '/api/companies/{company}/documents'
 */
    const storeForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyDocumentController::store
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:40
 * @route '/api/companies/{company}/documents'
 */
        storeForm.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\CompanyDocumentController::destroy
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:62
 * @route '/api/companies/{company}/documents/{document}'
 */
export const destroy = (args: { company: number | { id: number }, document: number | { id: number } } | [company: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/companies/{company}/documents/{document}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\CompanyDocumentController::destroy
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:62
 * @route '/api/companies/{company}/documents/{document}'
 */
destroy.url = (args: { company: number | { id: number }, document: number | { id: number } } | [company: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                    document: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                                document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return destroy.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyDocumentController::destroy
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:62
 * @route '/api/companies/{company}/documents/{document}'
 */
destroy.delete = (args: { company: number | { id: number }, document: number | { id: number } } | [company: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\CompanyDocumentController::destroy
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:62
 * @route '/api/companies/{company}/documents/{document}'
 */
    const destroyForm = (args: { company: number | { id: number }, document: number | { id: number } } | [company: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyDocumentController::destroy
 * @see app/Http/Controllers/Api/CompanyDocumentController.php:62
 * @route '/api/companies/{company}/documents/{document}'
 */
        destroyForm.delete = (args: { company: number | { id: number }, document: number | { id: number } } | [company: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const CompanyDocumentController = { index, store, destroy }

export default CompanyDocumentController