import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CreditNoteController::index
 * @see app/Http/Controllers/Api/CreditNoteController.php:31
 * @route '/api/credit-notes'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/credit-notes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CreditNoteController::index
 * @see app/Http/Controllers/Api/CreditNoteController.php:31
 * @route '/api/credit-notes'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CreditNoteController::index
 * @see app/Http/Controllers/Api/CreditNoteController.php:31
 * @route '/api/credit-notes'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\CreditNoteController::index
 * @see app/Http/Controllers/Api/CreditNoteController.php:31
 * @route '/api/credit-notes'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\CreditNoteController::index
 * @see app/Http/Controllers/Api/CreditNoteController.php:31
 * @route '/api/credit-notes'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\CreditNoteController::index
 * @see app/Http/Controllers/Api/CreditNoteController.php:31
 * @route '/api/credit-notes'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\CreditNoteController::index
 * @see app/Http/Controllers/Api/CreditNoteController.php:31
 * @route '/api/credit-notes'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\CreditNoteController::store
 * @see app/Http/Controllers/Api/CreditNoteController.php:106
 * @route '/api/credit-notes/invoices/{invoice}'
 */
export const store = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/credit-notes/invoices/{invoice}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CreditNoteController::store
 * @see app/Http/Controllers/Api/CreditNoteController.php:106
 * @route '/api/credit-notes/invoices/{invoice}'
 */
store.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return store.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CreditNoteController::store
 * @see app/Http/Controllers/Api/CreditNoteController.php:106
 * @route '/api/credit-notes/invoices/{invoice}'
 */
store.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CreditNoteController::store
 * @see app/Http/Controllers/Api/CreditNoteController.php:106
 * @route '/api/credit-notes/invoices/{invoice}'
 */
    const storeForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CreditNoteController::store
 * @see app/Http/Controllers/Api/CreditNoteController.php:106
 * @route '/api/credit-notes/invoices/{invoice}'
 */
        storeForm.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\CreditNoteController::show
 * @see app/Http/Controllers/Api/CreditNoteController.php:154
 * @route '/api/credit-notes/{creditNote}'
 */
export const show = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/credit-notes/{creditNote}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CreditNoteController::show
 * @see app/Http/Controllers/Api/CreditNoteController.php:154
 * @route '/api/credit-notes/{creditNote}'
 */
show.url = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { creditNote: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { creditNote: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    creditNote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        creditNote: typeof args.creditNote === 'object'
                ? args.creditNote.id
                : args.creditNote,
                }

    return show.definition.url
            .replace('{creditNote}', parsedArgs.creditNote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CreditNoteController::show
 * @see app/Http/Controllers/Api/CreditNoteController.php:154
 * @route '/api/credit-notes/{creditNote}'
 */
show.get = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\CreditNoteController::show
 * @see app/Http/Controllers/Api/CreditNoteController.php:154
 * @route '/api/credit-notes/{creditNote}'
 */
show.head = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\CreditNoteController::show
 * @see app/Http/Controllers/Api/CreditNoteController.php:154
 * @route '/api/credit-notes/{creditNote}'
 */
    const showForm = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\CreditNoteController::show
 * @see app/Http/Controllers/Api/CreditNoteController.php:154
 * @route '/api/credit-notes/{creditNote}'
 */
        showForm.get = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\CreditNoteController::show
 * @see app/Http/Controllers/Api/CreditNoteController.php:154
 * @route '/api/credit-notes/{creditNote}'
 */
        showForm.head = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\CreditNoteController::issue
 * @see app/Http/Controllers/Api/CreditNoteController.php:177
 * @route '/api/credit-notes/{creditNote}/issue'
 */
export const issue = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: issue.url(args, options),
    method: 'post',
})

issue.definition = {
    methods: ["post"],
    url: '/api/credit-notes/{creditNote}/issue',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CreditNoteController::issue
 * @see app/Http/Controllers/Api/CreditNoteController.php:177
 * @route '/api/credit-notes/{creditNote}/issue'
 */
issue.url = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { creditNote: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { creditNote: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    creditNote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        creditNote: typeof args.creditNote === 'object'
                ? args.creditNote.id
                : args.creditNote,
                }

    return issue.definition.url
            .replace('{creditNote}', parsedArgs.creditNote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CreditNoteController::issue
 * @see app/Http/Controllers/Api/CreditNoteController.php:177
 * @route '/api/credit-notes/{creditNote}/issue'
 */
issue.post = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: issue.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CreditNoteController::issue
 * @see app/Http/Controllers/Api/CreditNoteController.php:177
 * @route '/api/credit-notes/{creditNote}/issue'
 */
    const issueForm = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: issue.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CreditNoteController::issue
 * @see app/Http/Controllers/Api/CreditNoteController.php:177
 * @route '/api/credit-notes/{creditNote}/issue'
 */
        issueForm.post = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: issue.url(args, options),
            method: 'post',
        })
    
    issue.form = issueForm
/**
* @see \App\Http\Controllers\Api\CreditNoteController::approve
 * @see app/Http/Controllers/Api/CreditNoteController.php:211
 * @route '/api/credit-notes/{creditNote}/approve'
 */
export const approve = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/credit-notes/{creditNote}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CreditNoteController::approve
 * @see app/Http/Controllers/Api/CreditNoteController.php:211
 * @route '/api/credit-notes/{creditNote}/approve'
 */
approve.url = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { creditNote: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { creditNote: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    creditNote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        creditNote: typeof args.creditNote === 'object'
                ? args.creditNote.id
                : args.creditNote,
                }

    return approve.definition.url
            .replace('{creditNote}', parsedArgs.creditNote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CreditNoteController::approve
 * @see app/Http/Controllers/Api/CreditNoteController.php:211
 * @route '/api/credit-notes/{creditNote}/approve'
 */
approve.post = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CreditNoteController::approve
 * @see app/Http/Controllers/Api/CreditNoteController.php:211
 * @route '/api/credit-notes/{creditNote}/approve'
 */
    const approveForm = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CreditNoteController::approve
 * @see app/Http/Controllers/Api/CreditNoteController.php:211
 * @route '/api/credit-notes/{creditNote}/approve'
 */
        approveForm.post = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Api\CreditNoteController::updateLines
 * @see app/Http/Controllers/Api/CreditNoteController.php:254
 * @route '/api/credit-notes/{creditNote}/lines'
 */
export const updateLines = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateLines.url(args, options),
    method: 'put',
})

updateLines.definition = {
    methods: ["put"],
    url: '/api/credit-notes/{creditNote}/lines',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\CreditNoteController::updateLines
 * @see app/Http/Controllers/Api/CreditNoteController.php:254
 * @route '/api/credit-notes/{creditNote}/lines'
 */
updateLines.url = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { creditNote: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { creditNote: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    creditNote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        creditNote: typeof args.creditNote === 'object'
                ? args.creditNote.id
                : args.creditNote,
                }

    return updateLines.definition.url
            .replace('{creditNote}', parsedArgs.creditNote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CreditNoteController::updateLines
 * @see app/Http/Controllers/Api/CreditNoteController.php:254
 * @route '/api/credit-notes/{creditNote}/lines'
 */
updateLines.put = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateLines.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\CreditNoteController::updateLines
 * @see app/Http/Controllers/Api/CreditNoteController.php:254
 * @route '/api/credit-notes/{creditNote}/lines'
 */
    const updateLinesForm = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateLines.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CreditNoteController::updateLines
 * @see app/Http/Controllers/Api/CreditNoteController.php:254
 * @route '/api/credit-notes/{creditNote}/lines'
 */
        updateLinesForm.put = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateLines.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateLines.form = updateLinesForm
/**
* @see \App\Http\Controllers\Api\CreditNoteController::attachFile
 * @see app/Http/Controllers/Api/CreditNoteController.php:287
 * @route '/api/credit-notes/{creditNote}/attachments'
 */
export const attachFile = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: attachFile.url(args, options),
    method: 'post',
})

attachFile.definition = {
    methods: ["post"],
    url: '/api/credit-notes/{creditNote}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CreditNoteController::attachFile
 * @see app/Http/Controllers/Api/CreditNoteController.php:287
 * @route '/api/credit-notes/{creditNote}/attachments'
 */
attachFile.url = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { creditNote: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { creditNote: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    creditNote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        creditNote: typeof args.creditNote === 'object'
                ? args.creditNote.id
                : args.creditNote,
                }

    return attachFile.definition.url
            .replace('{creditNote}', parsedArgs.creditNote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CreditNoteController::attachFile
 * @see app/Http/Controllers/Api/CreditNoteController.php:287
 * @route '/api/credit-notes/{creditNote}/attachments'
 */
attachFile.post = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: attachFile.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CreditNoteController::attachFile
 * @see app/Http/Controllers/Api/CreditNoteController.php:287
 * @route '/api/credit-notes/{creditNote}/attachments'
 */
    const attachFileForm = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: attachFile.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CreditNoteController::attachFile
 * @see app/Http/Controllers/Api/CreditNoteController.php:287
 * @route '/api/credit-notes/{creditNote}/attachments'
 */
        attachFileForm.post = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: attachFile.url(args, options),
            method: 'post',
        })
    
    attachFile.form = attachFileForm
const CreditNoteController = { index, store, show, issue, approve, updateLines, attachFile }

export default CreditNoteController