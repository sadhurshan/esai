import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::link
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:21
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}'
 */
export const link = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: link.url(args, options),
    method: 'put',
})

link.definition = {
    methods: ["put"],
    url: '/api/digital-twin/assets/{asset}/procedures/{procedure}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::link
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:21
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}'
 */
link.url = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                    procedure: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                                procedure: typeof args.procedure === 'object'
                ? args.procedure.id
                : args.procedure,
                }

    return link.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace('{procedure}', parsedArgs.procedure.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::link
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:21
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}'
 */
link.put = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: link.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::link
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:21
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}'
 */
    const linkForm = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: link.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::link
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:21
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}'
 */
        linkForm.put = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: link.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    link.form = linkForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::detach
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:37
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}'
 */
export const detach = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: detach.url(args, options),
    method: 'delete',
})

detach.definition = {
    methods: ["delete"],
    url: '/api/digital-twin/assets/{asset}/procedures/{procedure}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::detach
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:37
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}'
 */
detach.url = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                    procedure: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                                procedure: typeof args.procedure === 'object'
                ? args.procedure.id
                : args.procedure,
                }

    return detach.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace('{procedure}', parsedArgs.procedure.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::detach
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:37
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}'
 */
detach.delete = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: detach.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::detach
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:37
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}'
 */
    const detachForm = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: detach.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::detach
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:37
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}'
 */
        detachForm.delete = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: detach.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    detach.form = detachForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::complete
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:50
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}/complete'
 */
export const complete = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/api/digital-twin/assets/{asset}/procedures/{procedure}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::complete
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:50
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}/complete'
 */
complete.url = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                    procedure: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                                procedure: typeof args.procedure === 'object'
                ? args.procedure.id
                : args.procedure,
                }

    return complete.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace('{procedure}', parsedArgs.procedure.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::complete
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:50
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}/complete'
 */
complete.post = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::complete
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:50
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}/complete'
 */
    const completeForm = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetMaintenanceController::complete
 * @see app/Http/Controllers/Api/DigitalTwin/AssetMaintenanceController.php:50
 * @route '/api/digital-twin/assets/{asset}/procedures/{procedure}/complete'
 */
        completeForm.post = (args: { asset: number | { id: number }, procedure: number | { id: number } } | [asset: number | { id: number }, procedure: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, options),
            method: 'post',
        })
    
    complete.form = completeForm
const AssetMaintenanceController = { link, detach, complete }

export default AssetMaintenanceController