import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::index
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:23
 * @route '/api/digital-twin/locations'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/digital-twin/locations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::index
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:23
 * @route '/api/digital-twin/locations'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::index
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:23
 * @route '/api/digital-twin/locations'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::index
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:23
 * @route '/api/digital-twin/locations'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::index
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:23
 * @route '/api/digital-twin/locations'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::index
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:23
 * @route '/api/digital-twin/locations'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::index
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:23
 * @route '/api/digital-twin/locations'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::store
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:77
 * @route '/api/digital-twin/locations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/digital-twin/locations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::store
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:77
 * @route '/api/digital-twin/locations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::store
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:77
 * @route '/api/digital-twin/locations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::store
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:77
 * @route '/api/digital-twin/locations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::store
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:77
 * @route '/api/digital-twin/locations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::show
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:109
 * @route '/api/digital-twin/locations/{location}'
 */
export const show = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/digital-twin/locations/{location}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::show
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:109
 * @route '/api/digital-twin/locations/{location}'
 */
show.url = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { location: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { location: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    location: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        location: typeof args.location === 'object'
                ? args.location.id
                : args.location,
                }

    return show.definition.url
            .replace('{location}', parsedArgs.location.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::show
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:109
 * @route '/api/digital-twin/locations/{location}'
 */
show.get = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::show
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:109
 * @route '/api/digital-twin/locations/{location}'
 */
show.head = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::show
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:109
 * @route '/api/digital-twin/locations/{location}'
 */
    const showForm = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::show
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:109
 * @route '/api/digital-twin/locations/{location}'
 */
        showForm.get = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::show
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:109
 * @route '/api/digital-twin/locations/{location}'
 */
        showForm.head = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::update
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:121
 * @route '/api/digital-twin/locations/{location}'
 */
export const update = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/digital-twin/locations/{location}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::update
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:121
 * @route '/api/digital-twin/locations/{location}'
 */
update.url = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { location: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { location: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    location: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        location: typeof args.location === 'object'
                ? args.location.id
                : args.location,
                }

    return update.definition.url
            .replace('{location}', parsedArgs.location.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::update
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:121
 * @route '/api/digital-twin/locations/{location}'
 */
update.put = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::update
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:121
 * @route '/api/digital-twin/locations/{location}'
 */
update.patch = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::update
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:121
 * @route '/api/digital-twin/locations/{location}'
 */
    const updateForm = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::update
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:121
 * @route '/api/digital-twin/locations/{location}'
 */
        updateForm.put = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::update
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:121
 * @route '/api/digital-twin/locations/{location}'
 */
        updateForm.patch = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::destroy
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:140
 * @route '/api/digital-twin/locations/{location}'
 */
export const destroy = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/digital-twin/locations/{location}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::destroy
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:140
 * @route '/api/digital-twin/locations/{location}'
 */
destroy.url = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { location: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { location: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    location: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        location: typeof args.location === 'object'
                ? args.location.id
                : args.location,
                }

    return destroy.definition.url
            .replace('{location}', parsedArgs.location.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::destroy
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:140
 * @route '/api/digital-twin/locations/{location}'
 */
destroy.delete = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::destroy
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:140
 * @route '/api/digital-twin/locations/{location}'
 */
    const destroyForm = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\LocationController::destroy
 * @see app/Http/Controllers/Api/DigitalTwin/LocationController.php:140
 * @route '/api/digital-twin/locations/{location}'
 */
        destroyForm.delete = (args: { location: number | { id: number } } | [location: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const LocationController = { index, store, show, update, destroy }

export default LocationController