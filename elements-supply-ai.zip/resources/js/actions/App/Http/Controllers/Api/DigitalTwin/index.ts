import LocationController from './LocationController'
import SystemController from './SystemController'
import AssetController from './AssetController'
import AssetBomController from './AssetBomController'
import AssetMaintenanceController from './AssetMaintenanceController'
import MaintenanceProcedureController from './MaintenanceProcedureController'
const DigitalTwin = {
    LocationController: Object.assign(LocationController, LocationController),
SystemController: Object.assign(SystemController, SystemController),
AssetController: Object.assign(AssetController, AssetController),
AssetBomController: Object.assign(AssetBomController, AssetBomController),
AssetMaintenanceController: Object.assign(AssetMaintenanceController, AssetMaintenanceController),
MaintenanceProcedureController: Object.assign(MaintenanceProcedureController, MaintenanceProcedureController),
}

export default DigitalTwin