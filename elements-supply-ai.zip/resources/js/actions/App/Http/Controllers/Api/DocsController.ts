import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DocsController::openApi
 * @see app/Http/Controllers/Api/DocsController.php:11
 * @route '/api/docs/openapi.json'
 */
export const openApi = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: openApi.url(options),
    method: 'get',
})

openApi.definition = {
    methods: ["get","head"],
    url: '/api/docs/openapi.json',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DocsController::openApi
 * @see app/Http/Controllers/Api/DocsController.php:11
 * @route '/api/docs/openapi.json'
 */
openApi.url = (options?: RouteQueryOptions) => {
    return openApi.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DocsController::openApi
 * @see app/Http/Controllers/Api/DocsController.php:11
 * @route '/api/docs/openapi.json'
 */
openApi.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: openApi.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DocsController::openApi
 * @see app/Http/Controllers/Api/DocsController.php:11
 * @route '/api/docs/openapi.json'
 */
openApi.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: openApi.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DocsController::openApi
 * @see app/Http/Controllers/Api/DocsController.php:11
 * @route '/api/docs/openapi.json'
 */
    const openApiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: openApi.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DocsController::openApi
 * @see app/Http/Controllers/Api/DocsController.php:11
 * @route '/api/docs/openapi.json'
 */
        openApiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: openApi.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DocsController::openApi
 * @see app/Http/Controllers/Api/DocsController.php:11
 * @route '/api/docs/openapi.json'
 */
        openApiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: openApi.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    openApi.form = openApiForm
/**
* @see \App\Http\Controllers\Api\DocsController::postman
 * @see app/Http/Controllers/Api/DocsController.php:16
 * @route '/api/docs/postman.json'
 */
export const postman = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: postman.url(options),
    method: 'get',
})

postman.definition = {
    methods: ["get","head"],
    url: '/api/docs/postman.json',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DocsController::postman
 * @see app/Http/Controllers/Api/DocsController.php:16
 * @route '/api/docs/postman.json'
 */
postman.url = (options?: RouteQueryOptions) => {
    return postman.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DocsController::postman
 * @see app/Http/Controllers/Api/DocsController.php:16
 * @route '/api/docs/postman.json'
 */
postman.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: postman.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DocsController::postman
 * @see app/Http/Controllers/Api/DocsController.php:16
 * @route '/api/docs/postman.json'
 */
postman.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: postman.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DocsController::postman
 * @see app/Http/Controllers/Api/DocsController.php:16
 * @route '/api/docs/postman.json'
 */
    const postmanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: postman.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DocsController::postman
 * @see app/Http/Controllers/Api/DocsController.php:16
 * @route '/api/docs/postman.json'
 */
        postmanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: postman.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DocsController::postman
 * @see app/Http/Controllers/Api/DocsController.php:16
 * @route '/api/docs/postman.json'
 */
        postmanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: postman.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    postman.form = postmanForm
const DocsController = { openApi, postman }

export default DocsController