import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\FileController::cad
 * @see app/Http/Controllers/Api/FileController.php:13
 * @route '/api/files/cad/{rfq}'
 */
export const cad = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cad.url(args, options),
    method: 'get',
})

cad.definition = {
    methods: ["get","head"],
    url: '/api/files/cad/{rfq}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\FileController::cad
 * @see app/Http/Controllers/Api/FileController.php:13
 * @route '/api/files/cad/{rfq}'
 */
cad.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return cad.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FileController::cad
 * @see app/Http/Controllers/Api/FileController.php:13
 * @route '/api/files/cad/{rfq}'
 */
cad.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cad.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\FileController::cad
 * @see app/Http/Controllers/Api/FileController.php:13
 * @route '/api/files/cad/{rfq}'
 */
cad.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cad.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\FileController::cad
 * @see app/Http/Controllers/Api/FileController.php:13
 * @route '/api/files/cad/{rfq}'
 */
    const cadForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: cad.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\FileController::cad
 * @see app/Http/Controllers/Api/FileController.php:13
 * @route '/api/files/cad/{rfq}'
 */
        cadForm.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cad.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\FileController::cad
 * @see app/Http/Controllers/Api/FileController.php:13
 * @route '/api/files/cad/{rfq}'
 */
        cadForm.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cad.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    cad.form = cadForm
/**
* @see \App\Http\Controllers\Api\FileController::attachment
 * @see app/Http/Controllers/Api/FileController.php:22
 * @route '/api/files/attachments/{quote}'
 */
export const attachment = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attachment.url(args, options),
    method: 'get',
})

attachment.definition = {
    methods: ["get","head"],
    url: '/api/files/attachments/{quote}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\FileController::attachment
 * @see app/Http/Controllers/Api/FileController.php:22
 * @route '/api/files/attachments/{quote}'
 */
attachment.url = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { quote: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { quote: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    quote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                }

    return attachment.definition.url
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FileController::attachment
 * @see app/Http/Controllers/Api/FileController.php:22
 * @route '/api/files/attachments/{quote}'
 */
attachment.get = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: attachment.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\FileController::attachment
 * @see app/Http/Controllers/Api/FileController.php:22
 * @route '/api/files/attachments/{quote}'
 */
attachment.head = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: attachment.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\FileController::attachment
 * @see app/Http/Controllers/Api/FileController.php:22
 * @route '/api/files/attachments/{quote}'
 */
    const attachmentForm = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: attachment.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\FileController::attachment
 * @see app/Http/Controllers/Api/FileController.php:22
 * @route '/api/files/attachments/{quote}'
 */
        attachmentForm.get = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attachment.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\FileController::attachment
 * @see app/Http/Controllers/Api/FileController.php:22
 * @route '/api/files/attachments/{quote}'
 */
        attachmentForm.head = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: attachment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    attachment.form = attachmentForm
const FileController = { cad, attachment }

export default FileController