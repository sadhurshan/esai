import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::index
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:224
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
export const index = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/purchase-orders/{purchaseOrder}/grns',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::index
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:224
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
index.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return index.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::index
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:224
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
index.get = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::index
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:224
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
index.head = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::index
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:224
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
    const indexForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::index
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:224
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
        indexForm.get = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::index
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:224
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
        indexForm.head = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::show
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:316
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
export const show = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/purchase-orders/{purchaseOrder}/grns/{note}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::show
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:316
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
show.url = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                    note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                                note: args.note,
                }

    return show.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace('{note}', parsedArgs.note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::show
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:316
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
show.get = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::show
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:316
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
show.head = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::show
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:316
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
    const showForm = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::show
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:316
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
        showForm.get = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::show
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:316
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
        showForm.head = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::store
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:282
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
export const store = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/purchase-orders/{purchaseOrder}/grns',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::store
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:282
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
store.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return store.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::store
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:282
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
store.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::store
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:282
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
    const storeForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::store
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:282
 * @route '/api/purchase-orders/{purchaseOrder}/grns'
 */
        storeForm.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::update
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:353
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
export const update = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/purchase-orders/{purchaseOrder}/grns/{note}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::update
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:353
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
update.url = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                    note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                                note: args.note,
                }

    return update.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace('{note}', parsedArgs.note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::update
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:353
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
update.put = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::update
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:353
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
    const updateForm = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::update
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:353
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
        updateForm.put = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::destroy
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:395
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
export const destroy = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/purchase-orders/{purchaseOrder}/grns/{note}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::destroy
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:395
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
destroy.url = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                    note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                                note: args.note,
                }

    return destroy.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace('{note}', parsedArgs.note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::destroy
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:395
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
destroy.delete = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::destroy
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:395
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
    const destroyForm = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::destroy
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:395
 * @route '/api/purchase-orders/{purchaseOrder}/grns/{note}'
 */
        destroyForm.delete = (args: { purchaseOrder: number | { id: number }, note: string | number } | [purchaseOrder: number | { id: number }, note: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyIndex
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:29
 * @route '/api/receiving/grns'
 */
export const companyIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companyIndex.url(options),
    method: 'get',
})

companyIndex.definition = {
    methods: ["get","head"],
    url: '/api/receiving/grns',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyIndex
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:29
 * @route '/api/receiving/grns'
 */
companyIndex.url = (options?: RouteQueryOptions) => {
    return companyIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyIndex
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:29
 * @route '/api/receiving/grns'
 */
companyIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companyIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyIndex
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:29
 * @route '/api/receiving/grns'
 */
companyIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: companyIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyIndex
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:29
 * @route '/api/receiving/grns'
 */
    const companyIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: companyIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyIndex
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:29
 * @route '/api/receiving/grns'
 */
        companyIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companyIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyIndex
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:29
 * @route '/api/receiving/grns'
 */
        companyIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companyIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    companyIndex.form = companyIndexForm
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyShow
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:110
 * @route '/api/receiving/grns/{note}'
 */
export const companyShow = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companyShow.url(args, options),
    method: 'get',
})

companyShow.definition = {
    methods: ["get","head"],
    url: '/api/receiving/grns/{note}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyShow
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:110
 * @route '/api/receiving/grns/{note}'
 */
companyShow.url = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { note: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    note: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        note: args.note,
                }

    return companyShow.definition.url
            .replace('{note}', parsedArgs.note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyShow
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:110
 * @route '/api/receiving/grns/{note}'
 */
companyShow.get = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companyShow.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyShow
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:110
 * @route '/api/receiving/grns/{note}'
 */
companyShow.head = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: companyShow.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyShow
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:110
 * @route '/api/receiving/grns/{note}'
 */
    const companyShowForm = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: companyShow.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyShow
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:110
 * @route '/api/receiving/grns/{note}'
 */
        companyShowForm.get = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companyShow.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyShow
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:110
 * @route '/api/receiving/grns/{note}'
 */
        companyShowForm.head = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companyShow.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    companyShow.form = companyShowForm
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyStore
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:143
 * @route '/api/receiving/grns'
 */
export const companyStore = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: companyStore.url(options),
    method: 'post',
})

companyStore.definition = {
    methods: ["post"],
    url: '/api/receiving/grns',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyStore
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:143
 * @route '/api/receiving/grns'
 */
companyStore.url = (options?: RouteQueryOptions) => {
    return companyStore.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyStore
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:143
 * @route '/api/receiving/grns'
 */
companyStore.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: companyStore.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyStore
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:143
 * @route '/api/receiving/grns'
 */
    const companyStoreForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: companyStore.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyStore
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:143
 * @route '/api/receiving/grns'
 */
        companyStoreForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: companyStore.url(options),
            method: 'post',
        })
    
    companyStore.form = companyStoreForm
/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyAttachFile
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:181
 * @route '/api/receiving/grns/{note}/attachments'
 */
export const companyAttachFile = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: companyAttachFile.url(args, options),
    method: 'post',
})

companyAttachFile.definition = {
    methods: ["post"],
    url: '/api/receiving/grns/{note}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyAttachFile
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:181
 * @route '/api/receiving/grns/{note}/attachments'
 */
companyAttachFile.url = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { note: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    note: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        note: args.note,
                }

    return companyAttachFile.definition.url
            .replace('{note}', parsedArgs.note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyAttachFile
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:181
 * @route '/api/receiving/grns/{note}/attachments'
 */
companyAttachFile.post = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: companyAttachFile.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyAttachFile
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:181
 * @route '/api/receiving/grns/{note}/attachments'
 */
    const companyAttachFileForm = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: companyAttachFile.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\GoodsReceiptNoteController::companyAttachFile
 * @see app/Http/Controllers/Api/GoodsReceiptNoteController.php:181
 * @route '/api/receiving/grns/{note}/attachments'
 */
        companyAttachFileForm.post = (args: { note: string | number } | [note: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: companyAttachFile.url(args, options),
            method: 'post',
        })
    
    companyAttachFile.form = companyAttachFileForm
const GoodsReceiptNoteController = { index, show, store, update, destroy, companyIndex, companyShow, companyStore, companyAttachFile }

export default GoodsReceiptNoteController