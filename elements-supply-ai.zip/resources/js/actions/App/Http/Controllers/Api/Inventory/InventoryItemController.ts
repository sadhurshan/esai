import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::index
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:28
 * @route '/api/inventory/items'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/inventory/items',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::index
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:28
 * @route '/api/inventory/items'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::index
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:28
 * @route '/api/inventory/items'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::index
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:28
 * @route '/api/inventory/items'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::index
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:28
 * @route '/api/inventory/items'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::index
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:28
 * @route '/api/inventory/items'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::index
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:28
 * @route '/api/inventory/items'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::store
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:52
 * @route '/api/inventory/items'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/inventory/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::store
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:52
 * @route '/api/inventory/items'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::store
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:52
 * @route '/api/inventory/items'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::store
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:52
 * @route '/api/inventory/items'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::store
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:52
 * @route '/api/inventory/items'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::show
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:75
 * @route '/api/inventory/items/{item}'
 */
export const show = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/inventory/items/{item}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::show
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:75
 * @route '/api/inventory/items/{item}'
 */
show.url = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: args.item,
                }

    return show.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::show
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:75
 * @route '/api/inventory/items/{item}'
 */
show.get = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::show
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:75
 * @route '/api/inventory/items/{item}'
 */
show.head = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::show
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:75
 * @route '/api/inventory/items/{item}'
 */
    const showForm = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::show
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:75
 * @route '/api/inventory/items/{item}'
 */
        showForm.get = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::show
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:75
 * @route '/api/inventory/items/{item}'
 */
        showForm.head = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::update
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:98
 * @route '/api/inventory/items/{item}'
 */
export const update = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/api/inventory/items/{item}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::update
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:98
 * @route '/api/inventory/items/{item}'
 */
update.url = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { item: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        item: args.item,
                }

    return update.definition.url
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::update
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:98
 * @route '/api/inventory/items/{item}'
 */
update.patch = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::update
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:98
 * @route '/api/inventory/items/{item}'
 */
    const updateForm = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Inventory\InventoryItemController::update
 * @see app/Http/Controllers/Api/Inventory/InventoryItemController.php:98
 * @route '/api/inventory/items/{item}'
 */
        updateForm.patch = (args: { item: string | number } | [item: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const InventoryItemController = { index, store, show, update }

export default InventoryItemController