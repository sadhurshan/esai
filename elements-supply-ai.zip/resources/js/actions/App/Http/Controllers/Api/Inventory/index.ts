import InventoryItemController from './InventoryItemController'
import InventoryLowStockController from './InventoryLowStockController'
import InventoryMovementController from './InventoryMovementController'
import InventoryLocationController from './InventoryLocationController'
const Inventory = {
    InventoryItemController: Object.assign(InventoryItemController, InventoryItemController),
InventoryLowStockController: Object.assign(InventoryLowStockController, InventoryLowStockController),
InventoryMovementController: Object.assign(InventoryMovementController, InventoryMovementController),
InventoryLocationController: Object.assign(InventoryLocationController, InventoryLocationController),
}

export default Inventory