import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\InvoiceController::index
 * @see app/Http/Controllers/Api/InvoiceController.php:38
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
export const index = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/purchase-orders/{purchaseOrder}/invoices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::index
 * @see app/Http/Controllers/Api/InvoiceController.php:38
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
index.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return index.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::index
 * @see app/Http/Controllers/Api/InvoiceController.php:38
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
index.get = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\InvoiceController::index
 * @see app/Http/Controllers/Api/InvoiceController.php:38
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
index.head = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::index
 * @see app/Http/Controllers/Api/InvoiceController.php:38
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
    const indexForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::index
 * @see app/Http/Controllers/Api/InvoiceController.php:38
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
        indexForm.get = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\InvoiceController::index
 * @see app/Http/Controllers/Api/InvoiceController.php:38
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
        indexForm.head = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::store
 * @see app/Http/Controllers/Api/InvoiceController.php:141
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
export const store = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/purchase-orders/{purchaseOrder}/invoices',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::store
 * @see app/Http/Controllers/Api/InvoiceController.php:141
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
store.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return store.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::store
 * @see app/Http/Controllers/Api/InvoiceController.php:141
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
store.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::store
 * @see app/Http/Controllers/Api/InvoiceController.php:141
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
    const storeForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::store
 * @see app/Http/Controllers/Api/InvoiceController.php:141
 * @route '/api/purchase-orders/{purchaseOrder}/invoices'
 */
        storeForm.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::list
 * @see app/Http/Controllers/Api/InvoiceController.php:90
 * @route '/api/invoices'
 */
export const list = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: list.url(options),
    method: 'get',
})

list.definition = {
    methods: ["get","head"],
    url: '/api/invoices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::list
 * @see app/Http/Controllers/Api/InvoiceController.php:90
 * @route '/api/invoices'
 */
list.url = (options?: RouteQueryOptions) => {
    return list.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::list
 * @see app/Http/Controllers/Api/InvoiceController.php:90
 * @route '/api/invoices'
 */
list.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: list.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\InvoiceController::list
 * @see app/Http/Controllers/Api/InvoiceController.php:90
 * @route '/api/invoices'
 */
list.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: list.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::list
 * @see app/Http/Controllers/Api/InvoiceController.php:90
 * @route '/api/invoices'
 */
    const listForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: list.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::list
 * @see app/Http/Controllers/Api/InvoiceController.php:90
 * @route '/api/invoices'
 */
        listForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: list.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\InvoiceController::list
 * @see app/Http/Controllers/Api/InvoiceController.php:90
 * @route '/api/invoices'
 */
        listForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: list.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    list.form = listForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::show
 * @see app/Http/Controllers/Api/InvoiceController.php:236
 * @route '/api/invoices/{invoice}'
 */
export const show = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/invoices/{invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::show
 * @see app/Http/Controllers/Api/InvoiceController.php:236
 * @route '/api/invoices/{invoice}'
 */
show.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return show.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::show
 * @see app/Http/Controllers/Api/InvoiceController.php:236
 * @route '/api/invoices/{invoice}'
 */
show.get = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\InvoiceController::show
 * @see app/Http/Controllers/Api/InvoiceController.php:236
 * @route '/api/invoices/{invoice}'
 */
show.head = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::show
 * @see app/Http/Controllers/Api/InvoiceController.php:236
 * @route '/api/invoices/{invoice}'
 */
    const showForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::show
 * @see app/Http/Controllers/Api/InvoiceController.php:236
 * @route '/api/invoices/{invoice}'
 */
        showForm.get = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\InvoiceController::show
 * @see app/Http/Controllers/Api/InvoiceController.php:236
 * @route '/api/invoices/{invoice}'
 */
        showForm.head = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::update
 * @see app/Http/Controllers/Api/InvoiceController.php:259
 * @route '/api/invoices/{invoice}'
 */
export const update = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/invoices/{invoice}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::update
 * @see app/Http/Controllers/Api/InvoiceController.php:259
 * @route '/api/invoices/{invoice}'
 */
update.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return update.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::update
 * @see app/Http/Controllers/Api/InvoiceController.php:259
 * @route '/api/invoices/{invoice}'
 */
update.put = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::update
 * @see app/Http/Controllers/Api/InvoiceController.php:259
 * @route '/api/invoices/{invoice}'
 */
    const updateForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::update
 * @see app/Http/Controllers/Api/InvoiceController.php:259
 * @route '/api/invoices/{invoice}'
 */
        updateForm.put = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::destroy
 * @see app/Http/Controllers/Api/InvoiceController.php:280
 * @route '/api/invoices/{invoice}'
 */
export const destroy = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/invoices/{invoice}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::destroy
 * @see app/Http/Controllers/Api/InvoiceController.php:280
 * @route '/api/invoices/{invoice}'
 */
destroy.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return destroy.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::destroy
 * @see app/Http/Controllers/Api/InvoiceController.php:280
 * @route '/api/invoices/{invoice}'
 */
destroy.delete = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::destroy
 * @see app/Http/Controllers/Api/InvoiceController.php:280
 * @route '/api/invoices/{invoice}'
 */
    const destroyForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::destroy
 * @see app/Http/Controllers/Api/InvoiceController.php:280
 * @route '/api/invoices/{invoice}'
 */
        destroyForm.delete = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::storeFromPo
 * @see app/Http/Controllers/Api/InvoiceController.php:182
 * @route '/api/invoices/from-po'
 */
export const storeFromPo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeFromPo.url(options),
    method: 'post',
})

storeFromPo.definition = {
    methods: ["post"],
    url: '/api/invoices/from-po',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::storeFromPo
 * @see app/Http/Controllers/Api/InvoiceController.php:182
 * @route '/api/invoices/from-po'
 */
storeFromPo.url = (options?: RouteQueryOptions) => {
    return storeFromPo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::storeFromPo
 * @see app/Http/Controllers/Api/InvoiceController.php:182
 * @route '/api/invoices/from-po'
 */
storeFromPo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeFromPo.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::storeFromPo
 * @see app/Http/Controllers/Api/InvoiceController.php:182
 * @route '/api/invoices/from-po'
 */
    const storeFromPoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeFromPo.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::storeFromPo
 * @see app/Http/Controllers/Api/InvoiceController.php:182
 * @route '/api/invoices/from-po'
 */
        storeFromPoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeFromPo.url(options),
            method: 'post',
        })
    
    storeFromPo.form = storeFromPoForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::attachFile
 * @see app/Http/Controllers/Api/InvoiceController.php:297
 * @route '/api/invoices/{invoice}/attachments'
 */
export const attachFile = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: attachFile.url(args, options),
    method: 'post',
})

attachFile.definition = {
    methods: ["post"],
    url: '/api/invoices/{invoice}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::attachFile
 * @see app/Http/Controllers/Api/InvoiceController.php:297
 * @route '/api/invoices/{invoice}/attachments'
 */
attachFile.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return attachFile.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::attachFile
 * @see app/Http/Controllers/Api/InvoiceController.php:297
 * @route '/api/invoices/{invoice}/attachments'
 */
attachFile.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: attachFile.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::attachFile
 * @see app/Http/Controllers/Api/InvoiceController.php:297
 * @route '/api/invoices/{invoice}/attachments'
 */
    const attachFileForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: attachFile.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::attachFile
 * @see app/Http/Controllers/Api/InvoiceController.php:297
 * @route '/api/invoices/{invoice}/attachments'
 */
        attachFileForm.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: attachFile.url(args, options),
            method: 'post',
        })
    
    attachFile.form = attachFileForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::approve
 * @see app/Http/Controllers/Api/InvoiceController.php:324
 * @route '/api/invoices/{invoice}/review/approve'
 */
export const approve = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/invoices/{invoice}/review/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::approve
 * @see app/Http/Controllers/Api/InvoiceController.php:324
 * @route '/api/invoices/{invoice}/review/approve'
 */
approve.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return approve.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::approve
 * @see app/Http/Controllers/Api/InvoiceController.php:324
 * @route '/api/invoices/{invoice}/review/approve'
 */
approve.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::approve
 * @see app/Http/Controllers/Api/InvoiceController.php:324
 * @route '/api/invoices/{invoice}/review/approve'
 */
    const approveForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::approve
 * @see app/Http/Controllers/Api/InvoiceController.php:324
 * @route '/api/invoices/{invoice}/review/approve'
 */
        approveForm.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::reject
 * @see app/Http/Controllers/Api/InvoiceController.php:349
 * @route '/api/invoices/{invoice}/review/reject'
 */
export const reject = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/api/invoices/{invoice}/review/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::reject
 * @see app/Http/Controllers/Api/InvoiceController.php:349
 * @route '/api/invoices/{invoice}/review/reject'
 */
reject.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return reject.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::reject
 * @see app/Http/Controllers/Api/InvoiceController.php:349
 * @route '/api/invoices/{invoice}/review/reject'
 */
reject.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::reject
 * @see app/Http/Controllers/Api/InvoiceController.php:349
 * @route '/api/invoices/{invoice}/review/reject'
 */
    const rejectForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::reject
 * @see app/Http/Controllers/Api/InvoiceController.php:349
 * @route '/api/invoices/{invoice}/review/reject'
 */
        rejectForm.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::requestChanges
 * @see app/Http/Controllers/Api/InvoiceController.php:376
 * @route '/api/invoices/{invoice}/review/request-changes'
 */
export const requestChanges = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requestChanges.url(args, options),
    method: 'post',
})

requestChanges.definition = {
    methods: ["post"],
    url: '/api/invoices/{invoice}/review/request-changes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::requestChanges
 * @see app/Http/Controllers/Api/InvoiceController.php:376
 * @route '/api/invoices/{invoice}/review/request-changes'
 */
requestChanges.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return requestChanges.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::requestChanges
 * @see app/Http/Controllers/Api/InvoiceController.php:376
 * @route '/api/invoices/{invoice}/review/request-changes'
 */
requestChanges.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requestChanges.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::requestChanges
 * @see app/Http/Controllers/Api/InvoiceController.php:376
 * @route '/api/invoices/{invoice}/review/request-changes'
 */
    const requestChangesForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: requestChanges.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::requestChanges
 * @see app/Http/Controllers/Api/InvoiceController.php:376
 * @route '/api/invoices/{invoice}/review/request-changes'
 */
        requestChangesForm.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: requestChanges.url(args, options),
            method: 'post',
        })
    
    requestChanges.form = requestChangesForm
/**
* @see \App\Http\Controllers\Api\InvoiceController::markPaid
 * @see app/Http/Controllers/Api/InvoiceController.php:403
 * @route '/api/invoices/{invoice}/mark-paid'
 */
export const markPaid = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markPaid.url(args, options),
    method: 'post',
})

markPaid.definition = {
    methods: ["post"],
    url: '/api/invoices/{invoice}/mark-paid',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\InvoiceController::markPaid
 * @see app/Http/Controllers/Api/InvoiceController.php:403
 * @route '/api/invoices/{invoice}/mark-paid'
 */
markPaid.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return markPaid.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceController::markPaid
 * @see app/Http/Controllers/Api/InvoiceController.php:403
 * @route '/api/invoices/{invoice}/mark-paid'
 */
markPaid.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markPaid.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceController::markPaid
 * @see app/Http/Controllers/Api/InvoiceController.php:403
 * @route '/api/invoices/{invoice}/mark-paid'
 */
    const markPaidForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markPaid.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceController::markPaid
 * @see app/Http/Controllers/Api/InvoiceController.php:403
 * @route '/api/invoices/{invoice}/mark-paid'
 */
        markPaidForm.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markPaid.url(args, options),
            method: 'post',
        })
    
    markPaid.form = markPaidForm
const InvoiceController = { index, store, list, show, update, destroy, storeFromPo, attachFile, approve, reject, requestChanges, markPaid }

export default InvoiceController