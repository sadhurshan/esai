import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\InvoiceTotalsController::recalculate
 * @see app/Http/Controllers/Api/InvoiceTotalsController.php:17
 * @route '/api/invoices/{invoice}/recalculate'
 */
export const recalculate = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(args, options),
    method: 'post',
})

recalculate.definition = {
    methods: ["post"],
    url: '/api/invoices/{invoice}/recalculate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\InvoiceTotalsController::recalculate
 * @see app/Http/Controllers/Api/InvoiceTotalsController.php:17
 * @route '/api/invoices/{invoice}/recalculate'
 */
recalculate.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return recalculate.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\InvoiceTotalsController::recalculate
 * @see app/Http/Controllers/Api/InvoiceTotalsController.php:17
 * @route '/api/invoices/{invoice}/recalculate'
 */
recalculate.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\InvoiceTotalsController::recalculate
 * @see app/Http/Controllers/Api/InvoiceTotalsController.php:17
 * @route '/api/invoices/{invoice}/recalculate'
 */
    const recalculateForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: recalculate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\InvoiceTotalsController::recalculate
 * @see app/Http/Controllers/Api/InvoiceTotalsController.php:17
 * @route '/api/invoices/{invoice}/recalculate'
 */
        recalculateForm.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: recalculate.url(args, options),
            method: 'post',
        })
    
    recalculate.form = recalculateForm
const InvoiceTotalsController = { recalculate }

export default InvoiceTotalsController