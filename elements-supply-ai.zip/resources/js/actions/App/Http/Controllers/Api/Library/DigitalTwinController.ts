import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::index
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:31
 * @route '/api/library/digital-twins'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/library/digital-twins',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::index
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:31
 * @route '/api/library/digital-twins'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::index
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:31
 * @route '/api/library/digital-twins'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::index
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:31
 * @route '/api/library/digital-twins'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::index
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:31
 * @route '/api/library/digital-twins'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::index
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:31
 * @route '/api/library/digital-twins'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::index
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:31
 * @route '/api/library/digital-twins'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::show
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:65
 * @route '/api/library/digital-twins/{digital_twin}'
 */
export const show = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/library/digital-twins/{digital_twin}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::show
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:65
 * @route '/api/library/digital-twins/{digital_twin}'
 */
show.url = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { digital_twin: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    digital_twin: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        digital_twin: args.digital_twin,
                }

    return show.definition.url
            .replace('{digital_twin}', parsedArgs.digital_twin.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::show
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:65
 * @route '/api/library/digital-twins/{digital_twin}'
 */
show.get = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::show
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:65
 * @route '/api/library/digital-twins/{digital_twin}'
 */
show.head = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::show
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:65
 * @route '/api/library/digital-twins/{digital_twin}'
 */
    const showForm = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::show
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:65
 * @route '/api/library/digital-twins/{digital_twin}'
 */
        showForm.get = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::show
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:65
 * @route '/api/library/digital-twins/{digital_twin}'
 */
        showForm.head = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::useForRfq
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:82
 * @route '/api/library/digital-twins/{digital_twin}/use-for-rfq'
 */
export const useForRfq = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: useForRfq.url(args, options),
    method: 'post',
})

useForRfq.definition = {
    methods: ["post"],
    url: '/api/library/digital-twins/{digital_twin}/use-for-rfq',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::useForRfq
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:82
 * @route '/api/library/digital-twins/{digital_twin}/use-for-rfq'
 */
useForRfq.url = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { digital_twin: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    digital_twin: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        digital_twin: args.digital_twin,
                }

    return useForRfq.definition.url
            .replace('{digital_twin}', parsedArgs.digital_twin.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::useForRfq
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:82
 * @route '/api/library/digital-twins/{digital_twin}/use-for-rfq'
 */
useForRfq.post = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: useForRfq.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::useForRfq
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:82
 * @route '/api/library/digital-twins/{digital_twin}/use-for-rfq'
 */
    const useForRfqForm = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: useForRfq.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Library\DigitalTwinController::useForRfq
 * @see app/Http/Controllers/Api/Library/DigitalTwinController.php:82
 * @route '/api/library/digital-twins/{digital_twin}/use-for-rfq'
 */
        useForRfqForm.post = (args: { digital_twin: string | number } | [digital_twin: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: useForRfq.url(args, options),
            method: 'post',
        })
    
    useForRfq.form = useForRfqForm
const DigitalTwinController = { index, show, useForRfq }

export default DigitalTwinController