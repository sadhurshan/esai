import DigitalTwinController from './DigitalTwinController'
const Library = {
    DigitalTwinController: Object.assign(DigitalTwinController, DigitalTwinController),
}

export default Library