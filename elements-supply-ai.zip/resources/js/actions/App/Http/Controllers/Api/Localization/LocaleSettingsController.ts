import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/settings/localization'
 */
const showd962ec65e991c0d52fdd6c4d8eff1623 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showd962ec65e991c0d52fdd6c4d8eff1623.url(options),
    method: 'get',
})

showd962ec65e991c0d52fdd6c4d8eff1623.definition = {
    methods: ["get","head"],
    url: '/api/settings/localization',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/settings/localization'
 */
showd962ec65e991c0d52fdd6c4d8eff1623.url = (options?: RouteQueryOptions) => {
    return showd962ec65e991c0d52fdd6c4d8eff1623.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/settings/localization'
 */
showd962ec65e991c0d52fdd6c4d8eff1623.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showd962ec65e991c0d52fdd6c4d8eff1623.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/settings/localization'
 */
showd962ec65e991c0d52fdd6c4d8eff1623.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showd962ec65e991c0d52fdd6c4d8eff1623.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/settings/localization'
 */
    const showd962ec65e991c0d52fdd6c4d8eff1623Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showd962ec65e991c0d52fdd6c4d8eff1623.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/settings/localization'
 */
        showd962ec65e991c0d52fdd6c4d8eff1623Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showd962ec65e991c0d52fdd6c4d8eff1623.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/settings/localization'
 */
        showd962ec65e991c0d52fdd6c4d8eff1623Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showd962ec65e991c0d52fdd6c4d8eff1623.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showd962ec65e991c0d52fdd6c4d8eff1623.form = showd962ec65e991c0d52fdd6c4d8eff1623Form
    /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/localization/settings'
 */
const show9ad1a7f320c1f1705dcc5e8cd2cca5a8 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show9ad1a7f320c1f1705dcc5e8cd2cca5a8.url(options),
    method: 'get',
})

show9ad1a7f320c1f1705dcc5e8cd2cca5a8.definition = {
    methods: ["get","head"],
    url: '/api/localization/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/localization/settings'
 */
show9ad1a7f320c1f1705dcc5e8cd2cca5a8.url = (options?: RouteQueryOptions) => {
    return show9ad1a7f320c1f1705dcc5e8cd2cca5a8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/localization/settings'
 */
show9ad1a7f320c1f1705dcc5e8cd2cca5a8.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show9ad1a7f320c1f1705dcc5e8cd2cca5a8.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/localization/settings'
 */
show9ad1a7f320c1f1705dcc5e8cd2cca5a8.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show9ad1a7f320c1f1705dcc5e8cd2cca5a8.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/localization/settings'
 */
    const show9ad1a7f320c1f1705dcc5e8cd2cca5a8Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show9ad1a7f320c1f1705dcc5e8cd2cca5a8.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/localization/settings'
 */
        show9ad1a7f320c1f1705dcc5e8cd2cca5a8Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show9ad1a7f320c1f1705dcc5e8cd2cca5a8.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::show
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:20
 * @route '/api/localization/settings'
 */
        show9ad1a7f320c1f1705dcc5e8cd2cca5a8Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show9ad1a7f320c1f1705dcc5e8cd2cca5a8.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show9ad1a7f320c1f1705dcc5e8cd2cca5a8.form = show9ad1a7f320c1f1705dcc5e8cd2cca5a8Form

export const show = {
    '/api/settings/localization': showd962ec65e991c0d52fdd6c4d8eff1623,
    '/api/localization/settings': show9ad1a7f320c1f1705dcc5e8cd2cca5a8,
}

/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::update
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:41
 * @route '/api/settings/localization'
 */
const updated962ec65e991c0d52fdd6c4d8eff1623 = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updated962ec65e991c0d52fdd6c4d8eff1623.url(options),
    method: 'patch',
})

updated962ec65e991c0d52fdd6c4d8eff1623.definition = {
    methods: ["patch"],
    url: '/api/settings/localization',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::update
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:41
 * @route '/api/settings/localization'
 */
updated962ec65e991c0d52fdd6c4d8eff1623.url = (options?: RouteQueryOptions) => {
    return updated962ec65e991c0d52fdd6c4d8eff1623.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::update
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:41
 * @route '/api/settings/localization'
 */
updated962ec65e991c0d52fdd6c4d8eff1623.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updated962ec65e991c0d52fdd6c4d8eff1623.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::update
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:41
 * @route '/api/settings/localization'
 */
    const updated962ec65e991c0d52fdd6c4d8eff1623Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updated962ec65e991c0d52fdd6c4d8eff1623.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::update
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:41
 * @route '/api/settings/localization'
 */
        updated962ec65e991c0d52fdd6c4d8eff1623Form.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updated962ec65e991c0d52fdd6c4d8eff1623.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updated962ec65e991c0d52fdd6c4d8eff1623.form = updated962ec65e991c0d52fdd6c4d8eff1623Form
    /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::update
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:41
 * @route '/api/localization/settings'
 */
const update9ad1a7f320c1f1705dcc5e8cd2cca5a8 = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update9ad1a7f320c1f1705dcc5e8cd2cca5a8.url(options),
    method: 'put',
})

update9ad1a7f320c1f1705dcc5e8cd2cca5a8.definition = {
    methods: ["put"],
    url: '/api/localization/settings',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::update
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:41
 * @route '/api/localization/settings'
 */
update9ad1a7f320c1f1705dcc5e8cd2cca5a8.url = (options?: RouteQueryOptions) => {
    return update9ad1a7f320c1f1705dcc5e8cd2cca5a8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::update
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:41
 * @route '/api/localization/settings'
 */
update9ad1a7f320c1f1705dcc5e8cd2cca5a8.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update9ad1a7f320c1f1705dcc5e8cd2cca5a8.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::update
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:41
 * @route '/api/localization/settings'
 */
    const update9ad1a7f320c1f1705dcc5e8cd2cca5a8Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update9ad1a7f320c1f1705dcc5e8cd2cca5a8.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\LocaleSettingsController::update
 * @see app/Http/Controllers/Api/Localization/LocaleSettingsController.php:41
 * @route '/api/localization/settings'
 */
        update9ad1a7f320c1f1705dcc5e8cd2cca5a8Form.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update9ad1a7f320c1f1705dcc5e8cd2cca5a8.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update9ad1a7f320c1f1705dcc5e8cd2cca5a8.form = update9ad1a7f320c1f1705dcc5e8cd2cca5a8Form

export const update = {
    '/api/settings/localization': updated962ec65e991c0d52fdd6c4d8eff1623,
    '/api/localization/settings': update9ad1a7f320c1f1705dcc5e8cd2cca5a8,
}

const LocaleSettingsController = { show, update }

export default LocaleSettingsController