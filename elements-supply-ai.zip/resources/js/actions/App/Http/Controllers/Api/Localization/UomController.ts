import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Localization\UomController::index
 * @see app/Http/Controllers/Api/Localization/UomController.php:24
 * @route '/api/localization/uoms'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/localization/uoms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Localization\UomController::index
 * @see app/Http/Controllers/Api/Localization/UomController.php:24
 * @route '/api/localization/uoms'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\UomController::index
 * @see app/Http/Controllers/Api/Localization/UomController.php:24
 * @route '/api/localization/uoms'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Localization\UomController::index
 * @see app/Http/Controllers/Api/Localization/UomController.php:24
 * @route '/api/localization/uoms'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Localization\UomController::index
 * @see app/Http/Controllers/Api/Localization/UomController.php:24
 * @route '/api/localization/uoms'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\UomController::index
 * @see app/Http/Controllers/Api/Localization/UomController.php:24
 * @route '/api/localization/uoms'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Localization\UomController::index
 * @see app/Http/Controllers/Api/Localization/UomController.php:24
 * @route '/api/localization/uoms'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Localization\UomController::store
 * @see app/Http/Controllers/Api/Localization/UomController.php:48
 * @route '/api/localization/uoms'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/localization/uoms',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Localization\UomController::store
 * @see app/Http/Controllers/Api/Localization/UomController.php:48
 * @route '/api/localization/uoms'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\UomController::store
 * @see app/Http/Controllers/Api/Localization/UomController.php:48
 * @route '/api/localization/uoms'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Localization\UomController::store
 * @see app/Http/Controllers/Api/Localization/UomController.php:48
 * @route '/api/localization/uoms'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\UomController::store
 * @see app/Http/Controllers/Api/Localization/UomController.php:48
 * @route '/api/localization/uoms'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\Localization\UomController::update
 * @see app/Http/Controllers/Api/Localization/UomController.php:61
 * @route '/api/localization/uoms/{uom}'
 */
export const update = (args: { uom: number | { id: number } } | [uom: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/localization/uoms/{uom}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\Localization\UomController::update
 * @see app/Http/Controllers/Api/Localization/UomController.php:61
 * @route '/api/localization/uoms/{uom}'
 */
update.url = (args: { uom: number | { id: number } } | [uom: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { uom: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { uom: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    uom: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        uom: typeof args.uom === 'object'
                ? args.uom.id
                : args.uom,
                }

    return update.definition.url
            .replace('{uom}', parsedArgs.uom.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\UomController::update
 * @see app/Http/Controllers/Api/Localization/UomController.php:61
 * @route '/api/localization/uoms/{uom}'
 */
update.put = (args: { uom: number | { id: number } } | [uom: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\Localization\UomController::update
 * @see app/Http/Controllers/Api/Localization/UomController.php:61
 * @route '/api/localization/uoms/{uom}'
 */
    const updateForm = (args: { uom: number | { id: number } } | [uom: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\UomController::update
 * @see app/Http/Controllers/Api/Localization/UomController.php:61
 * @route '/api/localization/uoms/{uom}'
 */
        updateForm.put = (args: { uom: number | { id: number } } | [uom: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\Localization\UomController::destroy
 * @see app/Http/Controllers/Api/Localization/UomController.php:80
 * @route '/api/localization/uoms/{uom}'
 */
export const destroy = (args: { uom: number | { id: number } } | [uom: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/localization/uoms/{uom}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\Localization\UomController::destroy
 * @see app/Http/Controllers/Api/Localization/UomController.php:80
 * @route '/api/localization/uoms/{uom}'
 */
destroy.url = (args: { uom: number | { id: number } } | [uom: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { uom: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { uom: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    uom: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        uom: typeof args.uom === 'object'
                ? args.uom.id
                : args.uom,
                }

    return destroy.definition.url
            .replace('{uom}', parsedArgs.uom.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\UomController::destroy
 * @see app/Http/Controllers/Api/Localization/UomController.php:80
 * @route '/api/localization/uoms/{uom}'
 */
destroy.delete = (args: { uom: number | { id: number } } | [uom: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\Localization\UomController::destroy
 * @see app/Http/Controllers/Api/Localization/UomController.php:80
 * @route '/api/localization/uoms/{uom}'
 */
    const destroyForm = (args: { uom: number | { id: number } } | [uom: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\UomController::destroy
 * @see app/Http/Controllers/Api/Localization/UomController.php:80
 * @route '/api/localization/uoms/{uom}'
 */
        destroyForm.delete = (args: { uom: number | { id: number } } | [uom: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const UomController = { index, store, update, destroy }

export default UomController