import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\MoneySettingsController::show
 * @see app/Http/Controllers/Api/MoneySettingsController.php:21
 * @route '/api/money/settings'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/money/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\MoneySettingsController::show
 * @see app/Http/Controllers/Api/MoneySettingsController.php:21
 * @route '/api/money/settings'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MoneySettingsController::show
 * @see app/Http/Controllers/Api/MoneySettingsController.php:21
 * @route '/api/money/settings'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\MoneySettingsController::show
 * @see app/Http/Controllers/Api/MoneySettingsController.php:21
 * @route '/api/money/settings'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\MoneySettingsController::show
 * @see app/Http/Controllers/Api/MoneySettingsController.php:21
 * @route '/api/money/settings'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\MoneySettingsController::show
 * @see app/Http/Controllers/Api/MoneySettingsController.php:21
 * @route '/api/money/settings'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\MoneySettingsController::show
 * @see app/Http/Controllers/Api/MoneySettingsController.php:21
 * @route '/api/money/settings'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\MoneySettingsController::update
 * @see app/Http/Controllers/Api/MoneySettingsController.php:60
 * @route '/api/money/settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/money/settings',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\MoneySettingsController::update
 * @see app/Http/Controllers/Api/MoneySettingsController.php:60
 * @route '/api/money/settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MoneySettingsController::update
 * @see app/Http/Controllers/Api/MoneySettingsController.php:60
 * @route '/api/money/settings'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\MoneySettingsController::update
 * @see app/Http/Controllers/Api/MoneySettingsController.php:60
 * @route '/api/money/settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\MoneySettingsController::update
 * @see app/Http/Controllers/Api/MoneySettingsController.php:60
 * @route '/api/money/settings'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const MoneySettingsController = { show, update }

export default MoneySettingsController