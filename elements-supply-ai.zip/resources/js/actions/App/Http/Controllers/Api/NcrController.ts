import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\NcrController::store
 * @see app/Http/Controllers/Api/NcrController.php:23
 * @route '/api/receiving/grns/{note}/ncrs'
 */
export const store = (args: { note: number | { id: number } } | [note: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/receiving/grns/{note}/ncrs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\NcrController::store
 * @see app/Http/Controllers/Api/NcrController.php:23
 * @route '/api/receiving/grns/{note}/ncrs'
 */
store.url = (args: { note: number | { id: number } } | [note: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { note: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { note: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    note: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        note: typeof args.note === 'object'
                ? args.note.id
                : args.note,
                }

    return store.definition.url
            .replace('{note}', parsedArgs.note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\NcrController::store
 * @see app/Http/Controllers/Api/NcrController.php:23
 * @route '/api/receiving/grns/{note}/ncrs'
 */
store.post = (args: { note: number | { id: number } } | [note: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\NcrController::store
 * @see app/Http/Controllers/Api/NcrController.php:23
 * @route '/api/receiving/grns/{note}/ncrs'
 */
    const storeForm = (args: { note: number | { id: number } } | [note: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\NcrController::store
 * @see app/Http/Controllers/Api/NcrController.php:23
 * @route '/api/receiving/grns/{note}/ncrs'
 */
        storeForm.post = (args: { note: number | { id: number } } | [note: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\NcrController::update
 * @see app/Http/Controllers/Api/NcrController.php:66
 * @route '/api/receiving/ncrs/{ncr}'
 */
export const update = (args: { ncr: number | { id: number } } | [ncr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/api/receiving/ncrs/{ncr}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\NcrController::update
 * @see app/Http/Controllers/Api/NcrController.php:66
 * @route '/api/receiving/ncrs/{ncr}'
 */
update.url = (args: { ncr: number | { id: number } } | [ncr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ncr: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ncr: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ncr: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ncr: typeof args.ncr === 'object'
                ? args.ncr.id
                : args.ncr,
                }

    return update.definition.url
            .replace('{ncr}', parsedArgs.ncr.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\NcrController::update
 * @see app/Http/Controllers/Api/NcrController.php:66
 * @route '/api/receiving/ncrs/{ncr}'
 */
update.patch = (args: { ncr: number | { id: number } } | [ncr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\NcrController::update
 * @see app/Http/Controllers/Api/NcrController.php:66
 * @route '/api/receiving/ncrs/{ncr}'
 */
    const updateForm = (args: { ncr: number | { id: number } } | [ncr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\NcrController::update
 * @see app/Http/Controllers/Api/NcrController.php:66
 * @route '/api/receiving/ncrs/{ncr}'
 */
        updateForm.patch = (args: { ncr: number | { id: number } } | [ncr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const NcrController = { store, update }

export default NcrController