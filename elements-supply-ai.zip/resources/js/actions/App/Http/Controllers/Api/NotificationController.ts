import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\NotificationController::index
 * @see app/Http/Controllers/Api/NotificationController.php:18
 * @route '/api/notifications'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\NotificationController::index
 * @see app/Http/Controllers/Api/NotificationController.php:18
 * @route '/api/notifications'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\NotificationController::index
 * @see app/Http/Controllers/Api/NotificationController.php:18
 * @route '/api/notifications'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\NotificationController::index
 * @see app/Http/Controllers/Api/NotificationController.php:18
 * @route '/api/notifications'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\NotificationController::index
 * @see app/Http/Controllers/Api/NotificationController.php:18
 * @route '/api/notifications'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\NotificationController::index
 * @see app/Http/Controllers/Api/NotificationController.php:18
 * @route '/api/notifications'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\NotificationController::index
 * @see app/Http/Controllers/Api/NotificationController.php:18
 * @route '/api/notifications'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\NotificationController::markSelectedRead
 * @see app/Http/Controllers/Api/NotificationController.php:86
 * @route '/api/notifications/read'
 */
export const markSelectedRead = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markSelectedRead.url(options),
    method: 'post',
})

markSelectedRead.definition = {
    methods: ["post"],
    url: '/api/notifications/read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\NotificationController::markSelectedRead
 * @see app/Http/Controllers/Api/NotificationController.php:86
 * @route '/api/notifications/read'
 */
markSelectedRead.url = (options?: RouteQueryOptions) => {
    return markSelectedRead.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\NotificationController::markSelectedRead
 * @see app/Http/Controllers/Api/NotificationController.php:86
 * @route '/api/notifications/read'
 */
markSelectedRead.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markSelectedRead.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\NotificationController::markSelectedRead
 * @see app/Http/Controllers/Api/NotificationController.php:86
 * @route '/api/notifications/read'
 */
    const markSelectedReadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markSelectedRead.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\NotificationController::markSelectedRead
 * @see app/Http/Controllers/Api/NotificationController.php:86
 * @route '/api/notifications/read'
 */
        markSelectedReadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markSelectedRead.url(options),
            method: 'post',
        })
    
    markSelectedRead.form = markSelectedReadForm
/**
* @see \App\Http\Controllers\Api\NotificationController::markAllRead
 * @see app/Http/Controllers/Api/NotificationController.php:73
 * @route '/api/notifications/mark-all-read'
 */
export const markAllRead = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllRead.url(options),
    method: 'post',
})

markAllRead.definition = {
    methods: ["post"],
    url: '/api/notifications/mark-all-read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\NotificationController::markAllRead
 * @see app/Http/Controllers/Api/NotificationController.php:73
 * @route '/api/notifications/mark-all-read'
 */
markAllRead.url = (options?: RouteQueryOptions) => {
    return markAllRead.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\NotificationController::markAllRead
 * @see app/Http/Controllers/Api/NotificationController.php:73
 * @route '/api/notifications/mark-all-read'
 */
markAllRead.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllRead.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\NotificationController::markAllRead
 * @see app/Http/Controllers/Api/NotificationController.php:73
 * @route '/api/notifications/mark-all-read'
 */
    const markAllReadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAllRead.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\NotificationController::markAllRead
 * @see app/Http/Controllers/Api/NotificationController.php:73
 * @route '/api/notifications/mark-all-read'
 */
        markAllReadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAllRead.url(options),
            method: 'post',
        })
    
    markAllRead.form = markAllReadForm
/**
* @see \App\Http\Controllers\Api\NotificationController::markRead
 * @see app/Http/Controllers/Api/NotificationController.php:56
 * @route '/api/notifications/{notification}/read'
 */
export const markRead = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: markRead.url(args, options),
    method: 'put',
})

markRead.definition = {
    methods: ["put"],
    url: '/api/notifications/{notification}/read',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\NotificationController::markRead
 * @see app/Http/Controllers/Api/NotificationController.php:56
 * @route '/api/notifications/{notification}/read'
 */
markRead.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return markRead.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\NotificationController::markRead
 * @see app/Http/Controllers/Api/NotificationController.php:56
 * @route '/api/notifications/{notification}/read'
 */
markRead.put = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: markRead.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\NotificationController::markRead
 * @see app/Http/Controllers/Api/NotificationController.php:56
 * @route '/api/notifications/{notification}/read'
 */
    const markReadForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markRead.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\NotificationController::markRead
 * @see app/Http/Controllers/Api/NotificationController.php:56
 * @route '/api/notifications/{notification}/read'
 */
        markReadForm.put = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markRead.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    markRead.form = markReadForm
const NotificationController = { index, markSelectedRead, markAllRead, markRead }

export default NotificationController