import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::index
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:15
 * @route '/api/buyer/orders'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/buyer/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::index
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:15
 * @route '/api/buyer/orders'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::index
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:15
 * @route '/api/buyer/orders'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::index
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:15
 * @route '/api/buyer/orders'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::index
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:15
 * @route '/api/buyer/orders'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::index
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:15
 * @route '/api/buyer/orders'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::index
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:15
 * @route '/api/buyer/orders'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::show
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:54
 * @route '/api/buyer/orders/{order}'
 */
export const show = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/buyer/orders/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::show
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:54
 * @route '/api/buyer/orders/{order}'
 */
show.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: args.order,
                }

    return show.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::show
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:54
 * @route '/api/buyer/orders/{order}'
 */
show.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::show
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:54
 * @route '/api/buyer/orders/{order}'
 */
show.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::show
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:54
 * @route '/api/buyer/orders/{order}'
 */
    const showForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::show
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:54
 * @route '/api/buyer/orders/{order}'
 */
        showForm.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Orders\BuyerOrderController::show
 * @see app/Http/Controllers/Api/Orders/BuyerOrderController.php:54
 * @route '/api/buyer/orders/{order}'
 */
        showForm.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const BuyerOrderController = { index, show }

export default BuyerOrderController