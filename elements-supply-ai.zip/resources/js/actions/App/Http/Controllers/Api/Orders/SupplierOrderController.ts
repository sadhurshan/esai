import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::index
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:22
 * @route '/api/supplier/orders'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/supplier/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::index
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:22
 * @route '/api/supplier/orders'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::index
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:22
 * @route '/api/supplier/orders'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::index
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:22
 * @route '/api/supplier/orders'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::index
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:22
 * @route '/api/supplier/orders'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::index
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:22
 * @route '/api/supplier/orders'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::index
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:22
 * @route '/api/supplier/orders'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::show
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:69
 * @route '/api/supplier/orders/{order}'
 */
export const show = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/supplier/orders/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::show
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:69
 * @route '/api/supplier/orders/{order}'
 */
show.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: args.order,
                }

    return show.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::show
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:69
 * @route '/api/supplier/orders/{order}'
 */
show.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::show
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:69
 * @route '/api/supplier/orders/{order}'
 */
show.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::show
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:69
 * @route '/api/supplier/orders/{order}'
 */
    const showForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::show
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:69
 * @route '/api/supplier/orders/{order}'
 */
        showForm.get = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::show
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:69
 * @route '/api/supplier/orders/{order}'
 */
        showForm.head = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::acknowledge
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:102
 * @route '/api/supplier/orders/{order}/ack'
 */
export const acknowledge = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: acknowledge.url(args, options),
    method: 'post',
})

acknowledge.definition = {
    methods: ["post"],
    url: '/api/supplier/orders/{order}/ack',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::acknowledge
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:102
 * @route '/api/supplier/orders/{order}/ack'
 */
acknowledge.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: args.order,
                }

    return acknowledge.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::acknowledge
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:102
 * @route '/api/supplier/orders/{order}/ack'
 */
acknowledge.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: acknowledge.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::acknowledge
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:102
 * @route '/api/supplier/orders/{order}/ack'
 */
    const acknowledgeForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: acknowledge.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Orders\SupplierOrderController::acknowledge
 * @see app/Http/Controllers/Api/Orders/SupplierOrderController.php:102
 * @route '/api/supplier/orders/{order}/ack'
 */
        acknowledgeForm.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: acknowledge.url(args, options),
            method: 'post',
        })
    
    acknowledge.form = acknowledgeForm
const SupplierOrderController = { index, show, acknowledge }

export default SupplierOrderController