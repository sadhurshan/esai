import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Orders\SupplierShipmentController::store
 * @see app/Http/Controllers/Api/Orders/SupplierShipmentController.php:24
 * @route '/api/supplier/orders/{order}/shipments'
 */
export const store = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/supplier/orders/{order}/shipments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Orders\SupplierShipmentController::store
 * @see app/Http/Controllers/Api/Orders/SupplierShipmentController.php:24
 * @route '/api/supplier/orders/{order}/shipments'
 */
store.url = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: args.order,
                }

    return store.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Orders\SupplierShipmentController::store
 * @see app/Http/Controllers/Api/Orders/SupplierShipmentController.php:24
 * @route '/api/supplier/orders/{order}/shipments'
 */
store.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Orders\SupplierShipmentController::store
 * @see app/Http/Controllers/Api/Orders/SupplierShipmentController.php:24
 * @route '/api/supplier/orders/{order}/shipments'
 */
    const storeForm = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Orders\SupplierShipmentController::store
 * @see app/Http/Controllers/Api/Orders/SupplierShipmentController.php:24
 * @route '/api/supplier/orders/{order}/shipments'
 */
        storeForm.post = (args: { order: string | number } | [order: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\Orders\SupplierShipmentController::updateStatus
 * @see app/Http/Controllers/Api/Orders/SupplierShipmentController.php:76
 * @route '/api/supplier/shipments/{shipment}/status'
 */
export const updateStatus = (args: { shipment: string | number } | [shipment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatus.url(args, options),
    method: 'post',
})

updateStatus.definition = {
    methods: ["post"],
    url: '/api/supplier/shipments/{shipment}/status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Orders\SupplierShipmentController::updateStatus
 * @see app/Http/Controllers/Api/Orders/SupplierShipmentController.php:76
 * @route '/api/supplier/shipments/{shipment}/status'
 */
updateStatus.url = (args: { shipment: string | number } | [shipment: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shipment: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    shipment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        shipment: args.shipment,
                }

    return updateStatus.definition.url
            .replace('{shipment}', parsedArgs.shipment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Orders\SupplierShipmentController::updateStatus
 * @see app/Http/Controllers/Api/Orders/SupplierShipmentController.php:76
 * @route '/api/supplier/shipments/{shipment}/status'
 */
updateStatus.post = (args: { shipment: string | number } | [shipment: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatus.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Orders\SupplierShipmentController::updateStatus
 * @see app/Http/Controllers/Api/Orders/SupplierShipmentController.php:76
 * @route '/api/supplier/shipments/{shipment}/status'
 */
    const updateStatusForm = (args: { shipment: string | number } | [shipment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Orders\SupplierShipmentController::updateStatus
 * @see app/Http/Controllers/Api/Orders/SupplierShipmentController.php:76
 * @route '/api/supplier/shipments/{shipment}/status'
 */
        updateStatusForm.post = (args: { shipment: string | number } | [shipment: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, options),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
const SupplierShipmentController = { store, updateStatus }

export default SupplierShipmentController