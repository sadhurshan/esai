import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::index
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
export const index = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/purchase-orders/{purchaseOrder}/change-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::index
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
index.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return index.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::index
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
index.get = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::index
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
index.head = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\PoChangeOrderController::index
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
    const indexForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\PoChangeOrderController::index
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
        indexForm.get = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\PoChangeOrderController::index
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
        indexForm.head = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::store
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:43
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
export const store = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/purchase-orders/{purchaseOrder}/change-orders',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::store
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:43
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
store.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return store.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::store
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:43
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
store.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\PoChangeOrderController::store
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:43
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
    const storeForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PoChangeOrderController::store
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:43
 * @route '/api/purchase-orders/{purchaseOrder}/change-orders'
 */
        storeForm.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::approve
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:75
 * @route '/api/change-orders/{changeOrder}/approve'
 */
export const approve = (args: { changeOrder: number | { id: number } } | [changeOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: approve.url(args, options),
    method: 'put',
})

approve.definition = {
    methods: ["put"],
    url: '/api/change-orders/{changeOrder}/approve',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::approve
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:75
 * @route '/api/change-orders/{changeOrder}/approve'
 */
approve.url = (args: { changeOrder: number | { id: number } } | [changeOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { changeOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { changeOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    changeOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        changeOrder: typeof args.changeOrder === 'object'
                ? args.changeOrder.id
                : args.changeOrder,
                }

    return approve.definition.url
            .replace('{changeOrder}', parsedArgs.changeOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::approve
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:75
 * @route '/api/change-orders/{changeOrder}/approve'
 */
approve.put = (args: { changeOrder: number | { id: number } } | [changeOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: approve.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\PoChangeOrderController::approve
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:75
 * @route '/api/change-orders/{changeOrder}/approve'
 */
    const approveForm = (args: { changeOrder: number | { id: number } } | [changeOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PoChangeOrderController::approve
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:75
 * @route '/api/change-orders/{changeOrder}/approve'
 */
        approveForm.put = (args: { changeOrder: number | { id: number } } | [changeOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::reject
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:121
 * @route '/api/change-orders/{changeOrder}/reject'
 */
export const reject = (args: { changeOrder: number | { id: number } } | [changeOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reject.url(args, options),
    method: 'put',
})

reject.definition = {
    methods: ["put"],
    url: '/api/change-orders/{changeOrder}/reject',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::reject
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:121
 * @route '/api/change-orders/{changeOrder}/reject'
 */
reject.url = (args: { changeOrder: number | { id: number } } | [changeOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { changeOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { changeOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    changeOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        changeOrder: typeof args.changeOrder === 'object'
                ? args.changeOrder.id
                : args.changeOrder,
                }

    return reject.definition.url
            .replace('{changeOrder}', parsedArgs.changeOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PoChangeOrderController::reject
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:121
 * @route '/api/change-orders/{changeOrder}/reject'
 */
reject.put = (args: { changeOrder: number | { id: number } } | [changeOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reject.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\PoChangeOrderController::reject
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:121
 * @route '/api/change-orders/{changeOrder}/reject'
 */
    const rejectForm = (args: { changeOrder: number | { id: number } } | [changeOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PoChangeOrderController::reject
 * @see app/Http/Controllers/Api/PoChangeOrderController.php:121
 * @route '/api/change-orders/{changeOrder}/reject'
 */
        rejectForm.put = (args: { changeOrder: number | { id: number } } | [changeOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reject.form = rejectForm
const PoChangeOrderController = { index, store, approve, reject }

export default PoChangeOrderController