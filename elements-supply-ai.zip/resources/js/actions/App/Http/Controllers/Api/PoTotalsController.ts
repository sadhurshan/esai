import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\PoTotalsController::recalculate
 * @see app/Http/Controllers/Api/PoTotalsController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/recalculate'
 */
export const recalculate = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(args, options),
    method: 'post',
})

recalculate.definition = {
    methods: ["post"],
    url: '/api/purchase-orders/{purchaseOrder}/recalculate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\PoTotalsController::recalculate
 * @see app/Http/Controllers/Api/PoTotalsController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/recalculate'
 */
recalculate.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return recalculate.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PoTotalsController::recalculate
 * @see app/Http/Controllers/Api/PoTotalsController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/recalculate'
 */
recalculate.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\PoTotalsController::recalculate
 * @see app/Http/Controllers/Api/PoTotalsController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/recalculate'
 */
    const recalculateForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: recalculate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PoTotalsController::recalculate
 * @see app/Http/Controllers/Api/PoTotalsController.php:17
 * @route '/api/purchase-orders/{purchaseOrder}/recalculate'
 */
        recalculateForm.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: recalculate.url(args, options),
            method: 'post',
        })
    
    recalculate.form = recalculateForm
const PoTotalsController = { recalculate }

export default PoTotalsController