import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::index
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:14
 * @route '/api/purchase-orders'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/purchase-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::index
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:14
 * @route '/api/purchase-orders'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::index
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:14
 * @route '/api/purchase-orders'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::index
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:14
 * @route '/api/purchase-orders'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\PurchaseOrderController::index
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:14
 * @route '/api/purchase-orders'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\PurchaseOrderController::index
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:14
 * @route '/api/purchase-orders'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\PurchaseOrderController::index
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:14
 * @route '/api/purchase-orders'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::send
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:77
 * @route '/api/purchase-orders/{purchaseOrder}/send'
 */
export const send = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/api/purchase-orders/{purchaseOrder}/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::send
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:77
 * @route '/api/purchase-orders/{purchaseOrder}/send'
 */
send.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return send.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::send
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:77
 * @route '/api/purchase-orders/{purchaseOrder}/send'
 */
send.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\PurchaseOrderController::send
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:77
 * @route '/api/purchase-orders/{purchaseOrder}/send'
 */
    const sendForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PurchaseOrderController::send
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:77
 * @route '/api/purchase-orders/{purchaseOrder}/send'
 */
        sendForm.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(args, options),
            method: 'post',
        })
    
    send.form = sendForm
/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::acknowledge
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:102
 * @route '/api/purchase-orders/{purchaseOrder}/acknowledge'
 */
export const acknowledge = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: acknowledge.url(args, options),
    method: 'post',
})

acknowledge.definition = {
    methods: ["post"],
    url: '/api/purchase-orders/{purchaseOrder}/acknowledge',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::acknowledge
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:102
 * @route '/api/purchase-orders/{purchaseOrder}/acknowledge'
 */
acknowledge.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return acknowledge.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::acknowledge
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:102
 * @route '/api/purchase-orders/{purchaseOrder}/acknowledge'
 */
acknowledge.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: acknowledge.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\PurchaseOrderController::acknowledge
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:102
 * @route '/api/purchase-orders/{purchaseOrder}/acknowledge'
 */
    const acknowledgeForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: acknowledge.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PurchaseOrderController::acknowledge
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:102
 * @route '/api/purchase-orders/{purchaseOrder}/acknowledge'
 */
        acknowledgeForm.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: acknowledge.url(args, options),
            method: 'post',
        })
    
    acknowledge.form = acknowledgeForm
/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::show
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:56
 * @route '/api/purchase-orders/{purchaseOrder}'
 */
export const show = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/purchase-orders/{purchaseOrder}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::show
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:56
 * @route '/api/purchase-orders/{purchaseOrder}'
 */
show.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return show.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::show
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:56
 * @route '/api/purchase-orders/{purchaseOrder}'
 */
show.get = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\PurchaseOrderController::show
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:56
 * @route '/api/purchase-orders/{purchaseOrder}'
 */
show.head = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\PurchaseOrderController::show
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:56
 * @route '/api/purchase-orders/{purchaseOrder}'
 */
    const showForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\PurchaseOrderController::show
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:56
 * @route '/api/purchase-orders/{purchaseOrder}'
 */
        showForm.get = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\PurchaseOrderController::show
 * @see app/Http/Controllers/Api/PurchaseOrderController.php:56
 * @route '/api/purchase-orders/{purchaseOrder}'
 */
        showForm.head = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const PurchaseOrderController = { index, send, acknowledge, show }

export default PurchaseOrderController