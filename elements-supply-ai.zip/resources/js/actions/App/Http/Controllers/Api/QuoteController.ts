import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:19
 * @route '/api/rfqs/{rfq}/quotes'
 */
export const index = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}/quotes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:19
 * @route '/api/rfqs/{rfq}/quotes'
 */
index.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return index.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:19
 * @route '/api/rfqs/{rfq}/quotes'
 */
index.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:19
 * @route '/api/rfqs/{rfq}/quotes'
 */
index.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:19
 * @route '/api/rfqs/{rfq}/quotes'
 */
    const indexForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:19
 * @route '/api/rfqs/{rfq}/quotes'
 */
        indexForm.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:19
 * @route '/api/rfqs/{rfq}/quotes'
 */
        indexForm.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\QuoteController::store
 * @see app/Http/Controllers/Api/QuoteController.php:39
 * @route '/api/quotes'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/quotes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::store
 * @see app/Http/Controllers/Api/QuoteController.php:39
 * @route '/api/quotes'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::store
 * @see app/Http/Controllers/Api/QuoteController.php:39
 * @route '/api/quotes'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::store
 * @see app/Http/Controllers/Api/QuoteController.php:39
 * @route '/api/quotes'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::store
 * @see app/Http/Controllers/Api/QuoteController.php:39
 * @route '/api/quotes'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const QuoteController = { index, store }

export default QuoteController