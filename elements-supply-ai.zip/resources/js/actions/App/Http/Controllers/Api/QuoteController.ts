import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:40
 * @route '/api/rfqs/{rfq}/quotes'
 */
export const index = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}/quotes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:40
 * @route '/api/rfqs/{rfq}/quotes'
 */
index.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return index.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:40
 * @route '/api/rfqs/{rfq}/quotes'
 */
index.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:40
 * @route '/api/rfqs/{rfq}/quotes'
 */
index.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:40
 * @route '/api/rfqs/{rfq}/quotes'
 */
    const indexForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:40
 * @route '/api/rfqs/{rfq}/quotes'
 */
        indexForm.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\QuoteController::index
 * @see app/Http/Controllers/Api/QuoteController.php:40
 * @route '/api/rfqs/{rfq}/quotes'
 */
        indexForm.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\QuoteController::compare
 * @see app/Http/Controllers/Api/QuoteController.php:244
 * @route '/api/rfqs/{rfq}/quotes/compare'
 */
export const compare = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: compare.url(args, options),
    method: 'get',
})

compare.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}/quotes/compare',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::compare
 * @see app/Http/Controllers/Api/QuoteController.php:244
 * @route '/api/rfqs/{rfq}/quotes/compare'
 */
compare.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return compare.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::compare
 * @see app/Http/Controllers/Api/QuoteController.php:244
 * @route '/api/rfqs/{rfq}/quotes/compare'
 */
compare.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: compare.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\QuoteController::compare
 * @see app/Http/Controllers/Api/QuoteController.php:244
 * @route '/api/rfqs/{rfq}/quotes/compare'
 */
compare.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: compare.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::compare
 * @see app/Http/Controllers/Api/QuoteController.php:244
 * @route '/api/rfqs/{rfq}/quotes/compare'
 */
    const compareForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: compare.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::compare
 * @see app/Http/Controllers/Api/QuoteController.php:244
 * @route '/api/rfqs/{rfq}/quotes/compare'
 */
        compareForm.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: compare.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\QuoteController::compare
 * @see app/Http/Controllers/Api/QuoteController.php:244
 * @route '/api/rfqs/{rfq}/quotes/compare'
 */
        compareForm.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: compare.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    compare.form = compareForm
/**
* @see \App\Http\Controllers\Api\QuoteController::storeStandalone
 * @see app/Http/Controllers/Api/QuoteController.php:100
 * @route '/api/quotes'
 */
export const storeStandalone = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStandalone.url(options),
    method: 'post',
})

storeStandalone.definition = {
    methods: ["post"],
    url: '/api/quotes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::storeStandalone
 * @see app/Http/Controllers/Api/QuoteController.php:100
 * @route '/api/quotes'
 */
storeStandalone.url = (options?: RouteQueryOptions) => {
    return storeStandalone.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::storeStandalone
 * @see app/Http/Controllers/Api/QuoteController.php:100
 * @route '/api/quotes'
 */
storeStandalone.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeStandalone.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::storeStandalone
 * @see app/Http/Controllers/Api/QuoteController.php:100
 * @route '/api/quotes'
 */
    const storeStandaloneForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeStandalone.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::storeStandalone
 * @see app/Http/Controllers/Api/QuoteController.php:100
 * @route '/api/quotes'
 */
        storeStandaloneForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeStandalone.url(options),
            method: 'post',
        })
    
    storeStandalone.form = storeStandaloneForm
/**
* @see \App\Http\Controllers\Api\QuoteController::submitStandalone
 * @see app/Http/Controllers/Api/QuoteController.php:105
 * @route '/api/quotes/{quote}/submit'
 */
export const submitStandalone = (args: { quote: string | number } | [quote: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitStandalone.url(args, options),
    method: 'post',
})

submitStandalone.definition = {
    methods: ["post"],
    url: '/api/quotes/{quote}/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::submitStandalone
 * @see app/Http/Controllers/Api/QuoteController.php:105
 * @route '/api/quotes/{quote}/submit'
 */
submitStandalone.url = (args: { quote: string | number } | [quote: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { quote: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    quote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quote: args.quote,
                }

    return submitStandalone.definition.url
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::submitStandalone
 * @see app/Http/Controllers/Api/QuoteController.php:105
 * @route '/api/quotes/{quote}/submit'
 */
submitStandalone.post = (args: { quote: string | number } | [quote: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitStandalone.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::submitStandalone
 * @see app/Http/Controllers/Api/QuoteController.php:105
 * @route '/api/quotes/{quote}/submit'
 */
    const submitStandaloneForm = (args: { quote: string | number } | [quote: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submitStandalone.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::submitStandalone
 * @see app/Http/Controllers/Api/QuoteController.php:105
 * @route '/api/quotes/{quote}/submit'
 */
        submitStandaloneForm.post = (args: { quote: string | number } | [quote: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submitStandalone.url(args, options),
            method: 'post',
        })
    
    submitStandalone.form = submitStandaloneForm
/**
* @see \App\Http\Controllers\Api\QuoteController::store
 * @see app/Http/Controllers/Api/QuoteController.php:95
 * @route '/api/rfqs/{rfq}/quotes'
 */
export const store = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/rfqs/{rfq}/quotes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::store
 * @see app/Http/Controllers/Api/QuoteController.php:95
 * @route '/api/rfqs/{rfq}/quotes'
 */
store.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return store.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::store
 * @see app/Http/Controllers/Api/QuoteController.php:95
 * @route '/api/rfqs/{rfq}/quotes'
 */
store.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::store
 * @see app/Http/Controllers/Api/QuoteController.php:95
 * @route '/api/rfqs/{rfq}/quotes'
 */
    const storeForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::store
 * @see app/Http/Controllers/Api/QuoteController.php:95
 * @route '/api/rfqs/{rfq}/quotes'
 */
        storeForm.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\QuoteController::submit
 * @see app/Http/Controllers/Api/QuoteController.php:122
 * @route '/api/rfqs/{rfq}/quotes/{quote}'
 */
export const submit = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: submit.url(args, options),
    method: 'put',
})

submit.definition = {
    methods: ["put"],
    url: '/api/rfqs/{rfq}/quotes/{quote}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::submit
 * @see app/Http/Controllers/Api/QuoteController.php:122
 * @route '/api/rfqs/{rfq}/quotes/{quote}'
 */
submit.url = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                    quote: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                                quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                }

    return submit.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::submit
 * @see app/Http/Controllers/Api/QuoteController.php:122
 * @route '/api/rfqs/{rfq}/quotes/{quote}'
 */
submit.put = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: submit.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::submit
 * @see app/Http/Controllers/Api/QuoteController.php:122
 * @route '/api/rfqs/{rfq}/quotes/{quote}'
 */
    const submitForm = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::submit
 * @see app/Http/Controllers/Api/QuoteController.php:122
 * @route '/api/rfqs/{rfq}/quotes/{quote}'
 */
        submitForm.put = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    submit.form = submitForm
/**
* @see \App\Http\Controllers\Api\QuoteController::updateDraft
 * @see app/Http/Controllers/Api/QuoteController.php:155
 * @route '/api/rfqs/{rfq}/quotes/{quote}/draft'
 */
export const updateDraft = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDraft.url(args, options),
    method: 'patch',
})

updateDraft.definition = {
    methods: ["patch"],
    url: '/api/rfqs/{rfq}/quotes/{quote}/draft',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::updateDraft
 * @see app/Http/Controllers/Api/QuoteController.php:155
 * @route '/api/rfqs/{rfq}/quotes/{quote}/draft'
 */
updateDraft.url = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                    quote: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                                quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                }

    return updateDraft.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::updateDraft
 * @see app/Http/Controllers/Api/QuoteController.php:155
 * @route '/api/rfqs/{rfq}/quotes/{quote}/draft'
 */
updateDraft.patch = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDraft.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::updateDraft
 * @see app/Http/Controllers/Api/QuoteController.php:155
 * @route '/api/rfqs/{rfq}/quotes/{quote}/draft'
 */
    const updateDraftForm = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDraft.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::updateDraft
 * @see app/Http/Controllers/Api/QuoteController.php:155
 * @route '/api/rfqs/{rfq}/quotes/{quote}/draft'
 */
        updateDraftForm.patch = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDraft.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateDraft.form = updateDraftForm
/**
* @see \App\Http\Controllers\Api\QuoteController::withdraw
 * @see app/Http/Controllers/Api/QuoteController.php:197
 * @route '/api/rfqs/{rfq}/quotes/{quote}'
 */
const withdrawc582fabfb2091941fe1cd4fd6b1046a6 = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: withdrawc582fabfb2091941fe1cd4fd6b1046a6.url(args, options),
    method: 'patch',
})

withdrawc582fabfb2091941fe1cd4fd6b1046a6.definition = {
    methods: ["patch"],
    url: '/api/rfqs/{rfq}/quotes/{quote}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::withdraw
 * @see app/Http/Controllers/Api/QuoteController.php:197
 * @route '/api/rfqs/{rfq}/quotes/{quote}'
 */
withdrawc582fabfb2091941fe1cd4fd6b1046a6.url = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                    quote: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                                quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                }

    return withdrawc582fabfb2091941fe1cd4fd6b1046a6.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::withdraw
 * @see app/Http/Controllers/Api/QuoteController.php:197
 * @route '/api/rfqs/{rfq}/quotes/{quote}'
 */
withdrawc582fabfb2091941fe1cd4fd6b1046a6.patch = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: withdrawc582fabfb2091941fe1cd4fd6b1046a6.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::withdraw
 * @see app/Http/Controllers/Api/QuoteController.php:197
 * @route '/api/rfqs/{rfq}/quotes/{quote}'
 */
    const withdrawc582fabfb2091941fe1cd4fd6b1046a6Form = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: withdrawc582fabfb2091941fe1cd4fd6b1046a6.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::withdraw
 * @see app/Http/Controllers/Api/QuoteController.php:197
 * @route '/api/rfqs/{rfq}/quotes/{quote}'
 */
        withdrawc582fabfb2091941fe1cd4fd6b1046a6Form.patch = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: withdrawc582fabfb2091941fe1cd4fd6b1046a6.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    withdrawc582fabfb2091941fe1cd4fd6b1046a6.form = withdrawc582fabfb2091941fe1cd4fd6b1046a6Form
    /**
* @see \App\Http\Controllers\Api\QuoteController::withdraw
 * @see app/Http/Controllers/Api/QuoteController.php:197
 * @route '/api/rfqs/{rfq}/quotes/{quote}/withdraw'
 */
const withdraw26b7cb9389576fe44cadd7c10fad2202 = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: withdraw26b7cb9389576fe44cadd7c10fad2202.url(args, options),
    method: 'post',
})

withdraw26b7cb9389576fe44cadd7c10fad2202.definition = {
    methods: ["post"],
    url: '/api/rfqs/{rfq}/quotes/{quote}/withdraw',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::withdraw
 * @see app/Http/Controllers/Api/QuoteController.php:197
 * @route '/api/rfqs/{rfq}/quotes/{quote}/withdraw'
 */
withdraw26b7cb9389576fe44cadd7c10fad2202.url = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                    quote: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                                quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                }

    return withdraw26b7cb9389576fe44cadd7c10fad2202.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::withdraw
 * @see app/Http/Controllers/Api/QuoteController.php:197
 * @route '/api/rfqs/{rfq}/quotes/{quote}/withdraw'
 */
withdraw26b7cb9389576fe44cadd7c10fad2202.post = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: withdraw26b7cb9389576fe44cadd7c10fad2202.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::withdraw
 * @see app/Http/Controllers/Api/QuoteController.php:197
 * @route '/api/rfqs/{rfq}/quotes/{quote}/withdraw'
 */
    const withdraw26b7cb9389576fe44cadd7c10fad2202Form = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: withdraw26b7cb9389576fe44cadd7c10fad2202.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::withdraw
 * @see app/Http/Controllers/Api/QuoteController.php:197
 * @route '/api/rfqs/{rfq}/quotes/{quote}/withdraw'
 */
        withdraw26b7cb9389576fe44cadd7c10fad2202Form.post = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: withdraw26b7cb9389576fe44cadd7c10fad2202.url(args, options),
            method: 'post',
        })
    
    withdraw26b7cb9389576fe44cadd7c10fad2202.form = withdraw26b7cb9389576fe44cadd7c10fad2202Form

export const withdraw = {
    '/api/rfqs/{rfq}/quotes/{quote}': withdrawc582fabfb2091941fe1cd4fd6b1046a6,
    '/api/rfqs/{rfq}/quotes/{quote}/withdraw': withdraw26b7cb9389576fe44cadd7c10fad2202,
}

/**
* @see \App\Http\Controllers\Api\QuoteController::show
 * @see app/Http/Controllers/Api/QuoteController.php:73
 * @route '/api/quotes/{quote}'
 */
export const show = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/quotes/{quote}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\QuoteController::show
 * @see app/Http/Controllers/Api/QuoteController.php:73
 * @route '/api/quotes/{quote}'
 */
show.url = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { quote: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { quote: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    quote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                }

    return show.definition.url
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteController::show
 * @see app/Http/Controllers/Api/QuoteController.php:73
 * @route '/api/quotes/{quote}'
 */
show.get = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\QuoteController::show
 * @see app/Http/Controllers/Api/QuoteController.php:73
 * @route '/api/quotes/{quote}'
 */
show.head = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\QuoteController::show
 * @see app/Http/Controllers/Api/QuoteController.php:73
 * @route '/api/quotes/{quote}'
 */
    const showForm = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteController::show
 * @see app/Http/Controllers/Api/QuoteController.php:73
 * @route '/api/quotes/{quote}'
 */
        showForm.get = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\QuoteController::show
 * @see app/Http/Controllers/Api/QuoteController.php:73
 * @route '/api/quotes/{quote}'
 */
        showForm.head = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const QuoteController = { index, compare, storeStandalone, submitStandalone, store, submit, updateDraft, withdraw, show }

export default QuoteController