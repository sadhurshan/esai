import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\QuoteLineController::store
 * @see app/Http/Controllers/Api/QuoteLineController.php:21
 * @route '/api/quotes/{quote}/lines'
 */
export const store = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/quotes/{quote}/lines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuoteLineController::store
 * @see app/Http/Controllers/Api/QuoteLineController.php:21
 * @route '/api/quotes/{quote}/lines'
 */
store.url = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { quote: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { quote: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    quote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                }

    return store.definition.url
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteLineController::store
 * @see app/Http/Controllers/Api/QuoteLineController.php:21
 * @route '/api/quotes/{quote}/lines'
 */
store.post = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuoteLineController::store
 * @see app/Http/Controllers/Api/QuoteLineController.php:21
 * @route '/api/quotes/{quote}/lines'
 */
    const storeForm = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteLineController::store
 * @see app/Http/Controllers/Api/QuoteLineController.php:21
 * @route '/api/quotes/{quote}/lines'
 */
        storeForm.post = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\QuoteLineController::update
 * @see app/Http/Controllers/Api/QuoteLineController.php:45
 * @route '/api/quotes/{quote}/lines/{quoteItem}'
 */
export const update = (args: { quote: number | { id: number }, quoteItem: number | { id: number } } | [quote: number | { id: number }, quoteItem: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/quotes/{quote}/lines/{quoteItem}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\QuoteLineController::update
 * @see app/Http/Controllers/Api/QuoteLineController.php:45
 * @route '/api/quotes/{quote}/lines/{quoteItem}'
 */
update.url = (args: { quote: number | { id: number }, quoteItem: number | { id: number } } | [quote: number | { id: number }, quoteItem: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    quote: args[0],
                    quoteItem: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                                quoteItem: typeof args.quoteItem === 'object'
                ? args.quoteItem.id
                : args.quoteItem,
                }

    return update.definition.url
            .replace('{quote}', parsedArgs.quote.toString())
            .replace('{quoteItem}', parsedArgs.quoteItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteLineController::update
 * @see app/Http/Controllers/Api/QuoteLineController.php:45
 * @route '/api/quotes/{quote}/lines/{quoteItem}'
 */
update.put = (args: { quote: number | { id: number }, quoteItem: number | { id: number } } | [quote: number | { id: number }, quoteItem: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\QuoteLineController::update
 * @see app/Http/Controllers/Api/QuoteLineController.php:45
 * @route '/api/quotes/{quote}/lines/{quoteItem}'
 */
    const updateForm = (args: { quote: number | { id: number }, quoteItem: number | { id: number } } | [quote: number | { id: number }, quoteItem: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteLineController::update
 * @see app/Http/Controllers/Api/QuoteLineController.php:45
 * @route '/api/quotes/{quote}/lines/{quoteItem}'
 */
        updateForm.put = (args: { quote: number | { id: number }, quoteItem: number | { id: number } } | [quote: number | { id: number }, quoteItem: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\QuoteLineController::destroy
 * @see app/Http/Controllers/Api/QuoteLineController.php:73
 * @route '/api/quotes/{quote}/lines/{quoteItem}'
 */
export const destroy = (args: { quote: number | { id: number }, quoteItem: number | { id: number } } | [quote: number | { id: number }, quoteItem: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/quotes/{quote}/lines/{quoteItem}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\QuoteLineController::destroy
 * @see app/Http/Controllers/Api/QuoteLineController.php:73
 * @route '/api/quotes/{quote}/lines/{quoteItem}'
 */
destroy.url = (args: { quote: number | { id: number }, quoteItem: number | { id: number } } | [quote: number | { id: number }, quoteItem: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    quote: args[0],
                    quoteItem: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                                quoteItem: typeof args.quoteItem === 'object'
                ? args.quoteItem.id
                : args.quoteItem,
                }

    return destroy.definition.url
            .replace('{quote}', parsedArgs.quote.toString())
            .replace('{quoteItem}', parsedArgs.quoteItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteLineController::destroy
 * @see app/Http/Controllers/Api/QuoteLineController.php:73
 * @route '/api/quotes/{quote}/lines/{quoteItem}'
 */
destroy.delete = (args: { quote: number | { id: number }, quoteItem: number | { id: number } } | [quote: number | { id: number }, quoteItem: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\QuoteLineController::destroy
 * @see app/Http/Controllers/Api/QuoteLineController.php:73
 * @route '/api/quotes/{quote}/lines/{quoteItem}'
 */
    const destroyForm = (args: { quote: number | { id: number }, quoteItem: number | { id: number } } | [quote: number | { id: number }, quoteItem: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteLineController::destroy
 * @see app/Http/Controllers/Api/QuoteLineController.php:73
 * @route '/api/quotes/{quote}/lines/{quoteItem}'
 */
        destroyForm.delete = (args: { quote: number | { id: number }, quoteItem: number | { id: number } } | [quote: number | { id: number }, quoteItem: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const QuoteLineController = { store, update, destroy }

export default QuoteLineController