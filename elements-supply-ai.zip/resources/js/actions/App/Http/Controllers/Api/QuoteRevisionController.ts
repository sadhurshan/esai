import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\QuoteRevisionController::index
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:19
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
export const index = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}/quotes/{quote}/revisions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\QuoteRevisionController::index
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:19
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
index.url = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                    quote: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                                quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                }

    return index.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteRevisionController::index
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:19
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
index.get = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\QuoteRevisionController::index
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:19
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
index.head = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\QuoteRevisionController::index
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:19
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
    const indexForm = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteRevisionController::index
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:19
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
        indexForm.get = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\QuoteRevisionController::index
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:19
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
        indexForm.head = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\QuoteRevisionController::store
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:46
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
export const store = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/rfqs/{rfq}/quotes/{quote}/revisions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuoteRevisionController::store
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:46
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
store.url = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                    quote: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                                quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                }

    return store.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteRevisionController::store
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:46
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
store.post = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuoteRevisionController::store
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:46
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
    const storeForm = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteRevisionController::store
 * @see app/Http/Controllers/Api/QuoteRevisionController.php:46
 * @route '/api/rfqs/{rfq}/quotes/{quote}/revisions'
 */
        storeForm.post = (args: { rfq: number | { id: number }, quote: number | { id: number } } | [rfq: number | { id: number }, quote: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const QuoteRevisionController = { index, store }

export default QuoteRevisionController