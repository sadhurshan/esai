import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RfpProposalController::index
 * @see app/Http/Controllers/Api/RfpProposalController.php:25
 * @route '/api/rfps/{rfp}/proposals'
 */
export const index = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfps/{rfp}/proposals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RfpProposalController::index
 * @see app/Http/Controllers/Api/RfpProposalController.php:25
 * @route '/api/rfps/{rfp}/proposals'
 */
index.url = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfp: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfp: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfp: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfp: typeof args.rfp === 'object'
                ? args.rfp.id
                : args.rfp,
                }

    return index.definition.url
            .replace('{rfp}', parsedArgs.rfp.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfpProposalController::index
 * @see app/Http/Controllers/Api/RfpProposalController.php:25
 * @route '/api/rfps/{rfp}/proposals'
 */
index.get = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RfpProposalController::index
 * @see app/Http/Controllers/Api/RfpProposalController.php:25
 * @route '/api/rfps/{rfp}/proposals'
 */
index.head = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RfpProposalController::index
 * @see app/Http/Controllers/Api/RfpProposalController.php:25
 * @route '/api/rfps/{rfp}/proposals'
 */
    const indexForm = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RfpProposalController::index
 * @see app/Http/Controllers/Api/RfpProposalController.php:25
 * @route '/api/rfps/{rfp}/proposals'
 */
        indexForm.get = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RfpProposalController::index
 * @see app/Http/Controllers/Api/RfpProposalController.php:25
 * @route '/api/rfps/{rfp}/proposals'
 */
        indexForm.head = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\RfpProposalController::store
 * @see app/Http/Controllers/Api/RfpProposalController.php:60
 * @route '/api/rfps/{rfp}/proposals'
 */
export const store = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/rfps/{rfp}/proposals',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfpProposalController::store
 * @see app/Http/Controllers/Api/RfpProposalController.php:60
 * @route '/api/rfps/{rfp}/proposals'
 */
store.url = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfp: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfp: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfp: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfp: typeof args.rfp === 'object'
                ? args.rfp.id
                : args.rfp,
                }

    return store.definition.url
            .replace('{rfp}', parsedArgs.rfp.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfpProposalController::store
 * @see app/Http/Controllers/Api/RfpProposalController.php:60
 * @route '/api/rfps/{rfp}/proposals'
 */
store.post = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfpProposalController::store
 * @see app/Http/Controllers/Api/RfpProposalController.php:60
 * @route '/api/rfps/{rfp}/proposals'
 */
    const storeForm = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfpProposalController::store
 * @see app/Http/Controllers/Api/RfpProposalController.php:60
 * @route '/api/rfps/{rfp}/proposals'
 */
        storeForm.post = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const RfpProposalController = { index, store }

export default RfpProposalController