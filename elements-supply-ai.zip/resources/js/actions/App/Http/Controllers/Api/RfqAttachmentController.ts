import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RfqAttachmentController::index
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:19
 * @route '/api/rfqs/{rfq}/attachments'
 */
export const index = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}/attachments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RfqAttachmentController::index
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:19
 * @route '/api/rfqs/{rfq}/attachments'
 */
index.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return index.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqAttachmentController::index
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:19
 * @route '/api/rfqs/{rfq}/attachments'
 */
index.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RfqAttachmentController::index
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:19
 * @route '/api/rfqs/{rfq}/attachments'
 */
index.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RfqAttachmentController::index
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:19
 * @route '/api/rfqs/{rfq}/attachments'
 */
    const indexForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RfqAttachmentController::index
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:19
 * @route '/api/rfqs/{rfq}/attachments'
 */
        indexForm.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RfqAttachmentController::index
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:19
 * @route '/api/rfqs/{rfq}/attachments'
 */
        indexForm.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\RfqAttachmentController::store
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:48
 * @route '/api/rfqs/{rfq}/attachments'
 */
export const store = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/rfqs/{rfq}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfqAttachmentController::store
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:48
 * @route '/api/rfqs/{rfq}/attachments'
 */
store.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return store.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqAttachmentController::store
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:48
 * @route '/api/rfqs/{rfq}/attachments'
 */
store.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfqAttachmentController::store
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:48
 * @route '/api/rfqs/{rfq}/attachments'
 */
    const storeForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfqAttachmentController::store
 * @see app/Http/Controllers/Api/RfqAttachmentController.php:48
 * @route '/api/rfqs/{rfq}/attachments'
 */
        storeForm.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const RfqAttachmentController = { index, store }

export default RfqAttachmentController