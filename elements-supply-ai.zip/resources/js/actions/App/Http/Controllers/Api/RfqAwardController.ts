import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RfqAwardController::awardLines
 * @see app/Http/Controllers/Api/RfqAwardController.php:20
 * @route '/api/rfqs/{rfq}/award-lines'
 */
export const awardLines = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: awardLines.url(args, options),
    method: 'post',
})

awardLines.definition = {
    methods: ["post"],
    url: '/api/rfqs/{rfq}/award-lines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfqAwardController::awardLines
 * @see app/Http/Controllers/Api/RfqAwardController.php:20
 * @route '/api/rfqs/{rfq}/award-lines'
 */
awardLines.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return awardLines.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqAwardController::awardLines
 * @see app/Http/Controllers/Api/RfqAwardController.php:20
 * @route '/api/rfqs/{rfq}/award-lines'
 */
awardLines.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: awardLines.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfqAwardController::awardLines
 * @see app/Http/Controllers/Api/RfqAwardController.php:20
 * @route '/api/rfqs/{rfq}/award-lines'
 */
    const awardLinesForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: awardLines.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfqAwardController::awardLines
 * @see app/Http/Controllers/Api/RfqAwardController.php:20
 * @route '/api/rfqs/{rfq}/award-lines'
 */
        awardLinesForm.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: awardLines.url(args, options),
            method: 'post',
        })
    
    awardLines.form = awardLinesForm
const RfqAwardController = { awardLines }

export default RfqAwardController