import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RfqInvitationController::index
 * @see app/Http/Controllers/Api/RfqInvitationController.php:36
 * @route '/api/rfqs/{rfq}/invitations'
 */
export const index = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}/invitations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RfqInvitationController::index
 * @see app/Http/Controllers/Api/RfqInvitationController.php:36
 * @route '/api/rfqs/{rfq}/invitations'
 */
index.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return index.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqInvitationController::index
 * @see app/Http/Controllers/Api/RfqInvitationController.php:36
 * @route '/api/rfqs/{rfq}/invitations'
 */
index.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RfqInvitationController::index
 * @see app/Http/Controllers/Api/RfqInvitationController.php:36
 * @route '/api/rfqs/{rfq}/invitations'
 */
index.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RfqInvitationController::index
 * @see app/Http/Controllers/Api/RfqInvitationController.php:36
 * @route '/api/rfqs/{rfq}/invitations'
 */
    const indexForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RfqInvitationController::index
 * @see app/Http/Controllers/Api/RfqInvitationController.php:36
 * @route '/api/rfqs/{rfq}/invitations'
 */
        indexForm.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RfqInvitationController::index
 * @see app/Http/Controllers/Api/RfqInvitationController.php:36
 * @route '/api/rfqs/{rfq}/invitations'
 */
        indexForm.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\RfqInvitationController::store
 * @see app/Http/Controllers/Api/RfqInvitationController.php:16
 * @route '/api/rfqs/{rfq}/invitations'
 */
export const store = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/rfqs/{rfq}/invitations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfqInvitationController::store
 * @see app/Http/Controllers/Api/RfqInvitationController.php:16
 * @route '/api/rfqs/{rfq}/invitations'
 */
store.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return store.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqInvitationController::store
 * @see app/Http/Controllers/Api/RfqInvitationController.php:16
 * @route '/api/rfqs/{rfq}/invitations'
 */
store.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfqInvitationController::store
 * @see app/Http/Controllers/Api/RfqInvitationController.php:16
 * @route '/api/rfqs/{rfq}/invitations'
 */
    const storeForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfqInvitationController::store
 * @see app/Http/Controllers/Api/RfqInvitationController.php:16
 * @route '/api/rfqs/{rfq}/invitations'
 */
        storeForm.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const RfqInvitationController = { index, store }

export default RfqInvitationController