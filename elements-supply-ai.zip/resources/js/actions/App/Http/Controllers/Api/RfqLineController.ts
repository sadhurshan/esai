import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RfqLineController::index
 * @see app/Http/Controllers/Api/RfqLineController.php:25
 * @route '/api/rfqs/{rfq}/lines'
 */
export const index = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}/lines',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RfqLineController::index
 * @see app/Http/Controllers/Api/RfqLineController.php:25
 * @route '/api/rfqs/{rfq}/lines'
 */
index.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return index.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqLineController::index
 * @see app/Http/Controllers/Api/RfqLineController.php:25
 * @route '/api/rfqs/{rfq}/lines'
 */
index.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RfqLineController::index
 * @see app/Http/Controllers/Api/RfqLineController.php:25
 * @route '/api/rfqs/{rfq}/lines'
 */
index.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RfqLineController::index
 * @see app/Http/Controllers/Api/RfqLineController.php:25
 * @route '/api/rfqs/{rfq}/lines'
 */
    const indexForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RfqLineController::index
 * @see app/Http/Controllers/Api/RfqLineController.php:25
 * @route '/api/rfqs/{rfq}/lines'
 */
        indexForm.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RfqLineController::index
 * @see app/Http/Controllers/Api/RfqLineController.php:25
 * @route '/api/rfqs/{rfq}/lines'
 */
        indexForm.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\RfqLineController::store
 * @see app/Http/Controllers/Api/RfqLineController.php:47
 * @route '/api/rfqs/{rfq}/lines'
 */
export const store = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/rfqs/{rfq}/lines',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfqLineController::store
 * @see app/Http/Controllers/Api/RfqLineController.php:47
 * @route '/api/rfqs/{rfq}/lines'
 */
store.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return store.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqLineController::store
 * @see app/Http/Controllers/Api/RfqLineController.php:47
 * @route '/api/rfqs/{rfq}/lines'
 */
store.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfqLineController::store
 * @see app/Http/Controllers/Api/RfqLineController.php:47
 * @route '/api/rfqs/{rfq}/lines'
 */
    const storeForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfqLineController::store
 * @see app/Http/Controllers/Api/RfqLineController.php:47
 * @route '/api/rfqs/{rfq}/lines'
 */
        storeForm.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\RfqLineController::update
 * @see app/Http/Controllers/Api/RfqLineController.php:93
 * @route '/api/rfqs/{rfq}/lines/{line}'
 */
export const update = (args: { rfq: number | { id: number }, line: string | number } | [rfq: number | { id: number }, line: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/rfqs/{rfq}/lines/{line}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\RfqLineController::update
 * @see app/Http/Controllers/Api/RfqLineController.php:93
 * @route '/api/rfqs/{rfq}/lines/{line}'
 */
update.url = (args: { rfq: number | { id: number }, line: string | number } | [rfq: number | { id: number }, line: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                    line: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                                line: args.line,
                }

    return update.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace('{line}', parsedArgs.line.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqLineController::update
 * @see app/Http/Controllers/Api/RfqLineController.php:93
 * @route '/api/rfqs/{rfq}/lines/{line}'
 */
update.put = (args: { rfq: number | { id: number }, line: string | number } | [rfq: number | { id: number }, line: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\RfqLineController::update
 * @see app/Http/Controllers/Api/RfqLineController.php:93
 * @route '/api/rfqs/{rfq}/lines/{line}'
 */
    const updateForm = (args: { rfq: number | { id: number }, line: string | number } | [rfq: number | { id: number }, line: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfqLineController::update
 * @see app/Http/Controllers/Api/RfqLineController.php:93
 * @route '/api/rfqs/{rfq}/lines/{line}'
 */
        updateForm.put = (args: { rfq: number | { id: number }, line: string | number } | [rfq: number | { id: number }, line: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\RfqLineController::destroy
 * @see app/Http/Controllers/Api/RfqLineController.php:157
 * @route '/api/rfqs/{rfq}/lines/{line}'
 */
export const destroy = (args: { rfq: number | { id: number }, line: string | number } | [rfq: number | { id: number }, line: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/rfqs/{rfq}/lines/{line}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\RfqLineController::destroy
 * @see app/Http/Controllers/Api/RfqLineController.php:157
 * @route '/api/rfqs/{rfq}/lines/{line}'
 */
destroy.url = (args: { rfq: number | { id: number }, line: string | number } | [rfq: number | { id: number }, line: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                    line: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                                line: args.line,
                }

    return destroy.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace('{line}', parsedArgs.line.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqLineController::destroy
 * @see app/Http/Controllers/Api/RfqLineController.php:157
 * @route '/api/rfqs/{rfq}/lines/{line}'
 */
destroy.delete = (args: { rfq: number | { id: number }, line: string | number } | [rfq: number | { id: number }, line: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\RfqLineController::destroy
 * @see app/Http/Controllers/Api/RfqLineController.php:157
 * @route '/api/rfqs/{rfq}/lines/{line}'
 */
    const destroyForm = (args: { rfq: number | { id: number }, line: string | number } | [rfq: number | { id: number }, line: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfqLineController::destroy
 * @see app/Http/Controllers/Api/RfqLineController.php:157
 * @route '/api/rfqs/{rfq}/lines/{line}'
 */
        destroyForm.delete = (args: { rfq: number | { id: number }, line: string | number } | [rfq: number | { id: number }, line: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const RfqLineController = { index, store, update, destroy }

export default RfqLineController