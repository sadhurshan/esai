import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RmaController::index
 * @see app/Http/Controllers/Api/RmaController.php:28
 * @route '/api/rmas'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rmas',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RmaController::index
 * @see app/Http/Controllers/Api/RmaController.php:28
 * @route '/api/rmas'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RmaController::index
 * @see app/Http/Controllers/Api/RmaController.php:28
 * @route '/api/rmas'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RmaController::index
 * @see app/Http/Controllers/Api/RmaController.php:28
 * @route '/api/rmas'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RmaController::index
 * @see app/Http/Controllers/Api/RmaController.php:28
 * @route '/api/rmas'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RmaController::index
 * @see app/Http/Controllers/Api/RmaController.php:28
 * @route '/api/rmas'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RmaController::index
 * @see app/Http/Controllers/Api/RmaController.php:28
 * @route '/api/rmas'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\RmaController::store
 * @see app/Http/Controllers/Api/RmaController.php:96
 * @route '/api/rmas/purchase-orders/{purchaseOrder}'
 */
export const store = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/rmas/purchase-orders/{purchaseOrder}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RmaController::store
 * @see app/Http/Controllers/Api/RmaController.php:96
 * @route '/api/rmas/purchase-orders/{purchaseOrder}'
 */
store.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return store.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RmaController::store
 * @see app/Http/Controllers/Api/RmaController.php:96
 * @route '/api/rmas/purchase-orders/{purchaseOrder}'
 */
store.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RmaController::store
 * @see app/Http/Controllers/Api/RmaController.php:96
 * @route '/api/rmas/purchase-orders/{purchaseOrder}'
 */
    const storeForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RmaController::store
 * @see app/Http/Controllers/Api/RmaController.php:96
 * @route '/api/rmas/purchase-orders/{purchaseOrder}'
 */
        storeForm.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\RmaController::show
 * @see app/Http/Controllers/Api/RmaController.php:163
 * @route '/api/rmas/{rma}'
 */
export const show = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/rmas/{rma}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RmaController::show
 * @see app/Http/Controllers/Api/RmaController.php:163
 * @route '/api/rmas/{rma}'
 */
show.url = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rma: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rma: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rma: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rma: typeof args.rma === 'object'
                ? args.rma.id
                : args.rma,
                }

    return show.definition.url
            .replace('{rma}', parsedArgs.rma.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RmaController::show
 * @see app/Http/Controllers/Api/RmaController.php:163
 * @route '/api/rmas/{rma}'
 */
show.get = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RmaController::show
 * @see app/Http/Controllers/Api/RmaController.php:163
 * @route '/api/rmas/{rma}'
 */
show.head = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RmaController::show
 * @see app/Http/Controllers/Api/RmaController.php:163
 * @route '/api/rmas/{rma}'
 */
    const showForm = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RmaController::show
 * @see app/Http/Controllers/Api/RmaController.php:163
 * @route '/api/rmas/{rma}'
 */
        showForm.get = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RmaController::show
 * @see app/Http/Controllers/Api/RmaController.php:163
 * @route '/api/rmas/{rma}'
 */
        showForm.head = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\RmaController::review
 * @see app/Http/Controllers/Api/RmaController.php:182
 * @route '/api/rmas/{rma}/review'
 */
export const review = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: review.url(args, options),
    method: 'post',
})

review.definition = {
    methods: ["post"],
    url: '/api/rmas/{rma}/review',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RmaController::review
 * @see app/Http/Controllers/Api/RmaController.php:182
 * @route '/api/rmas/{rma}/review'
 */
review.url = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rma: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rma: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rma: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rma: typeof args.rma === 'object'
                ? args.rma.id
                : args.rma,
                }

    return review.definition.url
            .replace('{rma}', parsedArgs.rma.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RmaController::review
 * @see app/Http/Controllers/Api/RmaController.php:182
 * @route '/api/rmas/{rma}/review'
 */
review.post = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: review.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RmaController::review
 * @see app/Http/Controllers/Api/RmaController.php:182
 * @route '/api/rmas/{rma}/review'
 */
    const reviewForm = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: review.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RmaController::review
 * @see app/Http/Controllers/Api/RmaController.php:182
 * @route '/api/rmas/{rma}/review'
 */
        reviewForm.post = (args: { rma: number | { id: number } } | [rma: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: review.url(args, options),
            method: 'post',
        })
    
    review.form = reviewForm
const RmaController = { index, store, show, review }

export default RmaController