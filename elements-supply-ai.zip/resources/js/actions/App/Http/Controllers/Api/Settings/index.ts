import CompanySettingsController from './CompanySettingsController'
import NumberingSettingsController from './NumberingSettingsController'
const Settings = {
    CompanySettingsController: Object.assign(CompanySettingsController, CompanySettingsController),
NumberingSettingsController: Object.assign(NumberingSettingsController, NumberingSettingsController),
}

export default Settings