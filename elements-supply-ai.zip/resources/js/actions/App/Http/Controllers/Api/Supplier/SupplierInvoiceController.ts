import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::index
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:33
 * @route '/api/supplier/invoices'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/supplier/invoices',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::index
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:33
 * @route '/api/supplier/invoices'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::index
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:33
 * @route '/api/supplier/invoices'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::index
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:33
 * @route '/api/supplier/invoices'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::index
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:33
 * @route '/api/supplier/invoices'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::index
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:33
 * @route '/api/supplier/invoices'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::index
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:33
 * @route '/api/supplier/invoices'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::show
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:94
 * @route '/api/supplier/invoices/{invoice}'
 */
export const show = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/supplier/invoices/{invoice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::show
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:94
 * @route '/api/supplier/invoices/{invoice}'
 */
show.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return show.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::show
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:94
 * @route '/api/supplier/invoices/{invoice}'
 */
show.get = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::show
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:94
 * @route '/api/supplier/invoices/{invoice}'
 */
show.head = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::show
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:94
 * @route '/api/supplier/invoices/{invoice}'
 */
    const showForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::show
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:94
 * @route '/api/supplier/invoices/{invoice}'
 */
        showForm.get = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::show
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:94
 * @route '/api/supplier/invoices/{invoice}'
 */
        showForm.head = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::update
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:161
 * @route '/api/supplier/invoices/{invoice}'
 */
export const update = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/supplier/invoices/{invoice}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::update
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:161
 * @route '/api/supplier/invoices/{invoice}'
 */
update.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return update.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::update
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:161
 * @route '/api/supplier/invoices/{invoice}'
 */
update.put = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::update
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:161
 * @route '/api/supplier/invoices/{invoice}'
 */
    const updateForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::update
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:161
 * @route '/api/supplier/invoices/{invoice}'
 */
        updateForm.put = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::submit
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:225
 * @route '/api/supplier/invoices/{invoice}/submit'
 */
export const submit = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/api/supplier/invoices/{invoice}/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::submit
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:225
 * @route '/api/supplier/invoices/{invoice}/submit'
 */
submit.url = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invoice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invoice: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invoice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invoice: typeof args.invoice === 'object'
                ? args.invoice.id
                : args.invoice,
                }

    return submit.definition.url
            .replace('{invoice}', parsedArgs.invoice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::submit
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:225
 * @route '/api/supplier/invoices/{invoice}/submit'
 */
submit.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::submit
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:225
 * @route '/api/supplier/invoices/{invoice}/submit'
 */
    const submitForm = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::submit
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:225
 * @route '/api/supplier/invoices/{invoice}/submit'
 */
        submitForm.post = (args: { invoice: number | { id: number } } | [invoice: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, options),
            method: 'post',
        })
    
    submit.form = submitForm
/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::store
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:114
 * @route '/api/supplier/purchase-orders/{purchaseOrder}/invoices'
 */
export const store = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/supplier/purchase-orders/{purchaseOrder}/invoices',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::store
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:114
 * @route '/api/supplier/purchase-orders/{purchaseOrder}/invoices'
 */
store.url = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { purchaseOrder: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: typeof args.purchaseOrder === 'object'
                ? args.purchaseOrder.id
                : args.purchaseOrder,
                }

    return store.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::store
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:114
 * @route '/api/supplier/purchase-orders/{purchaseOrder}/invoices'
 */
store.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::store
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:114
 * @route '/api/supplier/purchase-orders/{purchaseOrder}/invoices'
 */
    const storeForm = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Supplier\SupplierInvoiceController::store
 * @see app/Http/Controllers/Api/Supplier/SupplierInvoiceController.php:114
 * @route '/api/supplier/purchase-orders/{purchaseOrder}/invoices'
 */
        storeForm.post = (args: { purchaseOrder: number | { id: number } } | [purchaseOrder: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const SupplierInvoiceController = { index, show, update, submit, store }

export default SupplierInvoiceController