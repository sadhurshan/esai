import SupplierInvoiceController from './SupplierInvoiceController'
const Supplier = {
    SupplierInvoiceController: Object.assign(SupplierInvoiceController, SupplierInvoiceController),
}

export default Supplier