import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\UserCompanyController::index
 * @see app/Http/Controllers/Api/UserCompanyController.php:19
 * @route '/api/me/companies'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/me/companies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\UserCompanyController::index
 * @see app/Http/Controllers/Api/UserCompanyController.php:19
 * @route '/api/me/companies'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\UserCompanyController::index
 * @see app/Http/Controllers/Api/UserCompanyController.php:19
 * @route '/api/me/companies'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\UserCompanyController::index
 * @see app/Http/Controllers/Api/UserCompanyController.php:19
 * @route '/api/me/companies'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\UserCompanyController::index
 * @see app/Http/Controllers/Api/UserCompanyController.php:19
 * @route '/api/me/companies'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\UserCompanyController::index
 * @see app/Http/Controllers/Api/UserCompanyController.php:19
 * @route '/api/me/companies'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\UserCompanyController::index
 * @see app/Http/Controllers/Api/UserCompanyController.php:19
 * @route '/api/me/companies'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\UserCompanyController::switchMethod
 * @see app/Http/Controllers/Api/UserCompanyController.php:37
 * @route '/api/me/companies/switch'
 */
export const switchMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: switchMethod.url(options),
    method: 'post',
})

switchMethod.definition = {
    methods: ["post"],
    url: '/api/me/companies/switch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\UserCompanyController::switchMethod
 * @see app/Http/Controllers/Api/UserCompanyController.php:37
 * @route '/api/me/companies/switch'
 */
switchMethod.url = (options?: RouteQueryOptions) => {
    return switchMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\UserCompanyController::switchMethod
 * @see app/Http/Controllers/Api/UserCompanyController.php:37
 * @route '/api/me/companies/switch'
 */
switchMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: switchMethod.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\UserCompanyController::switchMethod
 * @see app/Http/Controllers/Api/UserCompanyController.php:37
 * @route '/api/me/companies/switch'
 */
    const switchMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: switchMethod.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\UserCompanyController::switchMethod
 * @see app/Http/Controllers/Api/UserCompanyController.php:37
 * @route '/api/me/companies/switch'
 */
        switchMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: switchMethod.url(options),
            method: 'post',
        })
    
    switchMethod.form = switchMethodForm
const UserCompanyController = { index, switchMethod, switch: switchMethod }

export default UserCompanyController