import HealthController from './HealthController'
import FileController from './FileController'
import SupplierController from './SupplierController'
import SupplierApplicationController from './SupplierApplicationController'
import RFQController from './RFQController'
import RfqInvitationController from './RfqInvitationController'
import QuoteController from './QuoteController'
import AwardController from './AwardController'
import OrderController from './OrderController'
import PurchaseOrderController from './PurchaseOrderController'
import PoChangeOrderController from './PoChangeOrderController'
import CompanyRegistrationController from './CompanyRegistrationController'
import CompanyDocumentController from './CompanyDocumentController'
import Admin from './Admin'
import DocumentController from './DocumentController'
import Billing from './Billing'
const Api = {
    HealthController: Object.assign(HealthController, HealthController),
FileController: Object.assign(FileController, FileController),
SupplierController: Object.assign(SupplierController, SupplierController),
SupplierApplicationController: Object.assign(SupplierApplicationController, SupplierApplicationController),
RFQController: Object.assign(RFQController, RFQController),
RfqInvitationController: Object.assign(RfqInvitationController, RfqInvitationController),
QuoteController: Object.assign(QuoteController, QuoteController),
AwardController: Object.assign(AwardController, AwardController),
OrderController: Object.assign(OrderController, OrderController),
PurchaseOrderController: Object.assign(PurchaseOrderController, PurchaseOrderController),
PoChangeOrderController: Object.assign(PoChangeOrderController, PoChangeOrderController),
CompanyRegistrationController: Object.assign(CompanyRegistrationController, CompanyRegistrationController),
CompanyDocumentController: Object.assign(CompanyDocumentController, CompanyDocumentController),
Admin: Object.assign(Admin, Admin),
DocumentController: Object.assign(DocumentController, DocumentController),
Billing: Object.assign(Billing, Billing),
}

export default Api