import ProfileController from './ProfileController'
import PasswordController from './PasswordController'
import PlanController from './PlanController'
import TwoFactorAuthenticationController from './TwoFactorAuthenticationController'
const Settings = {
    ProfileController: Object.assign(ProfileController, ProfileController),
PasswordController: Object.assign(PasswordController, PasswordController),
PlanController: Object.assign(PlanController, PlanController),
TwoFactorAuthenticationController: Object.assign(TwoFactorAuthenticationController, TwoFactorAuthenticationController),
}

export default Settings