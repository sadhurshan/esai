import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/'
 */
const ViewController980bb49ee7ae63891f1d891d2fbcf1c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

ViewController980bb49ee7ae63891f1d891d2fbcf1c9.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/'
 */
ViewController980bb49ee7ae63891f1d891d2fbcf1c9.url = (options?: RouteQueryOptions) => {
    return ViewController980bb49ee7ae63891f1d891d2fbcf1c9.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/'
 */
ViewController980bb49ee7ae63891f1d891d2fbcf1c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/'
 */
ViewController980bb49ee7ae63891f1d891d2fbcf1c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/'
 */
    const ViewController980bb49ee7ae63891f1d891d2fbcf1c9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/'
 */
        ViewController980bb49ee7ae63891f1d891d2fbcf1c9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/'
 */
        ViewController980bb49ee7ae63891f1d891d2fbcf1c9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController980bb49ee7ae63891f1d891d2fbcf1c9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController980bb49ee7ae63891f1d891d2fbcf1c9.form = ViewController980bb49ee7ae63891f1d891d2fbcf1c9Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/company-registration'
 */
const ViewController91e800219838cbdce3ba159ec9de6d77 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController91e800219838cbdce3ba159ec9de6d77.url(options),
    method: 'get',
})

ViewController91e800219838cbdce3ba159ec9de6d77.definition = {
    methods: ["get","head"],
    url: '/company-registration',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/company-registration'
 */
ViewController91e800219838cbdce3ba159ec9de6d77.url = (options?: RouteQueryOptions) => {
    return ViewController91e800219838cbdce3ba159ec9de6d77.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/company-registration'
 */
ViewController91e800219838cbdce3ba159ec9de6d77.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController91e800219838cbdce3ba159ec9de6d77.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/company-registration'
 */
ViewController91e800219838cbdce3ba159ec9de6d77.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController91e800219838cbdce3ba159ec9de6d77.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/company-registration'
 */
    const ViewController91e800219838cbdce3ba159ec9de6d77Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController91e800219838cbdce3ba159ec9de6d77.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/company-registration'
 */
        ViewController91e800219838cbdce3ba159ec9de6d77Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController91e800219838cbdce3ba159ec9de6d77.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/company-registration'
 */
        ViewController91e800219838cbdce3ba159ec9de6d77Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController91e800219838cbdce3ba159ec9de6d77.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController91e800219838cbdce3ba159ec9de6d77.form = ViewController91e800219838cbdce3ba159ec9de6d77Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/setup/plan'
 */
const ViewControllere6451a994ab145209e65f05d56dc7560 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewControllere6451a994ab145209e65f05d56dc7560.url(options),
    method: 'get',
})

ViewControllere6451a994ab145209e65f05d56dc7560.definition = {
    methods: ["get","head"],
    url: '/app/setup/plan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/setup/plan'
 */
ViewControllere6451a994ab145209e65f05d56dc7560.url = (options?: RouteQueryOptions) => {
    return ViewControllere6451a994ab145209e65f05d56dc7560.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/setup/plan'
 */
ViewControllere6451a994ab145209e65f05d56dc7560.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewControllere6451a994ab145209e65f05d56dc7560.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/setup/plan'
 */
ViewControllere6451a994ab145209e65f05d56dc7560.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewControllere6451a994ab145209e65f05d56dc7560.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/setup/plan'
 */
    const ViewControllere6451a994ab145209e65f05d56dc7560Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewControllere6451a994ab145209e65f05d56dc7560.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/setup/plan'
 */
        ViewControllere6451a994ab145209e65f05d56dc7560Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewControllere6451a994ab145209e65f05d56dc7560.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/setup/plan'
 */
        ViewControllere6451a994ab145209e65f05d56dc7560Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewControllere6451a994ab145209e65f05d56dc7560.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewControllere6451a994ab145209e65f05d56dc7560.form = ViewControllere6451a994ab145209e65f05d56dc7560Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app'
 */
const ViewController66c7f35ef69d84111bb599576cd05b30 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController66c7f35ef69d84111bb599576cd05b30.url(options),
    method: 'get',
})

ViewController66c7f35ef69d84111bb599576cd05b30.definition = {
    methods: ["get","head"],
    url: '/app',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app'
 */
ViewController66c7f35ef69d84111bb599576cd05b30.url = (options?: RouteQueryOptions) => {
    return ViewController66c7f35ef69d84111bb599576cd05b30.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app'
 */
ViewController66c7f35ef69d84111bb599576cd05b30.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController66c7f35ef69d84111bb599576cd05b30.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app'
 */
ViewController66c7f35ef69d84111bb599576cd05b30.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController66c7f35ef69d84111bb599576cd05b30.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app'
 */
    const ViewController66c7f35ef69d84111bb599576cd05b30Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController66c7f35ef69d84111bb599576cd05b30.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app'
 */
        ViewController66c7f35ef69d84111bb599576cd05b30Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController66c7f35ef69d84111bb599576cd05b30.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app'
 */
        ViewController66c7f35ef69d84111bb599576cd05b30Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController66c7f35ef69d84111bb599576cd05b30.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController66c7f35ef69d84111bb599576cd05b30.form = ViewController66c7f35ef69d84111bb599576cd05b30Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/suppliers'
 */
const ViewController82b371ad0797e3609e4f0a8e993cff32 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController82b371ad0797e3609e4f0a8e993cff32.url(options),
    method: 'get',
})

ViewController82b371ad0797e3609e4f0a8e993cff32.definition = {
    methods: ["get","head"],
    url: '/app/suppliers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/suppliers'
 */
ViewController82b371ad0797e3609e4f0a8e993cff32.url = (options?: RouteQueryOptions) => {
    return ViewController82b371ad0797e3609e4f0a8e993cff32.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/suppliers'
 */
ViewController82b371ad0797e3609e4f0a8e993cff32.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController82b371ad0797e3609e4f0a8e993cff32.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/suppliers'
 */
ViewController82b371ad0797e3609e4f0a8e993cff32.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController82b371ad0797e3609e4f0a8e993cff32.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/suppliers'
 */
    const ViewController82b371ad0797e3609e4f0a8e993cff32Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController82b371ad0797e3609e4f0a8e993cff32.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/suppliers'
 */
        ViewController82b371ad0797e3609e4f0a8e993cff32Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController82b371ad0797e3609e4f0a8e993cff32.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/suppliers'
 */
        ViewController82b371ad0797e3609e4f0a8e993cff32Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController82b371ad0797e3609e4f0a8e993cff32.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController82b371ad0797e3609e4f0a8e993cff32.form = ViewController82b371ad0797e3609e4f0a8e993cff32Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs'
 */
const ViewControllerbe687d9981e78fa7658b6810bbd9e8c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.url(options),
    method: 'get',
})

ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.definition = {
    methods: ["get","head"],
    url: '/app/rfqs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs'
 */
ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.url = (options?: RouteQueryOptions) => {
    return ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs'
 */
ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs'
 */
ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs'
 */
    const ViewControllerbe687d9981e78fa7658b6810bbd9e8c9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs'
 */
        ViewControllerbe687d9981e78fa7658b6810bbd9e8c9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs'
 */
        ViewControllerbe687d9981e78fa7658b6810bbd9e8c9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewControllerbe687d9981e78fa7658b6810bbd9e8c9.form = ViewControllerbe687d9981e78fa7658b6810bbd9e8c9Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/new'
 */
const ViewController2b0eaa4a98375198f364da77ff3ee68b = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController2b0eaa4a98375198f364da77ff3ee68b.url(options),
    method: 'get',
})

ViewController2b0eaa4a98375198f364da77ff3ee68b.definition = {
    methods: ["get","head"],
    url: '/app/rfqs/new',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/new'
 */
ViewController2b0eaa4a98375198f364da77ff3ee68b.url = (options?: RouteQueryOptions) => {
    return ViewController2b0eaa4a98375198f364da77ff3ee68b.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/new'
 */
ViewController2b0eaa4a98375198f364da77ff3ee68b.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController2b0eaa4a98375198f364da77ff3ee68b.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/new'
 */
ViewController2b0eaa4a98375198f364da77ff3ee68b.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController2b0eaa4a98375198f364da77ff3ee68b.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/new'
 */
    const ViewController2b0eaa4a98375198f364da77ff3ee68bForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController2b0eaa4a98375198f364da77ff3ee68b.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/new'
 */
        ViewController2b0eaa4a98375198f364da77ff3ee68bForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController2b0eaa4a98375198f364da77ff3ee68b.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/new'
 */
        ViewController2b0eaa4a98375198f364da77ff3ee68bForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController2b0eaa4a98375198f364da77ff3ee68b.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController2b0eaa4a98375198f364da77ff3ee68b.form = ViewController2b0eaa4a98375198f364da77ff3ee68bForm
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}'
 */
const ViewControllera34d4477d72f3b4670b2cf56c71eb017 = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewControllera34d4477d72f3b4670b2cf56c71eb017.url(args, options),
    method: 'get',
})

ViewControllera34d4477d72f3b4670b2cf56c71eb017.definition = {
    methods: ["get","head"],
    url: '/app/rfqs/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}'
 */
ViewControllera34d4477d72f3b4670b2cf56c71eb017.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return ViewControllera34d4477d72f3b4670b2cf56c71eb017.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}'
 */
ViewControllera34d4477d72f3b4670b2cf56c71eb017.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewControllera34d4477d72f3b4670b2cf56c71eb017.url(args, options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}'
 */
ViewControllera34d4477d72f3b4670b2cf56c71eb017.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewControllera34d4477d72f3b4670b2cf56c71eb017.url(args, options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}'
 */
    const ViewControllera34d4477d72f3b4670b2cf56c71eb017Form = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewControllera34d4477d72f3b4670b2cf56c71eb017.url(args, options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}'
 */
        ViewControllera34d4477d72f3b4670b2cf56c71eb017Form.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewControllera34d4477d72f3b4670b2cf56c71eb017.url(args, options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}'
 */
        ViewControllera34d4477d72f3b4670b2cf56c71eb017Form.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewControllera34d4477d72f3b4670b2cf56c71eb017.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewControllera34d4477d72f3b4670b2cf56c71eb017.form = ViewControllera34d4477d72f3b4670b2cf56c71eb017Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/open'
 */
const ViewController7b855be10679fba3eb654355e281a9c6 = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController7b855be10679fba3eb654355e281a9c6.url(args, options),
    method: 'get',
})

ViewController7b855be10679fba3eb654355e281a9c6.definition = {
    methods: ["get","head"],
    url: '/app/rfqs/{id}/open',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/open'
 */
ViewController7b855be10679fba3eb654355e281a9c6.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return ViewController7b855be10679fba3eb654355e281a9c6.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/open'
 */
ViewController7b855be10679fba3eb654355e281a9c6.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController7b855be10679fba3eb654355e281a9c6.url(args, options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/open'
 */
ViewController7b855be10679fba3eb654355e281a9c6.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController7b855be10679fba3eb654355e281a9c6.url(args, options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/open'
 */
    const ViewController7b855be10679fba3eb654355e281a9c6Form = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController7b855be10679fba3eb654355e281a9c6.url(args, options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/open'
 */
        ViewController7b855be10679fba3eb654355e281a9c6Form.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController7b855be10679fba3eb654355e281a9c6.url(args, options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/open'
 */
        ViewController7b855be10679fba3eb654355e281a9c6Form.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController7b855be10679fba3eb654355e281a9c6.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController7b855be10679fba3eb654355e281a9c6.form = ViewController7b855be10679fba3eb654355e281a9c6Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/compare'
 */
const ViewController43cf5392a8faa14475ee1fe998abea08 = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController43cf5392a8faa14475ee1fe998abea08.url(args, options),
    method: 'get',
})

ViewController43cf5392a8faa14475ee1fe998abea08.definition = {
    methods: ["get","head"],
    url: '/app/rfqs/{id}/compare',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/compare'
 */
ViewController43cf5392a8faa14475ee1fe998abea08.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return ViewController43cf5392a8faa14475ee1fe998abea08.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/compare'
 */
ViewController43cf5392a8faa14475ee1fe998abea08.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController43cf5392a8faa14475ee1fe998abea08.url(args, options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/compare'
 */
ViewController43cf5392a8faa14475ee1fe998abea08.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController43cf5392a8faa14475ee1fe998abea08.url(args, options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/compare'
 */
    const ViewController43cf5392a8faa14475ee1fe998abea08Form = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController43cf5392a8faa14475ee1fe998abea08.url(args, options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/compare'
 */
        ViewController43cf5392a8faa14475ee1fe998abea08Form.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController43cf5392a8faa14475ee1fe998abea08.url(args, options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/rfqs/{id}/compare'
 */
        ViewController43cf5392a8faa14475ee1fe998abea08Form.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController43cf5392a8faa14475ee1fe998abea08.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController43cf5392a8faa14475ee1fe998abea08.form = ViewController43cf5392a8faa14475ee1fe998abea08Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/orders'
 */
const ViewController338fb484fa231a7c18fa4ef90dadff0a = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController338fb484fa231a7c18fa4ef90dadff0a.url(options),
    method: 'get',
})

ViewController338fb484fa231a7c18fa4ef90dadff0a.definition = {
    methods: ["get","head"],
    url: '/app/orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/orders'
 */
ViewController338fb484fa231a7c18fa4ef90dadff0a.url = (options?: RouteQueryOptions) => {
    return ViewController338fb484fa231a7c18fa4ef90dadff0a.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/orders'
 */
ViewController338fb484fa231a7c18fa4ef90dadff0a.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController338fb484fa231a7c18fa4ef90dadff0a.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/orders'
 */
ViewController338fb484fa231a7c18fa4ef90dadff0a.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController338fb484fa231a7c18fa4ef90dadff0a.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/orders'
 */
    const ViewController338fb484fa231a7c18fa4ef90dadff0aForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController338fb484fa231a7c18fa4ef90dadff0a.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/orders'
 */
        ViewController338fb484fa231a7c18fa4ef90dadff0aForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController338fb484fa231a7c18fa4ef90dadff0a.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/orders'
 */
        ViewController338fb484fa231a7c18fa4ef90dadff0aForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController338fb484fa231a7c18fa4ef90dadff0a.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController338fb484fa231a7c18fa4ef90dadff0a.form = ViewController338fb484fa231a7c18fa4ef90dadff0aForm
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders'
 */
const ViewController71c1836bf5e57bbe1bc96d1d6b71130f = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController71c1836bf5e57bbe1bc96d1d6b71130f.url(options),
    method: 'get',
})

ViewController71c1836bf5e57bbe1bc96d1d6b71130f.definition = {
    methods: ["get","head"],
    url: '/app/purchase-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders'
 */
ViewController71c1836bf5e57bbe1bc96d1d6b71130f.url = (options?: RouteQueryOptions) => {
    return ViewController71c1836bf5e57bbe1bc96d1d6b71130f.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders'
 */
ViewController71c1836bf5e57bbe1bc96d1d6b71130f.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController71c1836bf5e57bbe1bc96d1d6b71130f.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders'
 */
ViewController71c1836bf5e57bbe1bc96d1d6b71130f.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController71c1836bf5e57bbe1bc96d1d6b71130f.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders'
 */
    const ViewController71c1836bf5e57bbe1bc96d1d6b71130fForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController71c1836bf5e57bbe1bc96d1d6b71130f.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders'
 */
        ViewController71c1836bf5e57bbe1bc96d1d6b71130fForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController71c1836bf5e57bbe1bc96d1d6b71130f.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders'
 */
        ViewController71c1836bf5e57bbe1bc96d1d6b71130fForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController71c1836bf5e57bbe1bc96d1d6b71130f.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController71c1836bf5e57bbe1bc96d1d6b71130f.form = ViewController71c1836bf5e57bbe1bc96d1d6b71130fForm
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/supplier'
 */
const ViewControllerbd12b930aa56f61336a19043a2764567 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewControllerbd12b930aa56f61336a19043a2764567.url(options),
    method: 'get',
})

ViewControllerbd12b930aa56f61336a19043a2764567.definition = {
    methods: ["get","head"],
    url: '/app/purchase-orders/supplier',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/supplier'
 */
ViewControllerbd12b930aa56f61336a19043a2764567.url = (options?: RouteQueryOptions) => {
    return ViewControllerbd12b930aa56f61336a19043a2764567.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/supplier'
 */
ViewControllerbd12b930aa56f61336a19043a2764567.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewControllerbd12b930aa56f61336a19043a2764567.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/supplier'
 */
ViewControllerbd12b930aa56f61336a19043a2764567.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewControllerbd12b930aa56f61336a19043a2764567.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/supplier'
 */
    const ViewControllerbd12b930aa56f61336a19043a2764567Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewControllerbd12b930aa56f61336a19043a2764567.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/supplier'
 */
        ViewControllerbd12b930aa56f61336a19043a2764567Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewControllerbd12b930aa56f61336a19043a2764567.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/supplier'
 */
        ViewControllerbd12b930aa56f61336a19043a2764567Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewControllerbd12b930aa56f61336a19043a2764567.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewControllerbd12b930aa56f61336a19043a2764567.form = ViewControllerbd12b930aa56f61336a19043a2764567Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}/supplier'
 */
const ViewController366d0a44e6ca1f9ba073bfe6184a5229 = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController366d0a44e6ca1f9ba073bfe6184a5229.url(args, options),
    method: 'get',
})

ViewController366d0a44e6ca1f9ba073bfe6184a5229.definition = {
    methods: ["get","head"],
    url: '/app/purchase-orders/{id}/supplier',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}/supplier'
 */
ViewController366d0a44e6ca1f9ba073bfe6184a5229.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return ViewController366d0a44e6ca1f9ba073bfe6184a5229.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}/supplier'
 */
ViewController366d0a44e6ca1f9ba073bfe6184a5229.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController366d0a44e6ca1f9ba073bfe6184a5229.url(args, options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}/supplier'
 */
ViewController366d0a44e6ca1f9ba073bfe6184a5229.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController366d0a44e6ca1f9ba073bfe6184a5229.url(args, options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}/supplier'
 */
    const ViewController366d0a44e6ca1f9ba073bfe6184a5229Form = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController366d0a44e6ca1f9ba073bfe6184a5229.url(args, options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}/supplier'
 */
        ViewController366d0a44e6ca1f9ba073bfe6184a5229Form.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController366d0a44e6ca1f9ba073bfe6184a5229.url(args, options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}/supplier'
 */
        ViewController366d0a44e6ca1f9ba073bfe6184a5229Form.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController366d0a44e6ca1f9ba073bfe6184a5229.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController366d0a44e6ca1f9ba073bfe6184a5229.form = ViewController366d0a44e6ca1f9ba073bfe6184a5229Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}'
 */
const ViewController80db2698da85b957ffcfea3affbc59a4 = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController80db2698da85b957ffcfea3affbc59a4.url(args, options),
    method: 'get',
})

ViewController80db2698da85b957ffcfea3affbc59a4.definition = {
    methods: ["get","head"],
    url: '/app/purchase-orders/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}'
 */
ViewController80db2698da85b957ffcfea3affbc59a4.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return ViewController80db2698da85b957ffcfea3affbc59a4.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}'
 */
ViewController80db2698da85b957ffcfea3affbc59a4.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController80db2698da85b957ffcfea3affbc59a4.url(args, options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}'
 */
ViewController80db2698da85b957ffcfea3affbc59a4.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController80db2698da85b957ffcfea3affbc59a4.url(args, options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}'
 */
    const ViewController80db2698da85b957ffcfea3affbc59a4Form = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController80db2698da85b957ffcfea3affbc59a4.url(args, options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}'
 */
        ViewController80db2698da85b957ffcfea3affbc59a4Form.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController80db2698da85b957ffcfea3affbc59a4.url(args, options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/purchase-orders/{id}'
 */
        ViewController80db2698da85b957ffcfea3affbc59a4Form.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController80db2698da85b957ffcfea3affbc59a4.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController80db2698da85b957ffcfea3affbc59a4.form = ViewController80db2698da85b957ffcfea3affbc59a4Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/supplier/company-profile'
 */
const ViewController43849362a16b6060d5318b45a9aade6e = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController43849362a16b6060d5318b45a9aade6e.url(options),
    method: 'get',
})

ViewController43849362a16b6060d5318b45a9aade6e.definition = {
    methods: ["get","head"],
    url: '/app/supplier/company-profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/supplier/company-profile'
 */
ViewController43849362a16b6060d5318b45a9aade6e.url = (options?: RouteQueryOptions) => {
    return ViewController43849362a16b6060d5318b45a9aade6e.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/supplier/company-profile'
 */
ViewController43849362a16b6060d5318b45a9aade6e.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController43849362a16b6060d5318b45a9aade6e.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/supplier/company-profile'
 */
ViewController43849362a16b6060d5318b45a9aade6e.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController43849362a16b6060d5318b45a9aade6e.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/supplier/company-profile'
 */
    const ViewController43849362a16b6060d5318b45a9aade6eForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController43849362a16b6060d5318b45a9aade6e.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/supplier/company-profile'
 */
        ViewController43849362a16b6060d5318b45a9aade6eForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController43849362a16b6060d5318b45a9aade6e.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/supplier/company-profile'
 */
        ViewController43849362a16b6060d5318b45a9aade6eForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController43849362a16b6060d5318b45a9aade6e.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController43849362a16b6060d5318b45a9aade6e.form = ViewController43849362a16b6060d5318b45a9aade6eForm
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory'
 */
const ViewController0fb5f8741a9368dfb749529fba16c983 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController0fb5f8741a9368dfb749529fba16c983.url(options),
    method: 'get',
})

ViewController0fb5f8741a9368dfb749529fba16c983.definition = {
    methods: ["get","head"],
    url: '/app/inventory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory'
 */
ViewController0fb5f8741a9368dfb749529fba16c983.url = (options?: RouteQueryOptions) => {
    return ViewController0fb5f8741a9368dfb749529fba16c983.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory'
 */
ViewController0fb5f8741a9368dfb749529fba16c983.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController0fb5f8741a9368dfb749529fba16c983.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory'
 */
ViewController0fb5f8741a9368dfb749529fba16c983.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController0fb5f8741a9368dfb749529fba16c983.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory'
 */
    const ViewController0fb5f8741a9368dfb749529fba16c983Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController0fb5f8741a9368dfb749529fba16c983.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory'
 */
        ViewController0fb5f8741a9368dfb749529fba16c983Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController0fb5f8741a9368dfb749529fba16c983.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory'
 */
        ViewController0fb5f8741a9368dfb749529fba16c983Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController0fb5f8741a9368dfb749529fba16c983.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController0fb5f8741a9368dfb749529fba16c983.form = ViewController0fb5f8741a9368dfb749529fba16c983Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items'
 */
const ViewController9c9844b284ea9e68acc94dccad9d9104 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController9c9844b284ea9e68acc94dccad9d9104.url(options),
    method: 'get',
})

ViewController9c9844b284ea9e68acc94dccad9d9104.definition = {
    methods: ["get","head"],
    url: '/app/inventory/items',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items'
 */
ViewController9c9844b284ea9e68acc94dccad9d9104.url = (options?: RouteQueryOptions) => {
    return ViewController9c9844b284ea9e68acc94dccad9d9104.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items'
 */
ViewController9c9844b284ea9e68acc94dccad9d9104.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController9c9844b284ea9e68acc94dccad9d9104.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items'
 */
ViewController9c9844b284ea9e68acc94dccad9d9104.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController9c9844b284ea9e68acc94dccad9d9104.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items'
 */
    const ViewController9c9844b284ea9e68acc94dccad9d9104Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController9c9844b284ea9e68acc94dccad9d9104.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items'
 */
        ViewController9c9844b284ea9e68acc94dccad9d9104Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController9c9844b284ea9e68acc94dccad9d9104.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items'
 */
        ViewController9c9844b284ea9e68acc94dccad9d9104Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController9c9844b284ea9e68acc94dccad9d9104.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController9c9844b284ea9e68acc94dccad9d9104.form = ViewController9c9844b284ea9e68acc94dccad9d9104Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/new'
 */
const ViewControllerc4ff899c73f2902456517e780a1765a3 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewControllerc4ff899c73f2902456517e780a1765a3.url(options),
    method: 'get',
})

ViewControllerc4ff899c73f2902456517e780a1765a3.definition = {
    methods: ["get","head"],
    url: '/app/inventory/items/new',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/new'
 */
ViewControllerc4ff899c73f2902456517e780a1765a3.url = (options?: RouteQueryOptions) => {
    return ViewControllerc4ff899c73f2902456517e780a1765a3.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/new'
 */
ViewControllerc4ff899c73f2902456517e780a1765a3.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewControllerc4ff899c73f2902456517e780a1765a3.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/new'
 */
ViewControllerc4ff899c73f2902456517e780a1765a3.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewControllerc4ff899c73f2902456517e780a1765a3.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/new'
 */
    const ViewControllerc4ff899c73f2902456517e780a1765a3Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewControllerc4ff899c73f2902456517e780a1765a3.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/new'
 */
        ViewControllerc4ff899c73f2902456517e780a1765a3Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewControllerc4ff899c73f2902456517e780a1765a3.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/new'
 */
        ViewControllerc4ff899c73f2902456517e780a1765a3Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewControllerc4ff899c73f2902456517e780a1765a3.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewControllerc4ff899c73f2902456517e780a1765a3.form = ViewControllerc4ff899c73f2902456517e780a1765a3Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/{itemId}'
 */
const ViewController3692200bb6b44ad5f7bff27ad91a0978 = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController3692200bb6b44ad5f7bff27ad91a0978.url(args, options),
    method: 'get',
})

ViewController3692200bb6b44ad5f7bff27ad91a0978.definition = {
    methods: ["get","head"],
    url: '/app/inventory/items/{itemId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/{itemId}'
 */
ViewController3692200bb6b44ad5f7bff27ad91a0978.url = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { itemId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    itemId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        itemId: args.itemId,
                }

    return ViewController3692200bb6b44ad5f7bff27ad91a0978.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/{itemId}'
 */
ViewController3692200bb6b44ad5f7bff27ad91a0978.get = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController3692200bb6b44ad5f7bff27ad91a0978.url(args, options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/{itemId}'
 */
ViewController3692200bb6b44ad5f7bff27ad91a0978.head = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController3692200bb6b44ad5f7bff27ad91a0978.url(args, options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/{itemId}'
 */
    const ViewController3692200bb6b44ad5f7bff27ad91a0978Form = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController3692200bb6b44ad5f7bff27ad91a0978.url(args, options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/{itemId}'
 */
        ViewController3692200bb6b44ad5f7bff27ad91a0978Form.get = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController3692200bb6b44ad5f7bff27ad91a0978.url(args, options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/inventory/items/{itemId}'
 */
        ViewController3692200bb6b44ad5f7bff27ad91a0978Form.head = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController3692200bb6b44ad5f7bff27ad91a0978.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController3692200bb6b44ad5f7bff27ad91a0978.form = ViewController3692200bb6b44ad5f7bff27ad91a0978Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/admin/companies'
 */
const ViewController5fce88f78de72b0cadc96632d64d15b6 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController5fce88f78de72b0cadc96632d64d15b6.url(options),
    method: 'get',
})

ViewController5fce88f78de72b0cadc96632d64d15b6.definition = {
    methods: ["get","head"],
    url: '/app/admin/companies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/admin/companies'
 */
ViewController5fce88f78de72b0cadc96632d64d15b6.url = (options?: RouteQueryOptions) => {
    return ViewController5fce88f78de72b0cadc96632d64d15b6.definition.url + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/admin/companies'
 */
ViewController5fce88f78de72b0cadc96632d64d15b6.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController5fce88f78de72b0cadc96632d64d15b6.url(options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/admin/companies'
 */
ViewController5fce88f78de72b0cadc96632d64d15b6.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController5fce88f78de72b0cadc96632d64d15b6.url(options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/admin/companies'
 */
    const ViewController5fce88f78de72b0cadc96632d64d15b6Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController5fce88f78de72b0cadc96632d64d15b6.url(options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/admin/companies'
 */
        ViewController5fce88f78de72b0cadc96632d64d15b6Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController5fce88f78de72b0cadc96632d64d15b6.url(options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/admin/companies'
 */
        ViewController5fce88f78de72b0cadc96632d64d15b6Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController5fce88f78de72b0cadc96632d64d15b6.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController5fce88f78de72b0cadc96632d64d15b6.form = ViewController5fce88f78de72b0cadc96632d64d15b6Form
    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/{any}'
 */
const ViewController3fa9f49b454cfdee42bd9bf3a05a40f4 = (args: { any: string | number } | [any: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.url(args, options),
    method: 'get',
})

ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.definition = {
    methods: ["get","head"],
    url: '/app/{any}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/{any}'
 */
ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.url = (args: { any: string | number } | [any: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { any: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    any: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        any: args.any,
                }

    return ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.definition.url
            .replace('{any}', parsedArgs.any.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/{any}'
 */
ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.get = (args: { any: string | number } | [any: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.url(args, options),
    method: 'get',
})
/**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/{any}'
 */
ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.head = (args: { any: string | number } | [any: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.url(args, options),
    method: 'head',
})

    /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/{any}'
 */
    const ViewController3fa9f49b454cfdee42bd9bf3a05a40f4Form = (args: { any: string | number } | [any: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.url(args, options),
        method: 'get',
    })

            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/{any}'
 */
        ViewController3fa9f49b454cfdee42bd9bf3a05a40f4Form.get = (args: { any: string | number } | [any: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.url(args, options),
            method: 'get',
        })
            /**
* @see \Illuminate\Routing\ViewController::__invoke
 * @see vendor/laravel/framework/src/Illuminate/Routing/ViewController.php:32
 * @route '/app/{any}'
 */
        ViewController3fa9f49b454cfdee42bd9bf3a05a40f4Form.head = (args: { any: string | number } | [any: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ViewController3fa9f49b454cfdee42bd9bf3a05a40f4.form = ViewController3fa9f49b454cfdee42bd9bf3a05a40f4Form

const ViewController = {
    '/': ViewController980bb49ee7ae63891f1d891d2fbcf1c9,
    '/company-registration': ViewController91e800219838cbdce3ba159ec9de6d77,
    '/app/setup/plan': ViewControllere6451a994ab145209e65f05d56dc7560,
    '/app': ViewController66c7f35ef69d84111bb599576cd05b30,
    '/app/suppliers': ViewController82b371ad0797e3609e4f0a8e993cff32,
    '/app/rfqs': ViewControllerbe687d9981e78fa7658b6810bbd9e8c9,
    '/app/rfqs/new': ViewController2b0eaa4a98375198f364da77ff3ee68b,
    '/app/rfqs/{id}': ViewControllera34d4477d72f3b4670b2cf56c71eb017,
    '/app/rfqs/{id}/open': ViewController7b855be10679fba3eb654355e281a9c6,
    '/app/rfqs/{id}/compare': ViewController43cf5392a8faa14475ee1fe998abea08,
    '/app/orders': ViewController338fb484fa231a7c18fa4ef90dadff0a,
    '/app/purchase-orders': ViewController71c1836bf5e57bbe1bc96d1d6b71130f,
    '/app/purchase-orders/supplier': ViewControllerbd12b930aa56f61336a19043a2764567,
    '/app/purchase-orders/{id}/supplier': ViewController366d0a44e6ca1f9ba073bfe6184a5229,
    '/app/purchase-orders/{id}': ViewController80db2698da85b957ffcfea3affbc59a4,
    '/app/supplier/company-profile': ViewController43849362a16b6060d5318b45a9aade6e,
    '/app/inventory': ViewController0fb5f8741a9368dfb749529fba16c983,
    '/app/inventory/items': ViewController9c9844b284ea9e68acc94dccad9d9104,
    '/app/inventory/items/new': ViewControllerc4ff899c73f2902456517e780a1765a3,
    '/app/inventory/items/{itemId}': ViewController3692200bb6b44ad5f7bff27ad91a0978,
    '/app/admin/companies': ViewController5fce88f78de72b0cadc96632d64d15b6,
    '/app/{any}': ViewController3fa9f49b454cfdee42bd9bf3a05a40f4,
}

export default ViewController