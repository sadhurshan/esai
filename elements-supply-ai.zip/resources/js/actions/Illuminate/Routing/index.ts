import ViewController from './ViewController'
const Routing = {
    ViewController: Object.assign(ViewController, ViewController),
}

export default Routing