import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders'
 */
const Controllerb79d2970118d4e05b639b7e3c6c06377 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerb79d2970118d4e05b639b7e3c6c06377.url(options),
    method: 'get',
})

Controllerb79d2970118d4e05b639b7e3c6c06377.definition = {
    methods: ["get","head"],
    url: '/purchase-orders',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders'
 */
Controllerb79d2970118d4e05b639b7e3c6c06377.url = (options?: RouteQueryOptions) => {
    return Controllerb79d2970118d4e05b639b7e3c6c06377.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders'
 */
Controllerb79d2970118d4e05b639b7e3c6c06377.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerb79d2970118d4e05b639b7e3c6c06377.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders'
 */
Controllerb79d2970118d4e05b639b7e3c6c06377.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllerb79d2970118d4e05b639b7e3c6c06377.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders'
 */
    const Controllerb79d2970118d4e05b639b7e3c6c06377Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controllerb79d2970118d4e05b639b7e3c6c06377.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders'
 */
        Controllerb79d2970118d4e05b639b7e3c6c06377Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllerb79d2970118d4e05b639b7e3c6c06377.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders'
 */
        Controllerb79d2970118d4e05b639b7e3c6c06377Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllerb79d2970118d4e05b639b7e3c6c06377.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controllerb79d2970118d4e05b639b7e3c6c06377.form = Controllerb79d2970118d4e05b639b7e3c6c06377Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders/supplier'
 */
const Controller7aaf7c29bb1b3b72de92fde40fd2e1f5 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.url(options),
    method: 'get',
})

Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.definition = {
    methods: ["get","head"],
    url: '/purchase-orders/supplier',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders/supplier'
 */
Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.url = (options?: RouteQueryOptions) => {
    return Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders/supplier'
 */
Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders/supplier'
 */
Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders/supplier'
 */
    const Controller7aaf7c29bb1b3b72de92fde40fd2e1f5Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders/supplier'
 */
        Controller7aaf7c29bb1b3b72de92fde40fd2e1f5Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/purchase-orders/supplier'
 */
        Controller7aaf7c29bb1b3b72de92fde40fd2e1f5Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller7aaf7c29bb1b3b72de92fde40fd2e1f5.form = Controller7aaf7c29bb1b3b72de92fde40fd2e1f5Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
const Controller765815ee247c28ff7a6b8bd0a8c490ce = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller765815ee247c28ff7a6b8bd0a8c490ce.url(options),
    method: 'get',
})

Controller765815ee247c28ff7a6b8bd0a8c490ce.definition = {
    methods: ["get","head"],
    url: '/supplier/company-profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
Controller765815ee247c28ff7a6b8bd0a8c490ce.url = (options?: RouteQueryOptions) => {
    return Controller765815ee247c28ff7a6b8bd0a8c490ce.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
Controller765815ee247c28ff7a6b8bd0a8c490ce.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller765815ee247c28ff7a6b8bd0a8c490ce.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
Controller765815ee247c28ff7a6b8bd0a8c490ce.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller765815ee247c28ff7a6b8bd0a8c490ce.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
    const Controller765815ee247c28ff7a6b8bd0a8c490ceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller765815ee247c28ff7a6b8bd0a8c490ce.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
        Controller765815ee247c28ff7a6b8bd0a8c490ceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller765815ee247c28ff7a6b8bd0a8c490ce.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
        Controller765815ee247c28ff7a6b8bd0a8c490ceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller765815ee247c28ff7a6b8bd0a8c490ce.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller765815ee247c28ff7a6b8bd0a8c490ce.form = Controller765815ee247c28ff7a6b8bd0a8c490ceForm
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/companies'
 */
const Controller9fe6faf8b56cdbd10c6435170d61adba = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller9fe6faf8b56cdbd10c6435170d61adba.url(options),
    method: 'get',
})

Controller9fe6faf8b56cdbd10c6435170d61adba.definition = {
    methods: ["get","head"],
    url: '/admin/companies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/companies'
 */
Controller9fe6faf8b56cdbd10c6435170d61adba.url = (options?: RouteQueryOptions) => {
    return Controller9fe6faf8b56cdbd10c6435170d61adba.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/companies'
 */
Controller9fe6faf8b56cdbd10c6435170d61adba.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller9fe6faf8b56cdbd10c6435170d61adba.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/companies'
 */
Controller9fe6faf8b56cdbd10c6435170d61adba.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller9fe6faf8b56cdbd10c6435170d61adba.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/companies'
 */
    const Controller9fe6faf8b56cdbd10c6435170d61adbaForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller9fe6faf8b56cdbd10c6435170d61adba.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/companies'
 */
        Controller9fe6faf8b56cdbd10c6435170d61adbaForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller9fe6faf8b56cdbd10c6435170d61adba.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin/companies'
 */
        Controller9fe6faf8b56cdbd10c6435170d61adbaForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller9fe6faf8b56cdbd10c6435170d61adba.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller9fe6faf8b56cdbd10c6435170d61adba.form = Controller9fe6faf8b56cdbd10c6435170d61adbaForm

const Controller = {
    '/purchase-orders': Controllerb79d2970118d4e05b639b7e3c6c06377,
    '/purchase-orders/supplier': Controller7aaf7c29bb1b3b72de92fde40fd2e1f5,
    '/supplier/company-profile': Controller765815ee247c28ff7a6b8bd0a8c490ce,
    '/admin/companies': Controller9fe6faf8b56cdbd10c6435170d61adba,
}

export default Controller