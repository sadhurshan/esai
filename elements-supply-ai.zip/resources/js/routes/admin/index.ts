import companies from './companies'
const admin = {
    companies: Object.assign(companies, companies),
}

export default admin