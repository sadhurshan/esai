import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
 * @see routes/web.php:9
 * @route '/company-registration'
 */
export const registration = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: registration.url(options),
    method: 'get',
})

registration.definition = {
    methods: ["get","head"],
    url: '/company-registration',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:9
 * @route '/company-registration'
 */
registration.url = (options?: RouteQueryOptions) => {
    return registration.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:9
 * @route '/company-registration'
 */
registration.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: registration.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:9
 * @route '/company-registration'
 */
registration.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: registration.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:9
 * @route '/company-registration'
 */
    const registrationForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: registration.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:9
 * @route '/company-registration'
 */
        registrationForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: registration.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:9
 * @route '/company-registration'
 */
        registrationForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: registration.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    registration.form = registrationForm
const company = {
    registration: Object.assign(registration, registration),
}

export default company