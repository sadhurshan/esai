import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
export const companyProfile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companyProfile.url(options),
    method: 'get',
})

companyProfile.definition = {
    methods: ["get","head"],
    url: '/supplier/company-profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
companyProfile.url = (options?: RouteQueryOptions) => {
    return companyProfile.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
companyProfile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: companyProfile.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
companyProfile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: companyProfile.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
    const companyProfileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: companyProfile.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
        companyProfileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companyProfile.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/supplier/company-profile'
 */
        companyProfileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: companyProfile.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    companyProfile.form = companyProfileForm
const supplier = {
    companyProfile: Object.assign(companyProfile, companyProfile),
}

export default supplier