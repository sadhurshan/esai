import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AiTrainingController::index
 * @see app/Http/Controllers/Admin/AiTrainingController.php:22
 * @route '/api/v1/admin/ai-training/jobs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/admin/ai-training/jobs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AiTrainingController::index
 * @see app/Http/Controllers/Admin/AiTrainingController.php:22
 * @route '/api/v1/admin/ai-training/jobs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiTrainingController::index
 * @see app/Http/Controllers/Admin/AiTrainingController.php:22
 * @route '/api/v1/admin/ai-training/jobs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AiTrainingController::index
 * @see app/Http/Controllers/Admin/AiTrainingController.php:22
 * @route '/api/v1/admin/ai-training/jobs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AiTrainingController::index
 * @see app/Http/Controllers/Admin/AiTrainingController.php:22
 * @route '/api/v1/admin/ai-training/jobs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AiTrainingController::index
 * @see app/Http/Controllers/Admin/AiTrainingController.php:22
 * @route '/api/v1/admin/ai-training/jobs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AiTrainingController::index
 * @see app/Http/Controllers/Admin/AiTrainingController.php:22
 * @route '/api/v1/admin/ai-training/jobs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AiTrainingController::start
 * @see app/Http/Controllers/Admin/AiTrainingController.php:69
 * @route '/api/v1/admin/ai-training/start'
 */
export const start = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/api/v1/admin/ai-training/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AiTrainingController::start
 * @see app/Http/Controllers/Admin/AiTrainingController.php:69
 * @route '/api/v1/admin/ai-training/start'
 */
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiTrainingController::start
 * @see app/Http/Controllers/Admin/AiTrainingController.php:69
 * @route '/api/v1/admin/ai-training/start'
 */
start.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AiTrainingController::start
 * @see app/Http/Controllers/Admin/AiTrainingController.php:69
 * @route '/api/v1/admin/ai-training/start'
 */
    const startForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AiTrainingController::start
 * @see app/Http/Controllers/Admin/AiTrainingController.php:69
 * @route '/api/v1/admin/ai-training/start'
 */
        startForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\Admin\AiTrainingController::show
 * @see app/Http/Controllers/Admin/AiTrainingController.php:89
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}'
 */
export const show = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/admin/ai-training/jobs/{model_training_job}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AiTrainingController::show
 * @see app/Http/Controllers/Admin/AiTrainingController.php:89
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}'
 */
show.url = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { model_training_job: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    model_training_job: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        model_training_job: args.model_training_job,
                }

    return show.definition.url
            .replace('{model_training_job}', parsedArgs.model_training_job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiTrainingController::show
 * @see app/Http/Controllers/Admin/AiTrainingController.php:89
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}'
 */
show.get = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AiTrainingController::show
 * @see app/Http/Controllers/Admin/AiTrainingController.php:89
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}'
 */
show.head = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AiTrainingController::show
 * @see app/Http/Controllers/Admin/AiTrainingController.php:89
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}'
 */
    const showForm = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AiTrainingController::show
 * @see app/Http/Controllers/Admin/AiTrainingController.php:89
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}'
 */
        showForm.get = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AiTrainingController::show
 * @see app/Http/Controllers/Admin/AiTrainingController.php:89
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}'
 */
        showForm.head = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\AiTrainingController::refresh
 * @see app/Http/Controllers/Admin/AiTrainingController.php:96
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}/refresh'
 */
export const refresh = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refresh.url(args, options),
    method: 'post',
})

refresh.definition = {
    methods: ["post"],
    url: '/api/v1/admin/ai-training/jobs/{model_training_job}/refresh',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AiTrainingController::refresh
 * @see app/Http/Controllers/Admin/AiTrainingController.php:96
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}/refresh'
 */
refresh.url = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { model_training_job: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    model_training_job: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        model_training_job: args.model_training_job,
                }

    return refresh.definition.url
            .replace('{model_training_job}', parsedArgs.model_training_job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiTrainingController::refresh
 * @see app/Http/Controllers/Admin/AiTrainingController.php:96
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}/refresh'
 */
refresh.post = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refresh.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AiTrainingController::refresh
 * @see app/Http/Controllers/Admin/AiTrainingController.php:96
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}/refresh'
 */
    const refreshForm = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: refresh.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AiTrainingController::refresh
 * @see app/Http/Controllers/Admin/AiTrainingController.php:96
 * @route '/api/v1/admin/ai-training/jobs/{model_training_job}/refresh'
 */
        refreshForm.post = (args: { model_training_job: string | number } | [model_training_job: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: refresh.url(args, options),
            method: 'post',
        })
    
    refresh.form = refreshForm
const AiTrainingController = { index, start, show, refresh }

export default AiTrainingController