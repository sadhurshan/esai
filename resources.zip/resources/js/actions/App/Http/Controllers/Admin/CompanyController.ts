import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CompanyController::assignPlan
 * @see app/Http/Controllers/Admin/CompanyController.php:21
 * @route '/api/admin/companies/{company}/assign-plan'
 */
export const assignPlan = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignPlan.url(args, options),
    method: 'post',
})

assignPlan.definition = {
    methods: ["post"],
    url: '/api/admin/companies/{company}/assign-plan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CompanyController::assignPlan
 * @see app/Http/Controllers/Admin/CompanyController.php:21
 * @route '/api/admin/companies/{company}/assign-plan'
 */
assignPlan.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return assignPlan.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CompanyController::assignPlan
 * @see app/Http/Controllers/Admin/CompanyController.php:21
 * @route '/api/admin/companies/{company}/assign-plan'
 */
assignPlan.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignPlan.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\CompanyController::assignPlan
 * @see app/Http/Controllers/Admin/CompanyController.php:21
 * @route '/api/admin/companies/{company}/assign-plan'
 */
    const assignPlanForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assignPlan.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CompanyController::assignPlan
 * @see app/Http/Controllers/Admin/CompanyController.php:21
 * @route '/api/admin/companies/{company}/assign-plan'
 */
        assignPlanForm.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assignPlan.url(args, options),
            method: 'post',
        })
    
    assignPlan.form = assignPlanForm
/**
* @see \App\Http\Controllers\Admin\CompanyController::updateStatus
 * @see app/Http/Controllers/Admin/CompanyController.php:34
 * @route '/api/admin/companies/{company}/status'
 */
export const updateStatus = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStatus.url(args, options),
    method: 'put',
})

updateStatus.definition = {
    methods: ["put"],
    url: '/api/admin/companies/{company}/status',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\CompanyController::updateStatus
 * @see app/Http/Controllers/Admin/CompanyController.php:34
 * @route '/api/admin/companies/{company}/status'
 */
updateStatus.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return updateStatus.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CompanyController::updateStatus
 * @see app/Http/Controllers/Admin/CompanyController.php:34
 * @route '/api/admin/companies/{company}/status'
 */
updateStatus.put = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStatus.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\CompanyController::updateStatus
 * @see app/Http/Controllers/Admin/CompanyController.php:34
 * @route '/api/admin/companies/{company}/status'
 */
    const updateStatusForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CompanyController::updateStatus
 * @see app/Http/Controllers/Admin/CompanyController.php:34
 * @route '/api/admin/companies/{company}/status'
 */
        updateStatusForm.put = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
const CompanyController = { assignPlan, updateStatus }

export default CompanyController