import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::index
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:23
 * @route '/api/admin/companies/{company}/feature-flags'
 */
export const index = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/companies/{company}/feature-flags',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::index
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:23
 * @route '/api/admin/companies/{company}/feature-flags'
 */
index.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return index.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::index
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:23
 * @route '/api/admin/companies/{company}/feature-flags'
 */
index.get = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::index
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:23
 * @route '/api/admin/companies/{company}/feature-flags'
 */
index.head = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::index
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:23
 * @route '/api/admin/companies/{company}/feature-flags'
 */
    const indexForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::index
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:23
 * @route '/api/admin/companies/{company}/feature-flags'
 */
        indexForm.get = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::index
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:23
 * @route '/api/admin/companies/{company}/feature-flags'
 */
        indexForm.head = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::store
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:42
 * @route '/api/admin/companies/{company}/feature-flags'
 */
export const store = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/companies/{company}/feature-flags',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::store
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:42
 * @route '/api/admin/companies/{company}/feature-flags'
 */
store.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return store.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::store
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:42
 * @route '/api/admin/companies/{company}/feature-flags'
 */
store.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::store
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:42
 * @route '/api/admin/companies/{company}/feature-flags'
 */
    const storeForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::store
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:42
 * @route '/api/admin/companies/{company}/feature-flags'
 */
        storeForm.post = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::update
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:53
 * @route '/api/admin/companies/{company}/feature-flags/{flag}'
 */
export const update = (args: { company: number | { id: number }, flag: number | { id: number } } | [company: number | { id: number }, flag: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/admin/companies/{company}/feature-flags/{flag}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::update
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:53
 * @route '/api/admin/companies/{company}/feature-flags/{flag}'
 */
update.url = (args: { company: number | { id: number }, flag: number | { id: number } } | [company: number | { id: number }, flag: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                    flag: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                                flag: typeof args.flag === 'object'
                ? args.flag.id
                : args.flag,
                }

    return update.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace('{flag}', parsedArgs.flag.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::update
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:53
 * @route '/api/admin/companies/{company}/feature-flags/{flag}'
 */
update.put = (args: { company: number | { id: number }, flag: number | { id: number } } | [company: number | { id: number }, flag: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::update
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:53
 * @route '/api/admin/companies/{company}/feature-flags/{flag}'
 */
    const updateForm = (args: { company: number | { id: number }, flag: number | { id: number } } | [company: number | { id: number }, flag: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::update
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:53
 * @route '/api/admin/companies/{company}/feature-flags/{flag}'
 */
        updateForm.put = (args: { company: number | { id: number }, flag: number | { id: number } } | [company: number | { id: number }, flag: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::destroy
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:64
 * @route '/api/admin/companies/{company}/feature-flags/{flag}'
 */
export const destroy = (args: { company: number | { id: number }, flag: number | { id: number } } | [company: number | { id: number }, flag: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/companies/{company}/feature-flags/{flag}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::destroy
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:64
 * @route '/api/admin/companies/{company}/feature-flags/{flag}'
 */
destroy.url = (args: { company: number | { id: number }, flag: number | { id: number } } | [company: number | { id: number }, flag: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                    flag: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                                flag: typeof args.flag === 'object'
                ? args.flag.id
                : args.flag,
                }

    return destroy.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace('{flag}', parsedArgs.flag.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::destroy
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:64
 * @route '/api/admin/companies/{company}/feature-flags/{flag}'
 */
destroy.delete = (args: { company: number | { id: number }, flag: number | { id: number } } | [company: number | { id: number }, flag: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::destroy
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:64
 * @route '/api/admin/companies/{company}/feature-flags/{flag}'
 */
    const destroyForm = (args: { company: number | { id: number }, flag: number | { id: number } } | [company: number | { id: number }, flag: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\CompanyFeatureFlagController::destroy
 * @see app/Http/Controllers/Admin/CompanyFeatureFlagController.php:64
 * @route '/api/admin/companies/{company}/feature-flags/{flag}'
 */
        destroyForm.delete = (args: { company: number | { id: number }, flag: number | { id: number } } | [company: number | { id: number }, flag: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const CompanyFeatureFlagController = { index, store, update, destroy }

export default CompanyFeatureFlagController