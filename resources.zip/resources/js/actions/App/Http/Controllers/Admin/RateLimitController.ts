import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\RateLimitController::index
 * @see app/Http/Controllers/Admin/RateLimitController.php:21
 * @route '/api/admin/rate-limits'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/rate-limits',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\RateLimitController::index
 * @see app/Http/Controllers/Admin/RateLimitController.php:21
 * @route '/api/admin/rate-limits'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RateLimitController::index
 * @see app/Http/Controllers/Admin/RateLimitController.php:21
 * @route '/api/admin/rate-limits'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\RateLimitController::index
 * @see app/Http/Controllers/Admin/RateLimitController.php:21
 * @route '/api/admin/rate-limits'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\RateLimitController::index
 * @see app/Http/Controllers/Admin/RateLimitController.php:21
 * @route '/api/admin/rate-limits'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\RateLimitController::index
 * @see app/Http/Controllers/Admin/RateLimitController.php:21
 * @route '/api/admin/rate-limits'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\RateLimitController::index
 * @see app/Http/Controllers/Admin/RateLimitController.php:21
 * @route '/api/admin/rate-limits'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\RateLimitController::store
 * @see app/Http/Controllers/Admin/RateLimitController.php:41
 * @route '/api/admin/rate-limits'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/rate-limits',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\RateLimitController::store
 * @see app/Http/Controllers/Admin/RateLimitController.php:41
 * @route '/api/admin/rate-limits'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RateLimitController::store
 * @see app/Http/Controllers/Admin/RateLimitController.php:41
 * @route '/api/admin/rate-limits'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\RateLimitController::store
 * @see app/Http/Controllers/Admin/RateLimitController.php:41
 * @route '/api/admin/rate-limits'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\RateLimitController::store
 * @see app/Http/Controllers/Admin/RateLimitController.php:41
 * @route '/api/admin/rate-limits'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\RateLimitController::show
 * @see app/Http/Controllers/Admin/RateLimitController.php:52
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
export const show = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/admin/rate-limits/{rate_limit}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\RateLimitController::show
 * @see app/Http/Controllers/Admin/RateLimitController.php:52
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
show.url = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rate_limit: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    rate_limit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rate_limit: args.rate_limit,
                }

    return show.definition.url
            .replace('{rate_limit}', parsedArgs.rate_limit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RateLimitController::show
 * @see app/Http/Controllers/Admin/RateLimitController.php:52
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
show.get = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\RateLimitController::show
 * @see app/Http/Controllers/Admin/RateLimitController.php:52
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
show.head = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\RateLimitController::show
 * @see app/Http/Controllers/Admin/RateLimitController.php:52
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
    const showForm = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\RateLimitController::show
 * @see app/Http/Controllers/Admin/RateLimitController.php:52
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
        showForm.get = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\RateLimitController::show
 * @see app/Http/Controllers/Admin/RateLimitController.php:52
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
        showForm.head = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\RateLimitController::update
 * @see app/Http/Controllers/Admin/RateLimitController.php:61
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
export const update = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/admin/rate-limits/{rate_limit}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\RateLimitController::update
 * @see app/Http/Controllers/Admin/RateLimitController.php:61
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
update.url = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rate_limit: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    rate_limit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rate_limit: args.rate_limit,
                }

    return update.definition.url
            .replace('{rate_limit}', parsedArgs.rate_limit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RateLimitController::update
 * @see app/Http/Controllers/Admin/RateLimitController.php:61
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
update.put = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\RateLimitController::update
 * @see app/Http/Controllers/Admin/RateLimitController.php:61
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
update.patch = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\RateLimitController::update
 * @see app/Http/Controllers/Admin/RateLimitController.php:61
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
    const updateForm = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\RateLimitController::update
 * @see app/Http/Controllers/Admin/RateLimitController.php:61
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
        updateForm.put = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\RateLimitController::update
 * @see app/Http/Controllers/Admin/RateLimitController.php:61
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
        updateForm.patch = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\RateLimitController::destroy
 * @see app/Http/Controllers/Admin/RateLimitController.php:70
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
export const destroy = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/rate-limits/{rate_limit}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\RateLimitController::destroy
 * @see app/Http/Controllers/Admin/RateLimitController.php:70
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
destroy.url = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rate_limit: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    rate_limit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rate_limit: args.rate_limit,
                }

    return destroy.definition.url
            .replace('{rate_limit}', parsedArgs.rate_limit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RateLimitController::destroy
 * @see app/Http/Controllers/Admin/RateLimitController.php:70
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
destroy.delete = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\RateLimitController::destroy
 * @see app/Http/Controllers/Admin/RateLimitController.php:70
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
    const destroyForm = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\RateLimitController::destroy
 * @see app/Http/Controllers/Admin/RateLimitController.php:70
 * @route '/api/admin/rate-limits/{rate_limit}'
 */
        destroyForm.delete = (args: { rate_limit: string | number } | [rate_limit: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const RateLimitController = { index, store, show, update, destroy }

export default RateLimitController