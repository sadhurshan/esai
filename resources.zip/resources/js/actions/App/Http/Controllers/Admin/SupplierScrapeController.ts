import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::index
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:32
 * @route '/api/v1/admin/supplier-scrapes'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/admin/supplier-scrapes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::index
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:32
 * @route '/api/v1/admin/supplier-scrapes'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::index
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:32
 * @route '/api/v1/admin/supplier-scrapes'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::index
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:32
 * @route '/api/v1/admin/supplier-scrapes'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::index
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:32
 * @route '/api/v1/admin/supplier-scrapes'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::index
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:32
 * @route '/api/v1/admin/supplier-scrapes'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::index
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:32
 * @route '/api/v1/admin/supplier-scrapes'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::start
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:75
 * @route '/api/v1/admin/supplier-scrapes/start'
 */
export const start = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/api/v1/admin/supplier-scrapes/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::start
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:75
 * @route '/api/v1/admin/supplier-scrapes/start'
 */
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::start
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:75
 * @route '/api/v1/admin/supplier-scrapes/start'
 */
start.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::start
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:75
 * @route '/api/v1/admin/supplier-scrapes/start'
 */
    const startForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::start
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:75
 * @route '/api/v1/admin/supplier-scrapes/start'
 */
        startForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::results
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:92
 * @route '/api/v1/admin/supplier-scrapes/{supplier_scrape_job}/results'
 */
export const results = (args: { supplier_scrape_job: string | number } | [supplier_scrape_job: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: results.url(args, options),
    method: 'get',
})

results.definition = {
    methods: ["get","head"],
    url: '/api/v1/admin/supplier-scrapes/{supplier_scrape_job}/results',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::results
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:92
 * @route '/api/v1/admin/supplier-scrapes/{supplier_scrape_job}/results'
 */
results.url = (args: { supplier_scrape_job: string | number } | [supplier_scrape_job: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supplier_scrape_job: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    supplier_scrape_job: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        supplier_scrape_job: args.supplier_scrape_job,
                }

    return results.definition.url
            .replace('{supplier_scrape_job}', parsedArgs.supplier_scrape_job.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::results
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:92
 * @route '/api/v1/admin/supplier-scrapes/{supplier_scrape_job}/results'
 */
results.get = (args: { supplier_scrape_job: string | number } | [supplier_scrape_job: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: results.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::results
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:92
 * @route '/api/v1/admin/supplier-scrapes/{supplier_scrape_job}/results'
 */
results.head = (args: { supplier_scrape_job: string | number } | [supplier_scrape_job: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: results.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::results
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:92
 * @route '/api/v1/admin/supplier-scrapes/{supplier_scrape_job}/results'
 */
    const resultsForm = (args: { supplier_scrape_job: string | number } | [supplier_scrape_job: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: results.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::results
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:92
 * @route '/api/v1/admin/supplier-scrapes/{supplier_scrape_job}/results'
 */
        resultsForm.get = (args: { supplier_scrape_job: string | number } | [supplier_scrape_job: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: results.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::results
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:92
 * @route '/api/v1/admin/supplier-scrapes/{supplier_scrape_job}/results'
 */
        resultsForm.head = (args: { supplier_scrape_job: string | number } | [supplier_scrape_job: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: results.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    results.form = resultsForm
/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::approve
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:131
 * @route '/api/v1/admin/scraped-suppliers/{scraped_supplier}/approve'
 */
export const approve = (args: { scraped_supplier: string | number } | [scraped_supplier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/v1/admin/scraped-suppliers/{scraped_supplier}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::approve
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:131
 * @route '/api/v1/admin/scraped-suppliers/{scraped_supplier}/approve'
 */
approve.url = (args: { scraped_supplier: string | number } | [scraped_supplier: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { scraped_supplier: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    scraped_supplier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        scraped_supplier: args.scraped_supplier,
                }

    return approve.definition.url
            .replace('{scraped_supplier}', parsedArgs.scraped_supplier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::approve
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:131
 * @route '/api/v1/admin/scraped-suppliers/{scraped_supplier}/approve'
 */
approve.post = (args: { scraped_supplier: string | number } | [scraped_supplier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::approve
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:131
 * @route '/api/v1/admin/scraped-suppliers/{scraped_supplier}/approve'
 */
    const approveForm = (args: { scraped_supplier: string | number } | [scraped_supplier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::approve
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:131
 * @route '/api/v1/admin/scraped-suppliers/{scraped_supplier}/approve'
 */
        approveForm.post = (args: { scraped_supplier: string | number } | [scraped_supplier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::discard
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:152
 * @route '/api/v1/admin/scraped-suppliers/{scraped_supplier}'
 */
export const discard = (args: { scraped_supplier: string | number } | [scraped_supplier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: discard.url(args, options),
    method: 'delete',
})

discard.definition = {
    methods: ["delete"],
    url: '/api/v1/admin/scraped-suppliers/{scraped_supplier}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::discard
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:152
 * @route '/api/v1/admin/scraped-suppliers/{scraped_supplier}'
 */
discard.url = (args: { scraped_supplier: string | number } | [scraped_supplier: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { scraped_supplier: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    scraped_supplier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        scraped_supplier: args.scraped_supplier,
                }

    return discard.definition.url
            .replace('{scraped_supplier}', parsedArgs.scraped_supplier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::discard
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:152
 * @route '/api/v1/admin/scraped-suppliers/{scraped_supplier}'
 */
discard.delete = (args: { scraped_supplier: string | number } | [scraped_supplier: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: discard.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::discard
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:152
 * @route '/api/v1/admin/scraped-suppliers/{scraped_supplier}'
 */
    const discardForm = (args: { scraped_supplier: string | number } | [scraped_supplier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: discard.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SupplierScrapeController::discard
 * @see app/Http/Controllers/Admin/SupplierScrapeController.php:152
 * @route '/api/v1/admin/scraped-suppliers/{scraped_supplier}'
 */
        discardForm.delete = (args: { scraped_supplier: string | number } | [scraped_supplier: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: discard.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    discard.form = discardForm
const SupplierScrapeController = { index, start, results, approve, discard }

export default SupplierScrapeController