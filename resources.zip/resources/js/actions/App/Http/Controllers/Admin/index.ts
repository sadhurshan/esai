import PlanController from './PlanController'
import CompanyController from './CompanyController'
import CompanyFeatureFlagController from './CompanyFeatureFlagController'
import EmailTemplateController from './EmailTemplateController'
import DigitalTwinCategoryController from './DigitalTwinCategoryController'
import DigitalTwinController from './DigitalTwinController'
import DigitalTwinAssetController from './DigitalTwinAssetController'
import DigitalTwinAuditEventController from './DigitalTwinAuditEventController'
import ApiKeyController from './ApiKeyController'
import RateLimitController from './RateLimitController'
import WebhookSubscriptionController from './WebhookSubscriptionController'
import WebhookDeliveryController from './WebhookDeliveryController'
import HealthController from './HealthController'
import RoleTemplateController from './RoleTemplateController'
import AuditLogController from './AuditLogController'
import AiEventController from './AiEventController'
import AiModelMetricController from './AiModelMetricController'
import AdminAnalyticsController from './AdminAnalyticsController'
import AiTrainingController from './AiTrainingController'
import SupplierScrapeController from './SupplierScrapeController'
const Admin = {
    PlanController: Object.assign(PlanController, PlanController),
CompanyController: Object.assign(CompanyController, CompanyController),
CompanyFeatureFlagController: Object.assign(CompanyFeatureFlagController, CompanyFeatureFlagController),
EmailTemplateController: Object.assign(EmailTemplateController, EmailTemplateController),
DigitalTwinCategoryController: Object.assign(DigitalTwinCategoryController, DigitalTwinCategoryController),
DigitalTwinController: Object.assign(DigitalTwinController, DigitalTwinController),
DigitalTwinAssetController: Object.assign(DigitalTwinAssetController, DigitalTwinAssetController),
DigitalTwinAuditEventController: Object.assign(DigitalTwinAuditEventController, DigitalTwinAuditEventController),
ApiKeyController: Object.assign(ApiKeyController, ApiKeyController),
RateLimitController: Object.assign(RateLimitController, RateLimitController),
WebhookSubscriptionController: Object.assign(WebhookSubscriptionController, WebhookSubscriptionController),
WebhookDeliveryController: Object.assign(WebhookDeliveryController, WebhookDeliveryController),
HealthController: Object.assign(HealthController, HealthController),
RoleTemplateController: Object.assign(RoleTemplateController, RoleTemplateController),
AuditLogController: Object.assign(AuditLogController, AuditLogController),
AiEventController: Object.assign(AiEventController, AiEventController),
AiModelMetricController: Object.assign(AiModelMetricController, AiModelMetricController),
AdminAnalyticsController: Object.assign(AdminAnalyticsController, AdminAnalyticsController),
AiTrainingController: Object.assign(AiTrainingController, AiTrainingController),
SupplierScrapeController: Object.assign(SupplierScrapeController, SupplierScrapeController),
}

export default Admin