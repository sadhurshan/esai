import CompanyApprovalController from './CompanyApprovalController'
import SupplierApplicationReviewController from './SupplierApplicationReviewController'
const Admin = {
    CompanyApprovalController: Object.assign(CompanyApprovalController, CompanyApprovalController),
SupplierApplicationReviewController: Object.assign(SupplierApplicationReviewController, SupplierApplicationReviewController),
}

export default Admin