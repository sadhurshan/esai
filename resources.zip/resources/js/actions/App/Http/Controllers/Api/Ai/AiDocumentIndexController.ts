import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Ai\AiDocumentIndexController::reindex
 * @see app/Http/Controllers/Api/Ai/AiDocumentIndexController.php:15
 * @route '/api/v1/admin/ai/reindex-document'
 */
export const reindex = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reindex.url(options),
    method: 'post',
})

reindex.definition = {
    methods: ["post"],
    url: '/api/v1/admin/ai/reindex-document',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Ai\AiDocumentIndexController::reindex
 * @see app/Http/Controllers/Api/Ai/AiDocumentIndexController.php:15
 * @route '/api/v1/admin/ai/reindex-document'
 */
reindex.url = (options?: RouteQueryOptions) => {
    return reindex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Ai\AiDocumentIndexController::reindex
 * @see app/Http/Controllers/Api/Ai/AiDocumentIndexController.php:15
 * @route '/api/v1/admin/ai/reindex-document'
 */
reindex.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reindex.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Ai\AiDocumentIndexController::reindex
 * @see app/Http/Controllers/Api/Ai/AiDocumentIndexController.php:15
 * @route '/api/v1/admin/ai/reindex-document'
 */
    const reindexForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reindex.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Ai\AiDocumentIndexController::reindex
 * @see app/Http/Controllers/Api/Ai/AiDocumentIndexController.php:15
 * @route '/api/v1/admin/ai/reindex-document'
 */
        reindexForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reindex.url(options),
            method: 'post',
        })
    
    reindex.form = reindexForm
const AiDocumentIndexController = { reindex }

export default AiDocumentIndexController