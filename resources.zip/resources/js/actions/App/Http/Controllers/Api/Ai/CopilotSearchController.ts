import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Ai\CopilotSearchController::search
 * @see app/Http/Controllers/Api/Ai/CopilotSearchController.php:31
 * @route '/api/copilot/search'
 */
export const search = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: search.url(options),
    method: 'post',
})

search.definition = {
    methods: ["post"],
    url: '/api/copilot/search',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Ai\CopilotSearchController::search
 * @see app/Http/Controllers/Api/Ai/CopilotSearchController.php:31
 * @route '/api/copilot/search'
 */
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Ai\CopilotSearchController::search
 * @see app/Http/Controllers/Api/Ai/CopilotSearchController.php:31
 * @route '/api/copilot/search'
 */
search.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: search.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Ai\CopilotSearchController::search
 * @see app/Http/Controllers/Api/Ai/CopilotSearchController.php:31
 * @route '/api/copilot/search'
 */
    const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: search.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Ai\CopilotSearchController::search
 * @see app/Http/Controllers/Api/Ai/CopilotSearchController.php:31
 * @route '/api/copilot/search'
 */
        searchForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: search.url(options),
            method: 'post',
        })
    
    search.form = searchForm
/**
* @see \App\Http\Controllers\Api\Ai\CopilotSearchController::answer
 * @see app/Http/Controllers/Api/Ai/CopilotSearchController.php:94
 * @route '/api/copilot/answer'
 */
export const answer = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: answer.url(options),
    method: 'post',
})

answer.definition = {
    methods: ["post"],
    url: '/api/copilot/answer',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Ai\CopilotSearchController::answer
 * @see app/Http/Controllers/Api/Ai/CopilotSearchController.php:94
 * @route '/api/copilot/answer'
 */
answer.url = (options?: RouteQueryOptions) => {
    return answer.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Ai\CopilotSearchController::answer
 * @see app/Http/Controllers/Api/Ai/CopilotSearchController.php:94
 * @route '/api/copilot/answer'
 */
answer.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: answer.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Ai\CopilotSearchController::answer
 * @see app/Http/Controllers/Api/Ai/CopilotSearchController.php:94
 * @route '/api/copilot/answer'
 */
    const answerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: answer.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Ai\CopilotSearchController::answer
 * @see app/Http/Controllers/Api/Ai/CopilotSearchController.php:94
 * @route '/api/copilot/answer'
 */
        answerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: answer.url(options),
            method: 'post',
        })
    
    answer.form = answerForm
const CopilotSearchController = { search, answer }

export default CopilotSearchController