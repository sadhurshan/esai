import AiDocumentIndexController from './AiDocumentIndexController'
import CopilotSearchController from './CopilotSearchController'
const Ai = {
    AiDocumentIndexController: Object.assign(AiDocumentIndexController, AiDocumentIndexController),
CopilotSearchController: Object.assign(CopilotSearchController, CopilotSearchController),
}

export default Ai