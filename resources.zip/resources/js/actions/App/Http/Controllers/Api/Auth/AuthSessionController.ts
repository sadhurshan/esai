import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::store
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:20
 * @route '/api/auth/login'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/auth/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::store
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:20
 * @route '/api/auth/login'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::store
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:20
 * @route '/api/auth/login'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::store
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:20
 * @route '/api/auth/login'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::store
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:20
 * @route '/api/auth/login'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::show
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:52
 * @route '/api/auth/me'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/auth/me',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::show
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:52
 * @route '/api/auth/me'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::show
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:52
 * @route '/api/auth/me'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::show
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:52
 * @route '/api/auth/me'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::show
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:52
 * @route '/api/auth/me'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::show
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:52
 * @route '/api/auth/me'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::show
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:52
 * @route '/api/auth/me'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::destroy
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:67
 * @route '/api/auth/logout'
 */
export const destroy = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

destroy.definition = {
    methods: ["post"],
    url: '/api/auth/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::destroy
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:67
 * @route '/api/auth/logout'
 */
destroy.url = (options?: RouteQueryOptions) => {
    return destroy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::destroy
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:67
 * @route '/api/auth/logout'
 */
destroy.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::destroy
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:67
 * @route '/api/auth/logout'
 */
    const destroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Auth\AuthSessionController::destroy
 * @see app/Http/Controllers/Api/Auth/AuthSessionController.php:67
 * @route '/api/auth/logout'
 */
        destroyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(options),
            method: 'post',
        })
    
    destroy.form = destroyForm
const AuthSessionController = { store, show, destroy }

export default AuthSessionController