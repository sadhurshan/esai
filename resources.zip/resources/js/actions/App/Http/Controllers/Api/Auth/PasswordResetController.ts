import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Auth\PasswordResetController::sendResetLink
 * @see app/Http/Controllers/Api/Auth/PasswordResetController.php:17
 * @route '/api/auth/forgot-password'
 */
export const sendResetLink = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendResetLink.url(options),
    method: 'post',
})

sendResetLink.definition = {
    methods: ["post"],
    url: '/api/auth/forgot-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Auth\PasswordResetController::sendResetLink
 * @see app/Http/Controllers/Api/Auth/PasswordResetController.php:17
 * @route '/api/auth/forgot-password'
 */
sendResetLink.url = (options?: RouteQueryOptions) => {
    return sendResetLink.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Auth\PasswordResetController::sendResetLink
 * @see app/Http/Controllers/Api/Auth/PasswordResetController.php:17
 * @route '/api/auth/forgot-password'
 */
sendResetLink.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendResetLink.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Auth\PasswordResetController::sendResetLink
 * @see app/Http/Controllers/Api/Auth/PasswordResetController.php:17
 * @route '/api/auth/forgot-password'
 */
    const sendResetLinkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendResetLink.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Auth\PasswordResetController::sendResetLink
 * @see app/Http/Controllers/Api/Auth/PasswordResetController.php:17
 * @route '/api/auth/forgot-password'
 */
        sendResetLinkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendResetLink.url(options),
            method: 'post',
        })
    
    sendResetLink.form = sendResetLinkForm
/**
* @see \App\Http\Controllers\Api\Auth\PasswordResetController::reset
 * @see app/Http/Controllers/Api/Auth/PasswordResetController.php:30
 * @route '/api/auth/reset-password'
 */
export const reset = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reset.url(options),
    method: 'post',
})

reset.definition = {
    methods: ["post"],
    url: '/api/auth/reset-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Auth\PasswordResetController::reset
 * @see app/Http/Controllers/Api/Auth/PasswordResetController.php:30
 * @route '/api/auth/reset-password'
 */
reset.url = (options?: RouteQueryOptions) => {
    return reset.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Auth\PasswordResetController::reset
 * @see app/Http/Controllers/Api/Auth/PasswordResetController.php:30
 * @route '/api/auth/reset-password'
 */
reset.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reset.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Auth\PasswordResetController::reset
 * @see app/Http/Controllers/Api/Auth/PasswordResetController.php:30
 * @route '/api/auth/reset-password'
 */
    const resetForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reset.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Auth\PasswordResetController::reset
 * @see app/Http/Controllers/Api/Auth/PasswordResetController.php:30
 * @route '/api/auth/reset-password'
 */
        resetForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reset.url(options),
            method: 'post',
        })
    
    reset.form = resetForm
const PasswordResetController = { sendResetLink, reset }

export default PasswordResetController