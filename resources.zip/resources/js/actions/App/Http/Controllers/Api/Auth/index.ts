import AuthSessionController from './AuthSessionController'
import SelfRegistrationController from './SelfRegistrationController'
import ActivePersonaController from './ActivePersonaController'
import PasswordResetController from './PasswordResetController'
const Auth = {
    AuthSessionController: Object.assign(AuthSessionController, AuthSessionController),
SelfRegistrationController: Object.assign(SelfRegistrationController, SelfRegistrationController),
ActivePersonaController: Object.assign(ActivePersonaController, ActivePersonaController),
PasswordResetController: Object.assign(PasswordResetController, PasswordResetController),
}

export default Auth