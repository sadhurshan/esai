import PlanCheckoutController from './PlanCheckoutController'
import BillingPortalController from './BillingPortalController'
import BillingInvoiceController from './BillingInvoiceController'
import StripeWebhookController from './StripeWebhookController'
const Billing = {
    PlanCheckoutController: Object.assign(PlanCheckoutController, PlanCheckoutController),
BillingPortalController: Object.assign(BillingPortalController, BillingPortalController),
BillingInvoiceController: Object.assign(BillingInvoiceController, BillingInvoiceController),
StripeWebhookController: Object.assign(StripeWebhookController, StripeWebhookController),
}

export default Billing