import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::accept
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:128
 * @route '/api/company-invitations/{token}/accept'
 */
export const accept = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: accept.url(args, options),
    method: 'post',
})

accept.definition = {
    methods: ["post"],
    url: '/api/company-invitations/{token}/accept',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::accept
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:128
 * @route '/api/company-invitations/{token}/accept'
 */
accept.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return accept.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::accept
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:128
 * @route '/api/company-invitations/{token}/accept'
 */
accept.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: accept.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CompanyInvitationController::accept
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:128
 * @route '/api/company-invitations/{token}/accept'
 */
    const acceptForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: accept.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyInvitationController::accept
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:128
 * @route '/api/company-invitations/{token}/accept'
 */
        acceptForm.post = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: accept.url(args, options),
            method: 'post',
        })
    
    accept.form = acceptForm
/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::index
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:28
 * @route '/api/company-invitations'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/company-invitations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::index
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:28
 * @route '/api/company-invitations'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::index
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:28
 * @route '/api/company-invitations'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::index
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:28
 * @route '/api/company-invitations'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\CompanyInvitationController::index
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:28
 * @route '/api/company-invitations'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyInvitationController::index
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:28
 * @route '/api/company-invitations'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\CompanyInvitationController::index
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:28
 * @route '/api/company-invitations'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::store
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:59
 * @route '/api/company-invitations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/company-invitations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::store
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:59
 * @route '/api/company-invitations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::store
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:59
 * @route '/api/company-invitations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CompanyInvitationController::store
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:59
 * @route '/api/company-invitations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyInvitationController::store
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:59
 * @route '/api/company-invitations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::destroy
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:86
 * @route '/api/company-invitations/{invitation}'
 */
export const destroy = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/company-invitations/{invitation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::destroy
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:86
 * @route '/api/company-invitations/{invitation}'
 */
destroy.url = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { invitation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { invitation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    invitation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        invitation: typeof args.invitation === 'object'
                ? args.invitation.id
                : args.invitation,
                }

    return destroy.definition.url
            .replace('{invitation}', parsedArgs.invitation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyInvitationController::destroy
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:86
 * @route '/api/company-invitations/{invitation}'
 */
destroy.delete = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\CompanyInvitationController::destroy
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:86
 * @route '/api/company-invitations/{invitation}'
 */
    const destroyForm = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyInvitationController::destroy
 * @see app/Http/Controllers/Api/CompanyInvitationController.php:86
 * @route '/api/company-invitations/{invitation}'
 */
        destroyForm.delete = (args: { invitation: number | { id: number } } | [invitation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const CompanyInvitationController = { accept, index, store, destroy }

export default CompanyInvitationController