import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CompanyPlanController::store
 * @see app/Http/Controllers/Api/CompanyPlanController.php:25
 * @route '/api/company/plan-selection'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/company/plan-selection',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CompanyPlanController::store
 * @see app/Http/Controllers/Api/CompanyPlanController.php:25
 * @route '/api/company/plan-selection'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyPlanController::store
 * @see app/Http/Controllers/Api/CompanyPlanController.php:25
 * @route '/api/company/plan-selection'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CompanyPlanController::store
 * @see app/Http/Controllers/Api/CompanyPlanController.php:25
 * @route '/api/company/plan-selection'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyPlanController::store
 * @see app/Http/Controllers/Api/CompanyPlanController.php:25
 * @route '/api/company/plan-selection'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const CompanyPlanController = { store }

export default CompanyPlanController