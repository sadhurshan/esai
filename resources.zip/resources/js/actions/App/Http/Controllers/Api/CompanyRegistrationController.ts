import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::store
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:21
 * @route '/api/companies'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/companies',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::store
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:21
 * @route '/api/companies'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::store
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:21
 * @route '/api/companies'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::store
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:21
 * @route '/api/companies'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::store
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:21
 * @route '/api/companies'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::show
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:34
 * @route '/api/companies/{company}'
 */
export const show = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/companies/{company}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::show
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:34
 * @route '/api/companies/{company}'
 */
show.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return show.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::show
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:34
 * @route '/api/companies/{company}'
 */
show.get = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::show
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:34
 * @route '/api/companies/{company}'
 */
show.head = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::show
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:34
 * @route '/api/companies/{company}'
 */
    const showForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::show
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:34
 * @route '/api/companies/{company}'
 */
        showForm.get = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::show
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:34
 * @route '/api/companies/{company}'
 */
        showForm.head = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::update
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:49
 * @route '/api/companies/{company}'
 */
export const update = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/companies/{company}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::update
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:49
 * @route '/api/companies/{company}'
 */
update.url = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { company: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { company: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    company: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        company: typeof args.company === 'object'
                ? args.company.id
                : args.company,
                }

    return update.definition.url
            .replace('{company}', parsedArgs.company.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::update
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:49
 * @route '/api/companies/{company}'
 */
update.put = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::update
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:49
 * @route '/api/companies/{company}'
 */
    const updateForm = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CompanyRegistrationController::update
 * @see app/Http/Controllers/Api/CompanyRegistrationController.php:49
 * @route '/api/companies/{company}'
 */
        updateForm.put = (args: { company: number | { id: number } } | [company: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const CompanyRegistrationController = { store, show, update }

export default CompanyRegistrationController