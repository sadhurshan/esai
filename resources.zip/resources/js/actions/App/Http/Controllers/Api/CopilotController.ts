import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CopilotController::handle
 * @see app/Http/Controllers/Api/CopilotController.php:26
 * @route '/api/copilot/analytics'
 */
export const handle = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: handle.url(options),
    method: 'post',
})

handle.definition = {
    methods: ["post"],
    url: '/api/copilot/analytics',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CopilotController::handle
 * @see app/Http/Controllers/Api/CopilotController.php:26
 * @route '/api/copilot/analytics'
 */
handle.url = (options?: RouteQueryOptions) => {
    return handle.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CopilotController::handle
 * @see app/Http/Controllers/Api/CopilotController.php:26
 * @route '/api/copilot/analytics'
 */
handle.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: handle.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CopilotController::handle
 * @see app/Http/Controllers/Api/CopilotController.php:26
 * @route '/api/copilot/analytics'
 */
    const handleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: handle.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CopilotController::handle
 * @see app/Http/Controllers/Api/CopilotController.php:26
 * @route '/api/copilot/analytics'
 */
        handleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: handle.url(options),
            method: 'post',
        })
    
    handle.form = handleForm
const CopilotController = { handle }

export default CopilotController