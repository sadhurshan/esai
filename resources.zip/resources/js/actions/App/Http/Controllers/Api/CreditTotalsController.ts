import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CreditTotalsController::recalculate
 * @see app/Http/Controllers/Api/CreditTotalsController.php:17
 * @route '/api/credit-notes/{creditNote}/recalculate'
 */
export const recalculate = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(args, options),
    method: 'post',
})

recalculate.definition = {
    methods: ["post"],
    url: '/api/credit-notes/{creditNote}/recalculate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CreditTotalsController::recalculate
 * @see app/Http/Controllers/Api/CreditTotalsController.php:17
 * @route '/api/credit-notes/{creditNote}/recalculate'
 */
recalculate.url = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { creditNote: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { creditNote: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    creditNote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        creditNote: typeof args.creditNote === 'object'
                ? args.creditNote.id
                : args.creditNote,
                }

    return recalculate.definition.url
            .replace('{creditNote}', parsedArgs.creditNote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CreditTotalsController::recalculate
 * @see app/Http/Controllers/Api/CreditTotalsController.php:17
 * @route '/api/credit-notes/{creditNote}/recalculate'
 */
recalculate.post = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CreditTotalsController::recalculate
 * @see app/Http/Controllers/Api/CreditTotalsController.php:17
 * @route '/api/credit-notes/{creditNote}/recalculate'
 */
    const recalculateForm = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: recalculate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CreditTotalsController::recalculate
 * @see app/Http/Controllers/Api/CreditTotalsController.php:17
 * @route '/api/credit-notes/{creditNote}/recalculate'
 */
        recalculateForm.post = (args: { creditNote: number | { id: number } } | [creditNote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: recalculate.url(args, options),
            method: 'post',
        })
    
    recalculate.form = recalculateForm
const CreditTotalsController = { recalculate }

export default CreditTotalsController