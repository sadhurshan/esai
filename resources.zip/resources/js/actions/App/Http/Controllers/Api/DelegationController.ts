import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DelegationController::index
 * @see app/Http/Controllers/Api/DelegationController.php:20
 * @route '/api/approvals/delegations'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/approvals/delegations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DelegationController::index
 * @see app/Http/Controllers/Api/DelegationController.php:20
 * @route '/api/approvals/delegations'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DelegationController::index
 * @see app/Http/Controllers/Api/DelegationController.php:20
 * @route '/api/approvals/delegations'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DelegationController::index
 * @see app/Http/Controllers/Api/DelegationController.php:20
 * @route '/api/approvals/delegations'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DelegationController::index
 * @see app/Http/Controllers/Api/DelegationController.php:20
 * @route '/api/approvals/delegations'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DelegationController::index
 * @see app/Http/Controllers/Api/DelegationController.php:20
 * @route '/api/approvals/delegations'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DelegationController::index
 * @see app/Http/Controllers/Api/DelegationController.php:20
 * @route '/api/approvals/delegations'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\DelegationController::store
 * @see app/Http/Controllers/Api/DelegationController.php:50
 * @route '/api/approvals/delegations'
 */
const store07c8703985558aba1bba26e9a2cba95f = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store07c8703985558aba1bba26e9a2cba95f.url(options),
    method: 'post',
})

store07c8703985558aba1bba26e9a2cba95f.definition = {
    methods: ["post"],
    url: '/api/approvals/delegations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DelegationController::store
 * @see app/Http/Controllers/Api/DelegationController.php:50
 * @route '/api/approvals/delegations'
 */
store07c8703985558aba1bba26e9a2cba95f.url = (options?: RouteQueryOptions) => {
    return store07c8703985558aba1bba26e9a2cba95f.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DelegationController::store
 * @see app/Http/Controllers/Api/DelegationController.php:50
 * @route '/api/approvals/delegations'
 */
store07c8703985558aba1bba26e9a2cba95f.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store07c8703985558aba1bba26e9a2cba95f.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DelegationController::store
 * @see app/Http/Controllers/Api/DelegationController.php:50
 * @route '/api/approvals/delegations'
 */
    const store07c8703985558aba1bba26e9a2cba95fForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store07c8703985558aba1bba26e9a2cba95f.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DelegationController::store
 * @see app/Http/Controllers/Api/DelegationController.php:50
 * @route '/api/approvals/delegations'
 */
        store07c8703985558aba1bba26e9a2cba95fForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store07c8703985558aba1bba26e9a2cba95f.url(options),
            method: 'post',
        })
    
    store07c8703985558aba1bba26e9a2cba95f.form = store07c8703985558aba1bba26e9a2cba95fForm
    /**
* @see \App\Http\Controllers\Api\DelegationController::store
 * @see app/Http/Controllers/Api/DelegationController.php:50
 * @route '/api/approvals/delegations/{delegation}'
 */
const store138b8a0036c4477b752b8e6b4e256297 = (args: { delegation: string | number } | [delegation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: store138b8a0036c4477b752b8e6b4e256297.url(args, options),
    method: 'put',
})

store138b8a0036c4477b752b8e6b4e256297.definition = {
    methods: ["put"],
    url: '/api/approvals/delegations/{delegation}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\DelegationController::store
 * @see app/Http/Controllers/Api/DelegationController.php:50
 * @route '/api/approvals/delegations/{delegation}'
 */
store138b8a0036c4477b752b8e6b4e256297.url = (args: { delegation: string | number } | [delegation: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delegation: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    delegation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        delegation: args.delegation,
                }

    return store138b8a0036c4477b752b8e6b4e256297.definition.url
            .replace('{delegation}', parsedArgs.delegation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DelegationController::store
 * @see app/Http/Controllers/Api/DelegationController.php:50
 * @route '/api/approvals/delegations/{delegation}'
 */
store138b8a0036c4477b752b8e6b4e256297.put = (args: { delegation: string | number } | [delegation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: store138b8a0036c4477b752b8e6b4e256297.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\DelegationController::store
 * @see app/Http/Controllers/Api/DelegationController.php:50
 * @route '/api/approvals/delegations/{delegation}'
 */
    const store138b8a0036c4477b752b8e6b4e256297Form = (args: { delegation: string | number } | [delegation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store138b8a0036c4477b752b8e6b4e256297.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DelegationController::store
 * @see app/Http/Controllers/Api/DelegationController.php:50
 * @route '/api/approvals/delegations/{delegation}'
 */
        store138b8a0036c4477b752b8e6b4e256297Form.put = (args: { delegation: string | number } | [delegation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store138b8a0036c4477b752b8e6b4e256297.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    store138b8a0036c4477b752b8e6b4e256297.form = store138b8a0036c4477b752b8e6b4e256297Form

export const store = {
    '/api/approvals/delegations': store07c8703985558aba1bba26e9a2cba95f,
    '/api/approvals/delegations/{delegation}': store138b8a0036c4477b752b8e6b4e256297,
}

/**
* @see \App\Http\Controllers\Api\DelegationController::destroy
 * @see app/Http/Controllers/Api/DelegationController.php:96
 * @route '/api/approvals/delegations/{delegation}'
 */
export const destroy = (args: { delegation: number | { id: number } } | [delegation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/approvals/delegations/{delegation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\DelegationController::destroy
 * @see app/Http/Controllers/Api/DelegationController.php:96
 * @route '/api/approvals/delegations/{delegation}'
 */
destroy.url = (args: { delegation: number | { id: number } } | [delegation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delegation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { delegation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    delegation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        delegation: typeof args.delegation === 'object'
                ? args.delegation.id
                : args.delegation,
                }

    return destroy.definition.url
            .replace('{delegation}', parsedArgs.delegation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DelegationController::destroy
 * @see app/Http/Controllers/Api/DelegationController.php:96
 * @route '/api/approvals/delegations/{delegation}'
 */
destroy.delete = (args: { delegation: number | { id: number } } | [delegation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\DelegationController::destroy
 * @see app/Http/Controllers/Api/DelegationController.php:96
 * @route '/api/approvals/delegations/{delegation}'
 */
    const destroyForm = (args: { delegation: number | { id: number } } | [delegation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DelegationController::destroy
 * @see app/Http/Controllers/Api/DelegationController.php:96
 * @route '/api/approvals/delegations/{delegation}'
 */
        destroyForm.delete = (args: { delegation: number | { id: number } } | [delegation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const DelegationController = { index, store, destroy }

export default DelegationController