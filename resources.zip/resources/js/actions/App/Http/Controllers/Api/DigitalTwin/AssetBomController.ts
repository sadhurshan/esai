import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetBomController::sync
 * @see app/Http/Controllers/Api/DigitalTwin/AssetBomController.php:19
 * @route '/api/digital-twin/assets/{asset}/bom'
 */
export const sync = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: sync.url(args, options),
    method: 'put',
})

sync.definition = {
    methods: ["put"],
    url: '/api/digital-twin/assets/{asset}/bom',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetBomController::sync
 * @see app/Http/Controllers/Api/DigitalTwin/AssetBomController.php:19
 * @route '/api/digital-twin/assets/{asset}/bom'
 */
sync.url = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { asset: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                }

    return sync.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetBomController::sync
 * @see app/Http/Controllers/Api/DigitalTwin/AssetBomController.php:19
 * @route '/api/digital-twin/assets/{asset}/bom'
 */
sync.put = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: sync.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetBomController::sync
 * @see app/Http/Controllers/Api/DigitalTwin/AssetBomController.php:19
 * @route '/api/digital-twin/assets/{asset}/bom'
 */
    const syncForm = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sync.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetBomController::sync
 * @see app/Http/Controllers/Api/DigitalTwin/AssetBomController.php:19
 * @route '/api/digital-twin/assets/{asset}/bom'
 */
        syncForm.put = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sync.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    sync.form = syncForm
const AssetBomController = { sync }

export default AssetBomController