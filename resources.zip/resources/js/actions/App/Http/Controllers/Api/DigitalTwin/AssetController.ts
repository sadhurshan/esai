import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::index
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:30
 * @route '/api/digital-twin/assets'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/digital-twin/assets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::index
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:30
 * @route '/api/digital-twin/assets'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::index
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:30
 * @route '/api/digital-twin/assets'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::index
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:30
 * @route '/api/digital-twin/assets'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::index
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:30
 * @route '/api/digital-twin/assets'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::index
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:30
 * @route '/api/digital-twin/assets'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::index
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:30
 * @route '/api/digital-twin/assets'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::store
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:84
 * @route '/api/digital-twin/assets'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/digital-twin/assets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::store
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:84
 * @route '/api/digital-twin/assets'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::store
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:84
 * @route '/api/digital-twin/assets'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::store
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:84
 * @route '/api/digital-twin/assets'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::store
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:84
 * @route '/api/digital-twin/assets'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::show
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:106
 * @route '/api/digital-twin/assets/{asset}'
 */
export const show = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/digital-twin/assets/{asset}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::show
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:106
 * @route '/api/digital-twin/assets/{asset}'
 */
show.url = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { asset: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                }

    return show.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::show
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:106
 * @route '/api/digital-twin/assets/{asset}'
 */
show.get = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::show
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:106
 * @route '/api/digital-twin/assets/{asset}'
 */
show.head = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::show
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:106
 * @route '/api/digital-twin/assets/{asset}'
 */
    const showForm = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::show
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:106
 * @route '/api/digital-twin/assets/{asset}'
 */
        showForm.get = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::show
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:106
 * @route '/api/digital-twin/assets/{asset}'
 */
        showForm.head = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::update
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:118
 * @route '/api/digital-twin/assets/{asset}'
 */
export const update = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/digital-twin/assets/{asset}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::update
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:118
 * @route '/api/digital-twin/assets/{asset}'
 */
update.url = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { asset: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                }

    return update.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::update
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:118
 * @route '/api/digital-twin/assets/{asset}'
 */
update.put = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::update
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:118
 * @route '/api/digital-twin/assets/{asset}'
 */
update.patch = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::update
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:118
 * @route '/api/digital-twin/assets/{asset}'
 */
    const updateForm = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::update
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:118
 * @route '/api/digital-twin/assets/{asset}'
 */
        updateForm.put = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::update
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:118
 * @route '/api/digital-twin/assets/{asset}'
 */
        updateForm.patch = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::destroy
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:140
 * @route '/api/digital-twin/assets/{asset}'
 */
export const destroy = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/digital-twin/assets/{asset}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::destroy
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:140
 * @route '/api/digital-twin/assets/{asset}'
 */
destroy.url = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { asset: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                }

    return destroy.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::destroy
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:140
 * @route '/api/digital-twin/assets/{asset}'
 */
destroy.delete = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::destroy
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:140
 * @route '/api/digital-twin/assets/{asset}'
 */
    const destroyForm = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::destroy
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:140
 * @route '/api/digital-twin/assets/{asset}'
 */
        destroyForm.delete = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::setStatus
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:129
 * @route '/api/digital-twin/assets/{asset}/status'
 */
export const setStatus = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: setStatus.url(args, options),
    method: 'patch',
})

setStatus.definition = {
    methods: ["patch"],
    url: '/api/digital-twin/assets/{asset}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::setStatus
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:129
 * @route '/api/digital-twin/assets/{asset}/status'
 */
setStatus.url = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { asset: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                }

    return setStatus.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::setStatus
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:129
 * @route '/api/digital-twin/assets/{asset}/status'
 */
setStatus.patch = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: setStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::setStatus
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:129
 * @route '/api/digital-twin/assets/{asset}/status'
 */
    const setStatusForm = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: setStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DigitalTwin\AssetController::setStatus
 * @see app/Http/Controllers/Api/DigitalTwin/AssetController.php:129
 * @route '/api/digital-twin/assets/{asset}/status'
 */
        setStatusForm.patch = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: setStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    setStatus.form = setStatusForm
const AssetController = { index, store, show, update, destroy, setStatus }

export default AssetController