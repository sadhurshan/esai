import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\EventDeliveryController::index
 * @see app/Http/Controllers/Api/EventDeliveryController.php:21
 * @route '/api/events/deliveries'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/events/deliveries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\EventDeliveryController::index
 * @see app/Http/Controllers/Api/EventDeliveryController.php:21
 * @route '/api/events/deliveries'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EventDeliveryController::index
 * @see app/Http/Controllers/Api/EventDeliveryController.php:21
 * @route '/api/events/deliveries'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\EventDeliveryController::index
 * @see app/Http/Controllers/Api/EventDeliveryController.php:21
 * @route '/api/events/deliveries'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\EventDeliveryController::index
 * @see app/Http/Controllers/Api/EventDeliveryController.php:21
 * @route '/api/events/deliveries'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\EventDeliveryController::index
 * @see app/Http/Controllers/Api/EventDeliveryController.php:21
 * @route '/api/events/deliveries'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\EventDeliveryController::index
 * @see app/Http/Controllers/Api/EventDeliveryController.php:21
 * @route '/api/events/deliveries'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\EventDeliveryController::retry
 * @see app/Http/Controllers/Api/EventDeliveryController.php:92
 * @route '/api/events/deliveries/{delivery}/retry'
 */
export const retry = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retry.url(args, options),
    method: 'post',
})

retry.definition = {
    methods: ["post"],
    url: '/api/events/deliveries/{delivery}/retry',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\EventDeliveryController::retry
 * @see app/Http/Controllers/Api/EventDeliveryController.php:92
 * @route '/api/events/deliveries/{delivery}/retry'
 */
retry.url = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { delivery: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { delivery: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    delivery: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        delivery: typeof args.delivery === 'object'
                ? args.delivery.id
                : args.delivery,
                }

    return retry.definition.url
            .replace('{delivery}', parsedArgs.delivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EventDeliveryController::retry
 * @see app/Http/Controllers/Api/EventDeliveryController.php:92
 * @route '/api/events/deliveries/{delivery}/retry'
 */
retry.post = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retry.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\EventDeliveryController::retry
 * @see app/Http/Controllers/Api/EventDeliveryController.php:92
 * @route '/api/events/deliveries/{delivery}/retry'
 */
    const retryForm = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: retry.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\EventDeliveryController::retry
 * @see app/Http/Controllers/Api/EventDeliveryController.php:92
 * @route '/api/events/deliveries/{delivery}/retry'
 */
        retryForm.post = (args: { delivery: number | { id: number } } | [delivery: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: retry.url(args, options),
            method: 'post',
        })
    
    retry.form = retryForm
/**
* @see \App\Http\Controllers\Api\EventDeliveryController::replay
 * @see app/Http/Controllers/Api/EventDeliveryController.php:113
 * @route '/api/events/dlq/replay'
 */
export const replay = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: replay.url(options),
    method: 'post',
})

replay.definition = {
    methods: ["post"],
    url: '/api/events/dlq/replay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\EventDeliveryController::replay
 * @see app/Http/Controllers/Api/EventDeliveryController.php:113
 * @route '/api/events/dlq/replay'
 */
replay.url = (options?: RouteQueryOptions) => {
    return replay.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\EventDeliveryController::replay
 * @see app/Http/Controllers/Api/EventDeliveryController.php:113
 * @route '/api/events/dlq/replay'
 */
replay.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: replay.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\EventDeliveryController::replay
 * @see app/Http/Controllers/Api/EventDeliveryController.php:113
 * @route '/api/events/dlq/replay'
 */
    const replayForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: replay.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\EventDeliveryController::replay
 * @see app/Http/Controllers/Api/EventDeliveryController.php:113
 * @route '/api/events/dlq/replay'
 */
        replayForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: replay.url(options),
            method: 'post',
        })
    
    replay.form = replayForm
const EventDeliveryController = { index, retry, replay }

export default EventDeliveryController