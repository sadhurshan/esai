import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ExportController::index
 * @see app/Http/Controllers/Api/ExportController.php:26
 * @route '/api/exports'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/exports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ExportController::index
 * @see app/Http/Controllers/Api/ExportController.php:26
 * @route '/api/exports'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExportController::index
 * @see app/Http/Controllers/Api/ExportController.php:26
 * @route '/api/exports'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ExportController::index
 * @see app/Http/Controllers/Api/ExportController.php:26
 * @route '/api/exports'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ExportController::index
 * @see app/Http/Controllers/Api/ExportController.php:26
 * @route '/api/exports'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ExportController::index
 * @see app/Http/Controllers/Api/ExportController.php:26
 * @route '/api/exports'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ExportController::index
 * @see app/Http/Controllers/Api/ExportController.php:26
 * @route '/api/exports'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\ExportController::store
 * @see app/Http/Controllers/Api/ExportController.php:56
 * @route '/api/exports'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/exports',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ExportController::store
 * @see app/Http/Controllers/Api/ExportController.php:56
 * @route '/api/exports'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExportController::store
 * @see app/Http/Controllers/Api/ExportController.php:56
 * @route '/api/exports'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ExportController::store
 * @see app/Http/Controllers/Api/ExportController.php:56
 * @route '/api/exports'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ExportController::store
 * @see app/Http/Controllers/Api/ExportController.php:56
 * @route '/api/exports'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\ExportController::show
 * @see app/Http/Controllers/Api/ExportController.php:83
 * @route '/api/exports/{exportRequest}'
 */
export const show = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/exports/{exportRequest}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ExportController::show
 * @see app/Http/Controllers/Api/ExportController.php:83
 * @route '/api/exports/{exportRequest}'
 */
show.url = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exportRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { exportRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    exportRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exportRequest: typeof args.exportRequest === 'object'
                ? args.exportRequest.id
                : args.exportRequest,
                }

    return show.definition.url
            .replace('{exportRequest}', parsedArgs.exportRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExportController::show
 * @see app/Http/Controllers/Api/ExportController.php:83
 * @route '/api/exports/{exportRequest}'
 */
show.get = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ExportController::show
 * @see app/Http/Controllers/Api/ExportController.php:83
 * @route '/api/exports/{exportRequest}'
 */
show.head = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ExportController::show
 * @see app/Http/Controllers/Api/ExportController.php:83
 * @route '/api/exports/{exportRequest}'
 */
    const showForm = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ExportController::show
 * @see app/Http/Controllers/Api/ExportController.php:83
 * @route '/api/exports/{exportRequest}'
 */
        showForm.get = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ExportController::show
 * @see app/Http/Controllers/Api/ExportController.php:83
 * @route '/api/exports/{exportRequest}'
 */
        showForm.head = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\ExportController::download
 * @see app/Http/Controllers/Api/ExportController.php:102
 * @route '/api/exports/{exportRequest}/download'
 */
export const download = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/api/exports/{exportRequest}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ExportController::download
 * @see app/Http/Controllers/Api/ExportController.php:102
 * @route '/api/exports/{exportRequest}/download'
 */
download.url = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { exportRequest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { exportRequest: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    exportRequest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        exportRequest: typeof args.exportRequest === 'object'
                ? args.exportRequest.id
                : args.exportRequest,
                }

    return download.definition.url
            .replace('{exportRequest}', parsedArgs.exportRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ExportController::download
 * @see app/Http/Controllers/Api/ExportController.php:102
 * @route '/api/exports/{exportRequest}/download'
 */
download.get = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ExportController::download
 * @see app/Http/Controllers/Api/ExportController.php:102
 * @route '/api/exports/{exportRequest}/download'
 */
download.head = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ExportController::download
 * @see app/Http/Controllers/Api/ExportController.php:102
 * @route '/api/exports/{exportRequest}/download'
 */
    const downloadForm = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ExportController::download
 * @see app/Http/Controllers/Api/ExportController.php:102
 * @route '/api/exports/{exportRequest}/download'
 */
        downloadForm.get = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ExportController::download
 * @see app/Http/Controllers/Api/ExportController.php:102
 * @route '/api/exports/{exportRequest}/download'
 */
        downloadForm.head = (args: { exportRequest: number | { id: number } } | [exportRequest: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const ExportController = { index, store, show, download }

export default ExportController