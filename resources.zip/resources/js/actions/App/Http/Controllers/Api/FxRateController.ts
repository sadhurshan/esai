import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\FxRateController::index
 * @see app/Http/Controllers/Api/FxRateController.php:26
 * @route '/api/money/fx'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/money/fx',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\FxRateController::index
 * @see app/Http/Controllers/Api/FxRateController.php:26
 * @route '/api/money/fx'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FxRateController::index
 * @see app/Http/Controllers/Api/FxRateController.php:26
 * @route '/api/money/fx'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\FxRateController::index
 * @see app/Http/Controllers/Api/FxRateController.php:26
 * @route '/api/money/fx'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\FxRateController::index
 * @see app/Http/Controllers/Api/FxRateController.php:26
 * @route '/api/money/fx'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\FxRateController::index
 * @see app/Http/Controllers/Api/FxRateController.php:26
 * @route '/api/money/fx'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\FxRateController::index
 * @see app/Http/Controllers/Api/FxRateController.php:26
 * @route '/api/money/fx'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\FxRateController::upsert
 * @see app/Http/Controllers/Api/FxRateController.php:62
 * @route '/api/money/fx'
 */
export const upsert = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upsert.url(options),
    method: 'post',
})

upsert.definition = {
    methods: ["post"],
    url: '/api/money/fx',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\FxRateController::upsert
 * @see app/Http/Controllers/Api/FxRateController.php:62
 * @route '/api/money/fx'
 */
upsert.url = (options?: RouteQueryOptions) => {
    return upsert.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\FxRateController::upsert
 * @see app/Http/Controllers/Api/FxRateController.php:62
 * @route '/api/money/fx'
 */
upsert.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upsert.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\FxRateController::upsert
 * @see app/Http/Controllers/Api/FxRateController.php:62
 * @route '/api/money/fx'
 */
    const upsertForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upsert.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\FxRateController::upsert
 * @see app/Http/Controllers/Api/FxRateController.php:62
 * @route '/api/money/fx'
 */
        upsertForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upsert.url(options),
            method: 'post',
        })
    
    upsert.form = upsertForm
const FxRateController = { index, upsert }

export default FxRateController