import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\HealthController::__invoke
 * @see app/Http/Controllers/Api/HealthController.php:9
 * @route '/api/health'
 */
export const __invoke = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: __invoke.url(options),
    method: 'get',
})

__invoke.definition = {
    methods: ["get","head"],
    url: '/api/health',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\HealthController::__invoke
 * @see app/Http/Controllers/Api/HealthController.php:9
 * @route '/api/health'
 */
__invoke.url = (options?: RouteQueryOptions) => {
    return __invoke.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\HealthController::__invoke
 * @see app/Http/Controllers/Api/HealthController.php:9
 * @route '/api/health'
 */
__invoke.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: __invoke.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\HealthController::__invoke
 * @see app/Http/Controllers/Api/HealthController.php:9
 * @route '/api/health'
 */
__invoke.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: __invoke.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\HealthController::__invoke
 * @see app/Http/Controllers/Api/HealthController.php:9
 * @route '/api/health'
 */
    const __invokeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: __invoke.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\HealthController::__invoke
 * @see app/Http/Controllers/Api/HealthController.php:9
 * @route '/api/health'
 */
        __invokeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: __invoke.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\HealthController::__invoke
 * @see app/Http/Controllers/Api/HealthController.php:9
 * @route '/api/health'
 */
        __invokeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: __invoke.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    __invoke.form = __invokeForm
const HealthController = { __invoke }

export default HealthController