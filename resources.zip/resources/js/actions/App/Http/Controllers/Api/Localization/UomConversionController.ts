import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::index
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:26
 * @route '/api/localization/uoms/conversions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/localization/uoms/conversions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::index
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:26
 * @route '/api/localization/uoms/conversions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::index
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:26
 * @route '/api/localization/uoms/conversions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::index
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:26
 * @route '/api/localization/uoms/conversions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::index
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:26
 * @route '/api/localization/uoms/conversions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::index
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:26
 * @route '/api/localization/uoms/conversions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::index
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:26
 * @route '/api/localization/uoms/conversions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::upsert
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:60
 * @route '/api/localization/uoms/conversions'
 */
export const upsert = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upsert.url(options),
    method: 'post',
})

upsert.definition = {
    methods: ["post"],
    url: '/api/localization/uoms/conversions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::upsert
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:60
 * @route '/api/localization/uoms/conversions'
 */
upsert.url = (options?: RouteQueryOptions) => {
    return upsert.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::upsert
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:60
 * @route '/api/localization/uoms/conversions'
 */
upsert.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upsert.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::upsert
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:60
 * @route '/api/localization/uoms/conversions'
 */
    const upsertForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upsert.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::upsert
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:60
 * @route '/api/localization/uoms/conversions'
 */
        upsertForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upsert.url(options),
            method: 'post',
        })
    
    upsert.form = upsertForm
/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convert
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:107
 * @route '/api/localization/uom/convert'
 */
export const convert = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: convert.url(options),
    method: 'post',
})

convert.definition = {
    methods: ["post"],
    url: '/api/localization/uom/convert',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convert
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:107
 * @route '/api/localization/uom/convert'
 */
convert.url = (options?: RouteQueryOptions) => {
    return convert.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convert
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:107
 * @route '/api/localization/uom/convert'
 */
convert.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: convert.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convert
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:107
 * @route '/api/localization/uom/convert'
 */
    const convertForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: convert.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convert
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:107
 * @route '/api/localization/uom/convert'
 */
        convertForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: convert.url(options),
            method: 'post',
        })
    
    convert.form = convertForm
/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convertForPart
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:129
 * @route '/api/localization/parts/{part}/convert'
 */
export const convertForPart = (args: { part: number | { id: number } } | [part: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: convertForPart.url(args, options),
    method: 'get',
})

convertForPart.definition = {
    methods: ["get","head"],
    url: '/api/localization/parts/{part}/convert',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convertForPart
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:129
 * @route '/api/localization/parts/{part}/convert'
 */
convertForPart.url = (args: { part: number | { id: number } } | [part: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { part: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { part: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    part: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        part: typeof args.part === 'object'
                ? args.part.id
                : args.part,
                }

    return convertForPart.definition.url
            .replace('{part}', parsedArgs.part.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convertForPart
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:129
 * @route '/api/localization/parts/{part}/convert'
 */
convertForPart.get = (args: { part: number | { id: number } } | [part: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: convertForPart.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convertForPart
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:129
 * @route '/api/localization/parts/{part}/convert'
 */
convertForPart.head = (args: { part: number | { id: number } } | [part: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: convertForPart.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convertForPart
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:129
 * @route '/api/localization/parts/{part}/convert'
 */
    const convertForPartForm = (args: { part: number | { id: number } } | [part: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: convertForPart.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convertForPart
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:129
 * @route '/api/localization/parts/{part}/convert'
 */
        convertForPartForm.get = (args: { part: number | { id: number } } | [part: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: convertForPart.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Localization\UomConversionController::convertForPart
 * @see app/Http/Controllers/Api/Localization/UomConversionController.php:129
 * @route '/api/localization/parts/{part}/convert'
 */
        convertForPartForm.head = (args: { part: number | { id: number } } | [part: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: convertForPart.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    convertForPart.form = convertForPartForm
const UomConversionController = { index, upsert, convert, convertForPart }

export default UomConversionController