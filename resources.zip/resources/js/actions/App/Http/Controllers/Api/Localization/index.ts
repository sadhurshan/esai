import LocaleSettingsController from './LocaleSettingsController'
import UomController from './UomController'
import UomConversionController from './UomConversionController'
const Localization = {
    LocaleSettingsController: Object.assign(LocaleSettingsController, LocaleSettingsController),
UomController: Object.assign(UomController, UomController),
UomConversionController: Object.assign(UomConversionController, UomConversionController),
}

export default Localization