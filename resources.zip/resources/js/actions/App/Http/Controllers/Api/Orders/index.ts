import BuyerOrderController from './BuyerOrderController'
import SupplierOrderController from './SupplierOrderController'
import SupplierShipmentController from './SupplierShipmentController'
const Orders = {
    BuyerOrderController: Object.assign(BuyerOrderController, BuyerOrderController),
SupplierOrderController: Object.assign(SupplierOrderController, SupplierOrderController),
SupplierShipmentController: Object.assign(SupplierShipmentController, SupplierShipmentController),
}

export default Orders