import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\PurchaseOrderShipmentController::index
 * @see app/Http/Controllers/Api/PurchaseOrderShipmentController.php:12
 * @route '/api/purchase-orders/{purchaseOrder}/shipments'
 */
export const index = (args: { purchaseOrder: string | number } | [purchaseOrder: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/purchase-orders/{purchaseOrder}/shipments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\PurchaseOrderShipmentController::index
 * @see app/Http/Controllers/Api/PurchaseOrderShipmentController.php:12
 * @route '/api/purchase-orders/{purchaseOrder}/shipments'
 */
index.url = (args: { purchaseOrder: string | number } | [purchaseOrder: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { purchaseOrder: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    purchaseOrder: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        purchaseOrder: args.purchaseOrder,
                }

    return index.definition.url
            .replace('{purchaseOrder}', parsedArgs.purchaseOrder.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PurchaseOrderShipmentController::index
 * @see app/Http/Controllers/Api/PurchaseOrderShipmentController.php:12
 * @route '/api/purchase-orders/{purchaseOrder}/shipments'
 */
index.get = (args: { purchaseOrder: string | number } | [purchaseOrder: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\PurchaseOrderShipmentController::index
 * @see app/Http/Controllers/Api/PurchaseOrderShipmentController.php:12
 * @route '/api/purchase-orders/{purchaseOrder}/shipments'
 */
index.head = (args: { purchaseOrder: string | number } | [purchaseOrder: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\PurchaseOrderShipmentController::index
 * @see app/Http/Controllers/Api/PurchaseOrderShipmentController.php:12
 * @route '/api/purchase-orders/{purchaseOrder}/shipments'
 */
    const indexForm = (args: { purchaseOrder: string | number } | [purchaseOrder: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\PurchaseOrderShipmentController::index
 * @see app/Http/Controllers/Api/PurchaseOrderShipmentController.php:12
 * @route '/api/purchase-orders/{purchaseOrder}/shipments'
 */
        indexForm.get = (args: { purchaseOrder: string | number } | [purchaseOrder: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\PurchaseOrderShipmentController::index
 * @see app/Http/Controllers/Api/PurchaseOrderShipmentController.php:12
 * @route '/api/purchase-orders/{purchaseOrder}/shipments'
 */
        indexForm.head = (args: { purchaseOrder: string | number } | [purchaseOrder: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const PurchaseOrderShipmentController = { index }

export default PurchaseOrderShipmentController