import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\QuoteTotalsController::recalculate
 * @see app/Http/Controllers/Api/QuoteTotalsController.php:17
 * @route '/api/quotes/{quote}/recalculate'
 */
export const recalculate = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(args, options),
    method: 'post',
})

recalculate.definition = {
    methods: ["post"],
    url: '/api/quotes/{quote}/recalculate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuoteTotalsController::recalculate
 * @see app/Http/Controllers/Api/QuoteTotalsController.php:17
 * @route '/api/quotes/{quote}/recalculate'
 */
recalculate.url = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { quote: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { quote: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    quote: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quote: typeof args.quote === 'object'
                ? args.quote.id
                : args.quote,
                }

    return recalculate.definition.url
            .replace('{quote}', parsedArgs.quote.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuoteTotalsController::recalculate
 * @see app/Http/Controllers/Api/QuoteTotalsController.php:17
 * @route '/api/quotes/{quote}/recalculate'
 */
recalculate.post = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recalculate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuoteTotalsController::recalculate
 * @see app/Http/Controllers/Api/QuoteTotalsController.php:17
 * @route '/api/quotes/{quote}/recalculate'
 */
    const recalculateForm = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: recalculate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuoteTotalsController::recalculate
 * @see app/Http/Controllers/Api/QuoteTotalsController.php:17
 * @route '/api/quotes/{quote}/recalculate'
 */
        recalculateForm.post = (args: { quote: number | { id: number } } | [quote: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: recalculate.url(args, options),
            method: 'post',
        })
    
    recalculate.form = recalculateForm
const QuoteTotalsController = { recalculate }

export default QuoteTotalsController