import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RFQQuoteController::index
 * @see app/Http/Controllers/Api/RFQQuoteController.php:31
 * @route '/api/rfq-quotes/{rfq}'
 */
export const index = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfq-quotes/{rfq}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RFQQuoteController::index
 * @see app/Http/Controllers/Api/RFQQuoteController.php:31
 * @route '/api/rfq-quotes/{rfq}'
 */
index.url = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: args.rfq,
                }

    return index.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RFQQuoteController::index
 * @see app/Http/Controllers/Api/RFQQuoteController.php:31
 * @route '/api/rfq-quotes/{rfq}'
 */
index.get = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RFQQuoteController::index
 * @see app/Http/Controllers/Api/RFQQuoteController.php:31
 * @route '/api/rfq-quotes/{rfq}'
 */
index.head = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RFQQuoteController::index
 * @see app/Http/Controllers/Api/RFQQuoteController.php:31
 * @route '/api/rfq-quotes/{rfq}'
 */
    const indexForm = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RFQQuoteController::index
 * @see app/Http/Controllers/Api/RFQQuoteController.php:31
 * @route '/api/rfq-quotes/{rfq}'
 */
        indexForm.get = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RFQQuoteController::index
 * @see app/Http/Controllers/Api/RFQQuoteController.php:31
 * @route '/api/rfq-quotes/{rfq}'
 */
        indexForm.head = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\RFQQuoteController::store
 * @see app/Http/Controllers/Api/RFQQuoteController.php:95
 * @route '/api/rfq-quotes/{rfq}'
 */
export const store = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/rfq-quotes/{rfq}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RFQQuoteController::store
 * @see app/Http/Controllers/Api/RFQQuoteController.php:95
 * @route '/api/rfq-quotes/{rfq}'
 */
store.url = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: args.rfq,
                }

    return store.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RFQQuoteController::store
 * @see app/Http/Controllers/Api/RFQQuoteController.php:95
 * @route '/api/rfq-quotes/{rfq}'
 */
store.post = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RFQQuoteController::store
 * @see app/Http/Controllers/Api/RFQQuoteController.php:95
 * @route '/api/rfq-quotes/{rfq}'
 */
    const storeForm = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RFQQuoteController::store
 * @see app/Http/Controllers/Api/RFQQuoteController.php:95
 * @route '/api/rfq-quotes/{rfq}'
 */
        storeForm.post = (args: { rfq: string | number } | [rfq: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const RFQQuoteController = { index, store }

export default RFQQuoteController