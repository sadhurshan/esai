import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RfpController::index
 * @see app/Http/Controllers/Api/RfpController.php:26
 * @route '/api/rfps'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfps',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RfpController::index
 * @see app/Http/Controllers/Api/RfpController.php:26
 * @route '/api/rfps'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfpController::index
 * @see app/Http/Controllers/Api/RfpController.php:26
 * @route '/api/rfps'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RfpController::index
 * @see app/Http/Controllers/Api/RfpController.php:26
 * @route '/api/rfps'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RfpController::index
 * @see app/Http/Controllers/Api/RfpController.php:26
 * @route '/api/rfps'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RfpController::index
 * @see app/Http/Controllers/Api/RfpController.php:26
 * @route '/api/rfps'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RfpController::index
 * @see app/Http/Controllers/Api/RfpController.php:26
 * @route '/api/rfps'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\RfpController::store
 * @see app/Http/Controllers/Api/RfpController.php:45
 * @route '/api/rfps'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/rfps',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfpController::store
 * @see app/Http/Controllers/Api/RfpController.php:45
 * @route '/api/rfps'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfpController::store
 * @see app/Http/Controllers/Api/RfpController.php:45
 * @route '/api/rfps'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfpController::store
 * @see app/Http/Controllers/Api/RfpController.php:45
 * @route '/api/rfps'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfpController::store
 * @see app/Http/Controllers/Api/RfpController.php:45
 * @route '/api/rfps'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\RfpController::show
 * @see app/Http/Controllers/Api/RfpController.php:66
 * @route '/api/rfps/{rfp}'
 */
export const show = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/rfps/{rfp}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RfpController::show
 * @see app/Http/Controllers/Api/RfpController.php:66
 * @route '/api/rfps/{rfp}'
 */
show.url = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfp: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfp: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfp: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfp: typeof args.rfp === 'object'
                ? args.rfp.id
                : args.rfp,
                }

    return show.definition.url
            .replace('{rfp}', parsedArgs.rfp.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfpController::show
 * @see app/Http/Controllers/Api/RfpController.php:66
 * @route '/api/rfps/{rfp}'
 */
show.get = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RfpController::show
 * @see app/Http/Controllers/Api/RfpController.php:66
 * @route '/api/rfps/{rfp}'
 */
show.head = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RfpController::show
 * @see app/Http/Controllers/Api/RfpController.php:66
 * @route '/api/rfps/{rfp}'
 */
    const showForm = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RfpController::show
 * @see app/Http/Controllers/Api/RfpController.php:66
 * @route '/api/rfps/{rfp}'
 */
        showForm.get = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RfpController::show
 * @see app/Http/Controllers/Api/RfpController.php:66
 * @route '/api/rfps/{rfp}'
 */
        showForm.head = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\RfpController::update
 * @see app/Http/Controllers/Api/RfpController.php:84
 * @route '/api/rfps/{rfp}'
 */
export const update = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/rfps/{rfp}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\RfpController::update
 * @see app/Http/Controllers/Api/RfpController.php:84
 * @route '/api/rfps/{rfp}'
 */
update.url = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfp: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfp: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfp: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfp: typeof args.rfp === 'object'
                ? args.rfp.id
                : args.rfp,
                }

    return update.definition.url
            .replace('{rfp}', parsedArgs.rfp.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfpController::update
 * @see app/Http/Controllers/Api/RfpController.php:84
 * @route '/api/rfps/{rfp}'
 */
update.put = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\RfpController::update
 * @see app/Http/Controllers/Api/RfpController.php:84
 * @route '/api/rfps/{rfp}'
 */
    const updateForm = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfpController::update
 * @see app/Http/Controllers/Api/RfpController.php:84
 * @route '/api/rfps/{rfp}'
 */
        updateForm.put = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\RfpController::publish
 * @see app/Http/Controllers/Api/RfpController.php:104
 * @route '/api/rfps/{rfp}/publish'
 */
export const publish = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

publish.definition = {
    methods: ["post"],
    url: '/api/rfps/{rfp}/publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfpController::publish
 * @see app/Http/Controllers/Api/RfpController.php:104
 * @route '/api/rfps/{rfp}/publish'
 */
publish.url = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfp: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfp: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfp: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfp: typeof args.rfp === 'object'
                ? args.rfp.id
                : args.rfp,
                }

    return publish.definition.url
            .replace('{rfp}', parsedArgs.rfp.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfpController::publish
 * @see app/Http/Controllers/Api/RfpController.php:104
 * @route '/api/rfps/{rfp}/publish'
 */
publish.post = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfpController::publish
 * @see app/Http/Controllers/Api/RfpController.php:104
 * @route '/api/rfps/{rfp}/publish'
 */
    const publishForm = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publish.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfpController::publish
 * @see app/Http/Controllers/Api/RfpController.php:104
 * @route '/api/rfps/{rfp}/publish'
 */
        publishForm.post = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publish.url(args, options),
            method: 'post',
        })
    
    publish.form = publishForm
/**
* @see \App\Http\Controllers\Api\RfpController::moveToReview
 * @see app/Http/Controllers/Api/RfpController.php:109
 * @route '/api/rfps/{rfp}/move-to-review'
 */
export const moveToReview = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: moveToReview.url(args, options),
    method: 'post',
})

moveToReview.definition = {
    methods: ["post"],
    url: '/api/rfps/{rfp}/move-to-review',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfpController::moveToReview
 * @see app/Http/Controllers/Api/RfpController.php:109
 * @route '/api/rfps/{rfp}/move-to-review'
 */
moveToReview.url = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfp: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfp: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfp: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfp: typeof args.rfp === 'object'
                ? args.rfp.id
                : args.rfp,
                }

    return moveToReview.definition.url
            .replace('{rfp}', parsedArgs.rfp.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfpController::moveToReview
 * @see app/Http/Controllers/Api/RfpController.php:109
 * @route '/api/rfps/{rfp}/move-to-review'
 */
moveToReview.post = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: moveToReview.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfpController::moveToReview
 * @see app/Http/Controllers/Api/RfpController.php:109
 * @route '/api/rfps/{rfp}/move-to-review'
 */
    const moveToReviewForm = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: moveToReview.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfpController::moveToReview
 * @see app/Http/Controllers/Api/RfpController.php:109
 * @route '/api/rfps/{rfp}/move-to-review'
 */
        moveToReviewForm.post = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: moveToReview.url(args, options),
            method: 'post',
        })
    
    moveToReview.form = moveToReviewForm
/**
* @see \App\Http\Controllers\Api\RfpController::award
 * @see app/Http/Controllers/Api/RfpController.php:114
 * @route '/api/rfps/{rfp}/award'
 */
export const award = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: award.url(args, options),
    method: 'post',
})

award.definition = {
    methods: ["post"],
    url: '/api/rfps/{rfp}/award',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfpController::award
 * @see app/Http/Controllers/Api/RfpController.php:114
 * @route '/api/rfps/{rfp}/award'
 */
award.url = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfp: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfp: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfp: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfp: typeof args.rfp === 'object'
                ? args.rfp.id
                : args.rfp,
                }

    return award.definition.url
            .replace('{rfp}', parsedArgs.rfp.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfpController::award
 * @see app/Http/Controllers/Api/RfpController.php:114
 * @route '/api/rfps/{rfp}/award'
 */
award.post = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: award.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfpController::award
 * @see app/Http/Controllers/Api/RfpController.php:114
 * @route '/api/rfps/{rfp}/award'
 */
    const awardForm = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: award.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfpController::award
 * @see app/Http/Controllers/Api/RfpController.php:114
 * @route '/api/rfps/{rfp}/award'
 */
        awardForm.post = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: award.url(args, options),
            method: 'post',
        })
    
    award.form = awardForm
/**
* @see \App\Http\Controllers\Api\RfpController::closeWithoutAward
 * @see app/Http/Controllers/Api/RfpController.php:119
 * @route '/api/rfps/{rfp}/close-no-award'
 */
export const closeWithoutAward = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: closeWithoutAward.url(args, options),
    method: 'post',
})

closeWithoutAward.definition = {
    methods: ["post"],
    url: '/api/rfps/{rfp}/close-no-award',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfpController::closeWithoutAward
 * @see app/Http/Controllers/Api/RfpController.php:119
 * @route '/api/rfps/{rfp}/close-no-award'
 */
closeWithoutAward.url = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfp: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfp: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfp: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfp: typeof args.rfp === 'object'
                ? args.rfp.id
                : args.rfp,
                }

    return closeWithoutAward.definition.url
            .replace('{rfp}', parsedArgs.rfp.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfpController::closeWithoutAward
 * @see app/Http/Controllers/Api/RfpController.php:119
 * @route '/api/rfps/{rfp}/close-no-award'
 */
closeWithoutAward.post = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: closeWithoutAward.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfpController::closeWithoutAward
 * @see app/Http/Controllers/Api/RfpController.php:119
 * @route '/api/rfps/{rfp}/close-no-award'
 */
    const closeWithoutAwardForm = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: closeWithoutAward.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfpController::closeWithoutAward
 * @see app/Http/Controllers/Api/RfpController.php:119
 * @route '/api/rfps/{rfp}/close-no-award'
 */
        closeWithoutAwardForm.post = (args: { rfp: number | { id: number } } | [rfp: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: closeWithoutAward.url(args, options),
            method: 'post',
        })
    
    closeWithoutAward.form = closeWithoutAwardForm
const RfpController = { index, store, show, update, publish, moveToReview, award, closeWithoutAward }

export default RfpController