import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RfqClarificationController::index
 * @see app/Http/Controllers/Api/RfqClarificationController.php:32
 * @route '/api/rfqs/{rfq}/clarifications'
 */
export const index = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}/clarifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RfqClarificationController::index
 * @see app/Http/Controllers/Api/RfqClarificationController.php:32
 * @route '/api/rfqs/{rfq}/clarifications'
 */
index.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return index.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqClarificationController::index
 * @see app/Http/Controllers/Api/RfqClarificationController.php:32
 * @route '/api/rfqs/{rfq}/clarifications'
 */
index.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RfqClarificationController::index
 * @see app/Http/Controllers/Api/RfqClarificationController.php:32
 * @route '/api/rfqs/{rfq}/clarifications'
 */
index.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RfqClarificationController::index
 * @see app/Http/Controllers/Api/RfqClarificationController.php:32
 * @route '/api/rfqs/{rfq}/clarifications'
 */
    const indexForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RfqClarificationController::index
 * @see app/Http/Controllers/Api/RfqClarificationController.php:32
 * @route '/api/rfqs/{rfq}/clarifications'
 */
        indexForm.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RfqClarificationController::index
 * @see app/Http/Controllers/Api/RfqClarificationController.php:32
 * @route '/api/rfqs/{rfq}/clarifications'
 */
        indexForm.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\RfqClarificationController::downloadAttachment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:157
 * @route '/api/rfqs/{rfq}/clarifications/{clarification}/attachments/{attachment}'
 */
export const downloadAttachment = (args: { rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number } | [rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadAttachment.url(args, options),
    method: 'get',
})

downloadAttachment.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}/clarifications/{clarification}/attachments/{attachment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RfqClarificationController::downloadAttachment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:157
 * @route '/api/rfqs/{rfq}/clarifications/{clarification}/attachments/{attachment}'
 */
downloadAttachment.url = (args: { rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number } | [rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                    clarification: args[1],
                    attachment: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                                clarification: typeof args.clarification === 'object'
                ? args.clarification.id
                : args.clarification,
                                attachment: args.attachment,
                }

    return downloadAttachment.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace('{clarification}', parsedArgs.clarification.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqClarificationController::downloadAttachment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:157
 * @route '/api/rfqs/{rfq}/clarifications/{clarification}/attachments/{attachment}'
 */
downloadAttachment.get = (args: { rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number } | [rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadAttachment.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RfqClarificationController::downloadAttachment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:157
 * @route '/api/rfqs/{rfq}/clarifications/{clarification}/attachments/{attachment}'
 */
downloadAttachment.head = (args: { rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number } | [rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadAttachment.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RfqClarificationController::downloadAttachment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:157
 * @route '/api/rfqs/{rfq}/clarifications/{clarification}/attachments/{attachment}'
 */
    const downloadAttachmentForm = (args: { rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number } | [rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadAttachment.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RfqClarificationController::downloadAttachment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:157
 * @route '/api/rfqs/{rfq}/clarifications/{clarification}/attachments/{attachment}'
 */
        downloadAttachmentForm.get = (args: { rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number } | [rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadAttachment.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RfqClarificationController::downloadAttachment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:157
 * @route '/api/rfqs/{rfq}/clarifications/{clarification}/attachments/{attachment}'
 */
        downloadAttachmentForm.head = (args: { rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number } | [rfq: number | { id: number }, clarification: number | { id: number }, attachment: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadAttachment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadAttachment.form = downloadAttachmentForm
/**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeQuestion
 * @see app/Http/Controllers/Api/RfqClarificationController.php:58
 * @route '/api/rfqs/{rfq}/clarifications/question'
 */
export const storeQuestion = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeQuestion.url(args, options),
    method: 'post',
})

storeQuestion.definition = {
    methods: ["post"],
    url: '/api/rfqs/{rfq}/clarifications/question',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeQuestion
 * @see app/Http/Controllers/Api/RfqClarificationController.php:58
 * @route '/api/rfqs/{rfq}/clarifications/question'
 */
storeQuestion.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return storeQuestion.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeQuestion
 * @see app/Http/Controllers/Api/RfqClarificationController.php:58
 * @route '/api/rfqs/{rfq}/clarifications/question'
 */
storeQuestion.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeQuestion.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeQuestion
 * @see app/Http/Controllers/Api/RfqClarificationController.php:58
 * @route '/api/rfqs/{rfq}/clarifications/question'
 */
    const storeQuestionForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeQuestion.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeQuestion
 * @see app/Http/Controllers/Api/RfqClarificationController.php:58
 * @route '/api/rfqs/{rfq}/clarifications/question'
 */
        storeQuestionForm.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeQuestion.url(args, options),
            method: 'post',
        })
    
    storeQuestion.form = storeQuestionForm
/**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeAnswer
 * @see app/Http/Controllers/Api/RfqClarificationController.php:91
 * @route '/api/rfqs/{rfq}/clarifications/answer'
 */
export const storeAnswer = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAnswer.url(args, options),
    method: 'post',
})

storeAnswer.definition = {
    methods: ["post"],
    url: '/api/rfqs/{rfq}/clarifications/answer',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeAnswer
 * @see app/Http/Controllers/Api/RfqClarificationController.php:91
 * @route '/api/rfqs/{rfq}/clarifications/answer'
 */
storeAnswer.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return storeAnswer.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeAnswer
 * @see app/Http/Controllers/Api/RfqClarificationController.php:91
 * @route '/api/rfqs/{rfq}/clarifications/answer'
 */
storeAnswer.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAnswer.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeAnswer
 * @see app/Http/Controllers/Api/RfqClarificationController.php:91
 * @route '/api/rfqs/{rfq}/clarifications/answer'
 */
    const storeAnswerForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAnswer.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeAnswer
 * @see app/Http/Controllers/Api/RfqClarificationController.php:91
 * @route '/api/rfqs/{rfq}/clarifications/answer'
 */
        storeAnswerForm.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAnswer.url(args, options),
            method: 'post',
        })
    
    storeAnswer.form = storeAnswerForm
/**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeAmendment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:124
 * @route '/api/rfqs/{rfq}/clarifications/amendment'
 */
export const storeAmendment = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAmendment.url(args, options),
    method: 'post',
})

storeAmendment.definition = {
    methods: ["post"],
    url: '/api/rfqs/{rfq}/clarifications/amendment',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeAmendment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:124
 * @route '/api/rfqs/{rfq}/clarifications/amendment'
 */
storeAmendment.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return storeAmendment.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeAmendment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:124
 * @route '/api/rfqs/{rfq}/clarifications/amendment'
 */
storeAmendment.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAmendment.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeAmendment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:124
 * @route '/api/rfqs/{rfq}/clarifications/amendment'
 */
    const storeAmendmentForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAmendment.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\RfqClarificationController::storeAmendment
 * @see app/Http/Controllers/Api/RfqClarificationController.php:124
 * @route '/api/rfqs/{rfq}/clarifications/amendment'
 */
        storeAmendmentForm.post = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAmendment.url(args, options),
            method: 'post',
        })
    
    storeAmendment.form = storeAmendmentForm
const RfqClarificationController = { index, downloadAttachment, storeQuestion, storeAnswer, storeAmendment }

export default RfqClarificationController