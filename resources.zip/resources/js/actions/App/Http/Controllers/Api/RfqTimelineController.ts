import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\RfqTimelineController::__invoke
 * @see app/Http/Controllers/Api/RfqTimelineController.php:24
 * @route '/api/rfqs/{rfq}/timeline'
 */
const RfqTimelineController = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RfqTimelineController.url(args, options),
    method: 'get',
})

RfqTimelineController.definition = {
    methods: ["get","head"],
    url: '/api/rfqs/{rfq}/timeline',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\RfqTimelineController::__invoke
 * @see app/Http/Controllers/Api/RfqTimelineController.php:24
 * @route '/api/rfqs/{rfq}/timeline'
 */
RfqTimelineController.url = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rfq: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rfq: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rfq: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rfq: typeof args.rfq === 'object'
                ? args.rfq.id
                : args.rfq,
                }

    return RfqTimelineController.definition.url
            .replace('{rfq}', parsedArgs.rfq.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\RfqTimelineController::__invoke
 * @see app/Http/Controllers/Api/RfqTimelineController.php:24
 * @route '/api/rfqs/{rfq}/timeline'
 */
RfqTimelineController.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: RfqTimelineController.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\RfqTimelineController::__invoke
 * @see app/Http/Controllers/Api/RfqTimelineController.php:24
 * @route '/api/rfqs/{rfq}/timeline'
 */
RfqTimelineController.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: RfqTimelineController.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\RfqTimelineController::__invoke
 * @see app/Http/Controllers/Api/RfqTimelineController.php:24
 * @route '/api/rfqs/{rfq}/timeline'
 */
    const RfqTimelineControllerForm = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: RfqTimelineController.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\RfqTimelineController::__invoke
 * @see app/Http/Controllers/Api/RfqTimelineController.php:24
 * @route '/api/rfqs/{rfq}/timeline'
 */
        RfqTimelineControllerForm.get = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RfqTimelineController.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\RfqTimelineController::__invoke
 * @see app/Http/Controllers/Api/RfqTimelineController.php:24
 * @route '/api/rfqs/{rfq}/timeline'
 */
        RfqTimelineControllerForm.head = (args: { rfq: number | { id: number } } | [rfq: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: RfqTimelineController.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    RfqTimelineController.form = RfqTimelineControllerForm
export default RfqTimelineController