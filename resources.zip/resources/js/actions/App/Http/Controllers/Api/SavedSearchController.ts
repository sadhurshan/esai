import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\SavedSearchController::index
 * @see app/Http/Controllers/Api/SavedSearchController.php:20
 * @route '/api/saved-searches'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/saved-searches',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SavedSearchController::index
 * @see app/Http/Controllers/Api/SavedSearchController.php:20
 * @route '/api/saved-searches'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SavedSearchController::index
 * @see app/Http/Controllers/Api/SavedSearchController.php:20
 * @route '/api/saved-searches'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\SavedSearchController::index
 * @see app/Http/Controllers/Api/SavedSearchController.php:20
 * @route '/api/saved-searches'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\SavedSearchController::index
 * @see app/Http/Controllers/Api/SavedSearchController.php:20
 * @route '/api/saved-searches'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\SavedSearchController::index
 * @see app/Http/Controllers/Api/SavedSearchController.php:20
 * @route '/api/saved-searches'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\SavedSearchController::index
 * @see app/Http/Controllers/Api/SavedSearchController.php:20
 * @route '/api/saved-searches'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\SavedSearchController::store
 * @see app/Http/Controllers/Api/SavedSearchController.php:50
 * @route '/api/saved-searches'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/saved-searches',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SavedSearchController::store
 * @see app/Http/Controllers/Api/SavedSearchController.php:50
 * @route '/api/saved-searches'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SavedSearchController::store
 * @see app/Http/Controllers/Api/SavedSearchController.php:50
 * @route '/api/saved-searches'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\SavedSearchController::store
 * @see app/Http/Controllers/Api/SavedSearchController.php:50
 * @route '/api/saved-searches'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SavedSearchController::store
 * @see app/Http/Controllers/Api/SavedSearchController.php:50
 * @route '/api/saved-searches'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\SavedSearchController::show
 * @see app/Http/Controllers/Api/SavedSearchController.php:96
 * @route '/api/saved-searches/{savedSearch}'
 */
export const show = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/saved-searches/{savedSearch}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SavedSearchController::show
 * @see app/Http/Controllers/Api/SavedSearchController.php:96
 * @route '/api/saved-searches/{savedSearch}'
 */
show.url = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { savedSearch: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { savedSearch: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    savedSearch: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        savedSearch: typeof args.savedSearch === 'object'
                ? args.savedSearch.id
                : args.savedSearch,
                }

    return show.definition.url
            .replace('{savedSearch}', parsedArgs.savedSearch.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SavedSearchController::show
 * @see app/Http/Controllers/Api/SavedSearchController.php:96
 * @route '/api/saved-searches/{savedSearch}'
 */
show.get = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\SavedSearchController::show
 * @see app/Http/Controllers/Api/SavedSearchController.php:96
 * @route '/api/saved-searches/{savedSearch}'
 */
show.head = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\SavedSearchController::show
 * @see app/Http/Controllers/Api/SavedSearchController.php:96
 * @route '/api/saved-searches/{savedSearch}'
 */
    const showForm = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\SavedSearchController::show
 * @see app/Http/Controllers/Api/SavedSearchController.php:96
 * @route '/api/saved-searches/{savedSearch}'
 */
        showForm.get = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\SavedSearchController::show
 * @see app/Http/Controllers/Api/SavedSearchController.php:96
 * @route '/api/saved-searches/{savedSearch}'
 */
        showForm.head = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\SavedSearchController::update
 * @see app/Http/Controllers/Api/SavedSearchController.php:111
 * @route '/api/saved-searches/{savedSearch}'
 */
export const update = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/saved-searches/{savedSearch}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\SavedSearchController::update
 * @see app/Http/Controllers/Api/SavedSearchController.php:111
 * @route '/api/saved-searches/{savedSearch}'
 */
update.url = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { savedSearch: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { savedSearch: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    savedSearch: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        savedSearch: typeof args.savedSearch === 'object'
                ? args.savedSearch.id
                : args.savedSearch,
                }

    return update.definition.url
            .replace('{savedSearch}', parsedArgs.savedSearch.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SavedSearchController::update
 * @see app/Http/Controllers/Api/SavedSearchController.php:111
 * @route '/api/saved-searches/{savedSearch}'
 */
update.put = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\SavedSearchController::update
 * @see app/Http/Controllers/Api/SavedSearchController.php:111
 * @route '/api/saved-searches/{savedSearch}'
 */
    const updateForm = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SavedSearchController::update
 * @see app/Http/Controllers/Api/SavedSearchController.php:111
 * @route '/api/saved-searches/{savedSearch}'
 */
        updateForm.put = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\SavedSearchController::destroy
 * @see app/Http/Controllers/Api/SavedSearchController.php:160
 * @route '/api/saved-searches/{savedSearch}'
 */
export const destroy = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/saved-searches/{savedSearch}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\SavedSearchController::destroy
 * @see app/Http/Controllers/Api/SavedSearchController.php:160
 * @route '/api/saved-searches/{savedSearch}'
 */
destroy.url = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { savedSearch: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { savedSearch: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    savedSearch: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        savedSearch: typeof args.savedSearch === 'object'
                ? args.savedSearch.id
                : args.savedSearch,
                }

    return destroy.definition.url
            .replace('{savedSearch}', parsedArgs.savedSearch.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SavedSearchController::destroy
 * @see app/Http/Controllers/Api/SavedSearchController.php:160
 * @route '/api/saved-searches/{savedSearch}'
 */
destroy.delete = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\SavedSearchController::destroy
 * @see app/Http/Controllers/Api/SavedSearchController.php:160
 * @route '/api/saved-searches/{savedSearch}'
 */
    const destroyForm = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SavedSearchController::destroy
 * @see app/Http/Controllers/Api/SavedSearchController.php:160
 * @route '/api/saved-searches/{savedSearch}'
 */
        destroyForm.delete = (args: { savedSearch: number | { id: number } } | [savedSearch: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const SavedSearchController = { index, store, show, update, destroy }

export default SavedSearchController