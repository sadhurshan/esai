import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::show
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:24
 * @route '/api/settings/company'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/settings/company',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::show
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:24
 * @route '/api/settings/company'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::show
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:24
 * @route '/api/settings/company'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::show
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:24
 * @route '/api/settings/company'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::show
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:24
 * @route '/api/settings/company'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::show
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:24
 * @route '/api/settings/company'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::show
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:24
 * @route '/api/settings/company'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::update
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:41
 * @route '/api/settings/company'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/api/settings/company',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::update
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:41
 * @route '/api/settings/company'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::update
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:41
 * @route '/api/settings/company'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::update
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:41
 * @route '/api/settings/company'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Settings\CompanySettingsController::update
 * @see app/Http/Controllers/Api/Settings/CompanySettingsController.php:41
 * @route '/api/settings/company'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const CompanySettingsController = { show, update }

export default CompanySettingsController