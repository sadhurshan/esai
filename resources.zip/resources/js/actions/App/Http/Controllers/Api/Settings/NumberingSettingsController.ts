import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::show
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:20
 * @route '/api/settings/numbering'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/settings/numbering',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::show
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:20
 * @route '/api/settings/numbering'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::show
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:20
 * @route '/api/settings/numbering'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::show
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:20
 * @route '/api/settings/numbering'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::show
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:20
 * @route '/api/settings/numbering'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::show
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:20
 * @route '/api/settings/numbering'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::show
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:20
 * @route '/api/settings/numbering'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::update
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:37
 * @route '/api/settings/numbering'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/api/settings/numbering',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::update
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:37
 * @route '/api/settings/numbering'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::update
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:37
 * @route '/api/settings/numbering'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::update
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:37
 * @route '/api/settings/numbering'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Settings\NumberingSettingsController::update
 * @see app/Http/Controllers/Api/Settings/NumberingSettingsController.php:37
 * @route '/api/settings/numbering'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const NumberingSettingsController = { show, update }

export default NumberingSettingsController