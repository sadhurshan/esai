import CompanySettingsController from './CompanySettingsController'
import CompanyAiSettingsController from './CompanyAiSettingsController'
import NumberingSettingsController from './NumberingSettingsController'
const Settings = {
    CompanySettingsController: Object.assign(CompanySettingsController, CompanySettingsController),
CompanyAiSettingsController: Object.assign(CompanyAiSettingsController, CompanyAiSettingsController),
NumberingSettingsController: Object.assign(NumberingSettingsController, NumberingSettingsController),
}

export default Settings