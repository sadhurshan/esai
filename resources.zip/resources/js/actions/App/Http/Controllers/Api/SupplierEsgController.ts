import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\SupplierEsgController::index
 * @see app/Http/Controllers/Api/SupplierEsgController.php:37
 * @route '/api/suppliers/{supplier}/esg'
 */
export const index = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/suppliers/{supplier}/esg',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SupplierEsgController::index
 * @see app/Http/Controllers/Api/SupplierEsgController.php:37
 * @route '/api/suppliers/{supplier}/esg'
 */
index.url = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supplier: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { supplier: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    supplier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        supplier: typeof args.supplier === 'object'
                ? args.supplier.id
                : args.supplier,
                }

    return index.definition.url
            .replace('{supplier}', parsedArgs.supplier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupplierEsgController::index
 * @see app/Http/Controllers/Api/SupplierEsgController.php:37
 * @route '/api/suppliers/{supplier}/esg'
 */
index.get = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\SupplierEsgController::index
 * @see app/Http/Controllers/Api/SupplierEsgController.php:37
 * @route '/api/suppliers/{supplier}/esg'
 */
index.head = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\SupplierEsgController::index
 * @see app/Http/Controllers/Api/SupplierEsgController.php:37
 * @route '/api/suppliers/{supplier}/esg'
 */
    const indexForm = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\SupplierEsgController::index
 * @see app/Http/Controllers/Api/SupplierEsgController.php:37
 * @route '/api/suppliers/{supplier}/esg'
 */
        indexForm.get = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\SupplierEsgController::index
 * @see app/Http/Controllers/Api/SupplierEsgController.php:37
 * @route '/api/suppliers/{supplier}/esg'
 */
        indexForm.head = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\SupplierEsgController::store
 * @see app/Http/Controllers/Api/SupplierEsgController.php:95
 * @route '/api/suppliers/{supplier}/esg'
 */
export const store = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/suppliers/{supplier}/esg',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SupplierEsgController::store
 * @see app/Http/Controllers/Api/SupplierEsgController.php:95
 * @route '/api/suppliers/{supplier}/esg'
 */
store.url = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supplier: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { supplier: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    supplier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        supplier: typeof args.supplier === 'object'
                ? args.supplier.id
                : args.supplier,
                }

    return store.definition.url
            .replace('{supplier}', parsedArgs.supplier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupplierEsgController::store
 * @see app/Http/Controllers/Api/SupplierEsgController.php:95
 * @route '/api/suppliers/{supplier}/esg'
 */
store.post = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\SupplierEsgController::store
 * @see app/Http/Controllers/Api/SupplierEsgController.php:95
 * @route '/api/suppliers/{supplier}/esg'
 */
    const storeForm = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SupplierEsgController::store
 * @see app/Http/Controllers/Api/SupplierEsgController.php:95
 * @route '/api/suppliers/{supplier}/esg'
 */
        storeForm.post = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\SupplierEsgController::exportMethod
 * @see app/Http/Controllers/Api/SupplierEsgController.php:228
 * @route '/api/suppliers/{supplier}/esg/export'
 */
export const exportMethod = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exportMethod.url(args, options),
    method: 'post',
})

exportMethod.definition = {
    methods: ["post"],
    url: '/api/suppliers/{supplier}/esg/export',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SupplierEsgController::exportMethod
 * @see app/Http/Controllers/Api/SupplierEsgController.php:228
 * @route '/api/suppliers/{supplier}/esg/export'
 */
exportMethod.url = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supplier: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { supplier: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    supplier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        supplier: typeof args.supplier === 'object'
                ? args.supplier.id
                : args.supplier,
                }

    return exportMethod.definition.url
            .replace('{supplier}', parsedArgs.supplier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupplierEsgController::exportMethod
 * @see app/Http/Controllers/Api/SupplierEsgController.php:228
 * @route '/api/suppliers/{supplier}/esg/export'
 */
exportMethod.post = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exportMethod.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\SupplierEsgController::exportMethod
 * @see app/Http/Controllers/Api/SupplierEsgController.php:228
 * @route '/api/suppliers/{supplier}/esg/export'
 */
    const exportMethodForm = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: exportMethod.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SupplierEsgController::exportMethod
 * @see app/Http/Controllers/Api/SupplierEsgController.php:228
 * @route '/api/suppliers/{supplier}/esg/export'
 */
        exportMethodForm.post = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: exportMethod.url(args, options),
            method: 'post',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\Api\SupplierEsgController::update
 * @see app/Http/Controllers/Api/SupplierEsgController.php:167
 * @route '/api/suppliers/{supplier}/esg/{record}'
 */
export const update = (args: { supplier: number | { id: number }, record: number | { id: number } } | [supplier: number | { id: number }, record: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/suppliers/{supplier}/esg/{record}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\SupplierEsgController::update
 * @see app/Http/Controllers/Api/SupplierEsgController.php:167
 * @route '/api/suppliers/{supplier}/esg/{record}'
 */
update.url = (args: { supplier: number | { id: number }, record: number | { id: number } } | [supplier: number | { id: number }, record: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    supplier: args[0],
                    record: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        supplier: typeof args.supplier === 'object'
                ? args.supplier.id
                : args.supplier,
                                record: typeof args.record === 'object'
                ? args.record.id
                : args.record,
                }

    return update.definition.url
            .replace('{supplier}', parsedArgs.supplier.toString())
            .replace('{record}', parsedArgs.record.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupplierEsgController::update
 * @see app/Http/Controllers/Api/SupplierEsgController.php:167
 * @route '/api/suppliers/{supplier}/esg/{record}'
 */
update.put = (args: { supplier: number | { id: number }, record: number | { id: number } } | [supplier: number | { id: number }, record: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\SupplierEsgController::update
 * @see app/Http/Controllers/Api/SupplierEsgController.php:167
 * @route '/api/suppliers/{supplier}/esg/{record}'
 */
    const updateForm = (args: { supplier: number | { id: number }, record: number | { id: number } } | [supplier: number | { id: number }, record: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SupplierEsgController::update
 * @see app/Http/Controllers/Api/SupplierEsgController.php:167
 * @route '/api/suppliers/{supplier}/esg/{record}'
 */
        updateForm.put = (args: { supplier: number | { id: number }, record: number | { id: number } } | [supplier: number | { id: number }, record: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\SupplierEsgController::destroy
 * @see app/Http/Controllers/Api/SupplierEsgController.php:204
 * @route '/api/suppliers/{supplier}/esg/{record}'
 */
export const destroy = (args: { supplier: number | { id: number }, record: number | { id: number } } | [supplier: number | { id: number }, record: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/suppliers/{supplier}/esg/{record}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\SupplierEsgController::destroy
 * @see app/Http/Controllers/Api/SupplierEsgController.php:204
 * @route '/api/suppliers/{supplier}/esg/{record}'
 */
destroy.url = (args: { supplier: number | { id: number }, record: number | { id: number } } | [supplier: number | { id: number }, record: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    supplier: args[0],
                    record: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        supplier: typeof args.supplier === 'object'
                ? args.supplier.id
                : args.supplier,
                                record: typeof args.record === 'object'
                ? args.record.id
                : args.record,
                }

    return destroy.definition.url
            .replace('{supplier}', parsedArgs.supplier.toString())
            .replace('{record}', parsedArgs.record.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupplierEsgController::destroy
 * @see app/Http/Controllers/Api/SupplierEsgController.php:204
 * @route '/api/suppliers/{supplier}/esg/{record}'
 */
destroy.delete = (args: { supplier: number | { id: number }, record: number | { id: number } } | [supplier: number | { id: number }, record: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\SupplierEsgController::destroy
 * @see app/Http/Controllers/Api/SupplierEsgController.php:204
 * @route '/api/suppliers/{supplier}/esg/{record}'
 */
    const destroyForm = (args: { supplier: number | { id: number }, record: number | { id: number } } | [supplier: number | { id: number }, record: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SupplierEsgController::destroy
 * @see app/Http/Controllers/Api/SupplierEsgController.php:204
 * @route '/api/suppliers/{supplier}/esg/{record}'
 */
        destroyForm.delete = (args: { supplier: number | { id: number }, record: number | { id: number } } | [supplier: number | { id: number }, record: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const SupplierEsgController = { index, store, exportMethod, update, destroy, export: exportMethod }

export default SupplierEsgController