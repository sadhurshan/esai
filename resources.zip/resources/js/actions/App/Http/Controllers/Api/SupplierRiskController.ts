import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\SupplierRiskController::index
 * @see app/Http/Controllers/Api/SupplierRiskController.php:22
 * @route '/api/risk'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/risk',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SupplierRiskController::index
 * @see app/Http/Controllers/Api/SupplierRiskController.php:22
 * @route '/api/risk'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupplierRiskController::index
 * @see app/Http/Controllers/Api/SupplierRiskController.php:22
 * @route '/api/risk'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\SupplierRiskController::index
 * @see app/Http/Controllers/Api/SupplierRiskController.php:22
 * @route '/api/risk'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\SupplierRiskController::index
 * @see app/Http/Controllers/Api/SupplierRiskController.php:22
 * @route '/api/risk'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\SupplierRiskController::index
 * @see app/Http/Controllers/Api/SupplierRiskController.php:22
 * @route '/api/risk'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\SupplierRiskController::index
 * @see app/Http/Controllers/Api/SupplierRiskController.php:22
 * @route '/api/risk'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\SupplierRiskController::show
 * @see app/Http/Controllers/Api/SupplierRiskController.php:79
 * @route '/api/risk/{supplier}'
 */
export const show = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/risk/{supplier}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SupplierRiskController::show
 * @see app/Http/Controllers/Api/SupplierRiskController.php:79
 * @route '/api/risk/{supplier}'
 */
show.url = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { supplier: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { supplier: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    supplier: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        supplier: typeof args.supplier === 'object'
                ? args.supplier.id
                : args.supplier,
                }

    return show.definition.url
            .replace('{supplier}', parsedArgs.supplier.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupplierRiskController::show
 * @see app/Http/Controllers/Api/SupplierRiskController.php:79
 * @route '/api/risk/{supplier}'
 */
show.get = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\SupplierRiskController::show
 * @see app/Http/Controllers/Api/SupplierRiskController.php:79
 * @route '/api/risk/{supplier}'
 */
show.head = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\SupplierRiskController::show
 * @see app/Http/Controllers/Api/SupplierRiskController.php:79
 * @route '/api/risk/{supplier}'
 */
    const showForm = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\SupplierRiskController::show
 * @see app/Http/Controllers/Api/SupplierRiskController.php:79
 * @route '/api/risk/{supplier}'
 */
        showForm.get = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\SupplierRiskController::show
 * @see app/Http/Controllers/Api/SupplierRiskController.php:79
 * @route '/api/risk/{supplier}'
 */
        showForm.head = (args: { supplier: number | { id: number } } | [supplier: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\SupplierRiskController::generate
 * @see app/Http/Controllers/Api/SupplierRiskController.php:106
 * @route '/api/risk/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/api/risk/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\SupplierRiskController::generate
 * @see app/Http/Controllers/Api/SupplierRiskController.php:106
 * @route '/api/risk/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupplierRiskController::generate
 * @see app/Http/Controllers/Api/SupplierRiskController.php:106
 * @route '/api/risk/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\SupplierRiskController::generate
 * @see app/Http/Controllers/Api/SupplierRiskController.php:106
 * @route '/api/risk/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SupplierRiskController::generate
 * @see app/Http/Controllers/Api/SupplierRiskController.php:106
 * @route '/api/risk/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
const SupplierRiskController = { index, show, generate }

export default SupplierRiskController