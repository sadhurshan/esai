import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::status
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:17
 * @route '/api/me/supplier-application/status'
 */
export const status = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})

status.definition = {
    methods: ["get","head"],
    url: '/api/me/supplier-application/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::status
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:17
 * @route '/api/me/supplier-application/status'
 */
status.url = (options?: RouteQueryOptions) => {
    return status.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::status
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:17
 * @route '/api/me/supplier-application/status'
 */
status.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::status
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:17
 * @route '/api/me/supplier-application/status'
 */
status.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::status
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:17
 * @route '/api/me/supplier-application/status'
 */
    const statusForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: status.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::status
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:17
 * @route '/api/me/supplier-application/status'
 */
        statusForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: status.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::status
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:17
 * @route '/api/me/supplier-application/status'
 */
        statusForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: status.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    status.form = statusForm
/**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::updateVisibility
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:45
 * @route '/api/me/supplier/visibility'
 */
export const updateVisibility = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateVisibility.url(options),
    method: 'put',
})

updateVisibility.definition = {
    methods: ["put"],
    url: '/api/me/supplier/visibility',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::updateVisibility
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:45
 * @route '/api/me/supplier/visibility'
 */
updateVisibility.url = (options?: RouteQueryOptions) => {
    return updateVisibility.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::updateVisibility
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:45
 * @route '/api/me/supplier/visibility'
 */
updateVisibility.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateVisibility.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::updateVisibility
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:45
 * @route '/api/me/supplier/visibility'
 */
    const updateVisibilityForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateVisibility.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\SupplierSelfServiceController::updateVisibility
 * @see app/Http/Controllers/Api/SupplierSelfServiceController.php:45
 * @route '/api/me/supplier/visibility'
 */
        updateVisibilityForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateVisibility.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateVisibility.form = updateVisibilityForm
const SupplierSelfServiceController = { status, updateVisibility }

export default SupplierSelfServiceController