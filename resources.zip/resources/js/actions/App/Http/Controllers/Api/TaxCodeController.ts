import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\TaxCodeController::index
 * @see app/Http/Controllers/Api/TaxCodeController.php:23
 * @route '/api/money/tax-codes'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/money/tax-codes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\TaxCodeController::index
 * @see app/Http/Controllers/Api/TaxCodeController.php:23
 * @route '/api/money/tax-codes'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\TaxCodeController::index
 * @see app/Http/Controllers/Api/TaxCodeController.php:23
 * @route '/api/money/tax-codes'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\TaxCodeController::index
 * @see app/Http/Controllers/Api/TaxCodeController.php:23
 * @route '/api/money/tax-codes'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\TaxCodeController::index
 * @see app/Http/Controllers/Api/TaxCodeController.php:23
 * @route '/api/money/tax-codes'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\TaxCodeController::index
 * @see app/Http/Controllers/Api/TaxCodeController.php:23
 * @route '/api/money/tax-codes'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\TaxCodeController::index
 * @see app/Http/Controllers/Api/TaxCodeController.php:23
 * @route '/api/money/tax-codes'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\TaxCodeController::store
 * @see app/Http/Controllers/Api/TaxCodeController.php:71
 * @route '/api/money/tax-codes'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/money/tax-codes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\TaxCodeController::store
 * @see app/Http/Controllers/Api/TaxCodeController.php:71
 * @route '/api/money/tax-codes'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\TaxCodeController::store
 * @see app/Http/Controllers/Api/TaxCodeController.php:71
 * @route '/api/money/tax-codes'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\TaxCodeController::store
 * @see app/Http/Controllers/Api/TaxCodeController.php:71
 * @route '/api/money/tax-codes'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\TaxCodeController::store
 * @see app/Http/Controllers/Api/TaxCodeController.php:71
 * @route '/api/money/tax-codes'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\TaxCodeController::show
 * @see app/Http/Controllers/Api/TaxCodeController.php:96
 * @route '/api/money/tax-codes/{tax_code}'
 */
export const show = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/money/tax-codes/{tax_code}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\TaxCodeController::show
 * @see app/Http/Controllers/Api/TaxCodeController.php:96
 * @route '/api/money/tax-codes/{tax_code}'
 */
show.url = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tax_code: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    tax_code: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tax_code: args.tax_code,
                }

    return show.definition.url
            .replace('{tax_code}', parsedArgs.tax_code.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\TaxCodeController::show
 * @see app/Http/Controllers/Api/TaxCodeController.php:96
 * @route '/api/money/tax-codes/{tax_code}'
 */
show.get = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\TaxCodeController::show
 * @see app/Http/Controllers/Api/TaxCodeController.php:96
 * @route '/api/money/tax-codes/{tax_code}'
 */
show.head = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\TaxCodeController::show
 * @see app/Http/Controllers/Api/TaxCodeController.php:96
 * @route '/api/money/tax-codes/{tax_code}'
 */
    const showForm = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\TaxCodeController::show
 * @see app/Http/Controllers/Api/TaxCodeController.php:96
 * @route '/api/money/tax-codes/{tax_code}'
 */
        showForm.get = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\TaxCodeController::show
 * @see app/Http/Controllers/Api/TaxCodeController.php:96
 * @route '/api/money/tax-codes/{tax_code}'
 */
        showForm.head = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\TaxCodeController::update
 * @see app/Http/Controllers/Api/TaxCodeController.php:106
 * @route '/api/money/tax-codes/{tax_code}'
 */
export const update = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/api/money/tax-codes/{tax_code}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Api\TaxCodeController::update
 * @see app/Http/Controllers/Api/TaxCodeController.php:106
 * @route '/api/money/tax-codes/{tax_code}'
 */
update.url = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tax_code: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    tax_code: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tax_code: args.tax_code,
                }

    return update.definition.url
            .replace('{tax_code}', parsedArgs.tax_code.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\TaxCodeController::update
 * @see app/Http/Controllers/Api/TaxCodeController.php:106
 * @route '/api/money/tax-codes/{tax_code}'
 */
update.put = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Api\TaxCodeController::update
 * @see app/Http/Controllers/Api/TaxCodeController.php:106
 * @route '/api/money/tax-codes/{tax_code}'
 */
update.patch = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Api\TaxCodeController::update
 * @see app/Http/Controllers/Api/TaxCodeController.php:106
 * @route '/api/money/tax-codes/{tax_code}'
 */
    const updateForm = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\TaxCodeController::update
 * @see app/Http/Controllers/Api/TaxCodeController.php:106
 * @route '/api/money/tax-codes/{tax_code}'
 */
        updateForm.put = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Api\TaxCodeController::update
 * @see app/Http/Controllers/Api/TaxCodeController.php:106
 * @route '/api/money/tax-codes/{tax_code}'
 */
        updateForm.patch = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\TaxCodeController::destroy
 * @see app/Http/Controllers/Api/TaxCodeController.php:133
 * @route '/api/money/tax-codes/{tax_code}'
 */
export const destroy = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/money/tax-codes/{tax_code}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\TaxCodeController::destroy
 * @see app/Http/Controllers/Api/TaxCodeController.php:133
 * @route '/api/money/tax-codes/{tax_code}'
 */
destroy.url = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tax_code: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    tax_code: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tax_code: args.tax_code,
                }

    return destroy.definition.url
            .replace('{tax_code}', parsedArgs.tax_code.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\TaxCodeController::destroy
 * @see app/Http/Controllers/Api/TaxCodeController.php:133
 * @route '/api/money/tax-codes/{tax_code}'
 */
destroy.delete = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\TaxCodeController::destroy
 * @see app/Http/Controllers/Api/TaxCodeController.php:133
 * @route '/api/money/tax-codes/{tax_code}'
 */
    const destroyForm = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\TaxCodeController::destroy
 * @see app/Http/Controllers/Api/TaxCodeController.php:133
 * @route '/api/money/tax-codes/{tax_code}'
 */
        destroyForm.delete = (args: { tax_code: string | number } | [tax_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const TaxCodeController = { index, store, show, update, destroy }

export default TaxCodeController