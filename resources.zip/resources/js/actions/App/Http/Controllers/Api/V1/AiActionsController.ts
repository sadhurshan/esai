import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::plan
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:44
 * @route '/api/v1/ai/actions/plan'
 */
export const plan = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: plan.url(options),
    method: 'post',
})

plan.definition = {
    methods: ["post"],
    url: '/api/v1/ai/actions/plan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::plan
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:44
 * @route '/api/v1/ai/actions/plan'
 */
plan.url = (options?: RouteQueryOptions) => {
    return plan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::plan
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:44
 * @route '/api/v1/ai/actions/plan'
 */
plan.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: plan.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::plan
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:44
 * @route '/api/v1/ai/actions/plan'
 */
    const planForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: plan.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::plan
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:44
 * @route '/api/v1/ai/actions/plan'
 */
        planForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: plan.url(options),
            method: 'post',
        })
    
    plan.form = planForm
/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::approve
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:140
 * @route '/api/v1/ai/actions/{draft}/approve'
 */
const approve019c02af55a50af98ab26d98da0525ba = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve019c02af55a50af98ab26d98da0525ba.url(args, options),
    method: 'post',
})

approve019c02af55a50af98ab26d98da0525ba.definition = {
    methods: ["post"],
    url: '/api/v1/ai/actions/{draft}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::approve
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:140
 * @route '/api/v1/ai/actions/{draft}/approve'
 */
approve019c02af55a50af98ab26d98da0525ba.url = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { draft: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    draft: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        draft: args.draft,
                }

    return approve019c02af55a50af98ab26d98da0525ba.definition.url
            .replace('{draft}', parsedArgs.draft.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::approve
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:140
 * @route '/api/v1/ai/actions/{draft}/approve'
 */
approve019c02af55a50af98ab26d98da0525ba.post = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve019c02af55a50af98ab26d98da0525ba.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::approve
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:140
 * @route '/api/v1/ai/actions/{draft}/approve'
 */
    const approve019c02af55a50af98ab26d98da0525baForm = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve019c02af55a50af98ab26d98da0525ba.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::approve
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:140
 * @route '/api/v1/ai/actions/{draft}/approve'
 */
        approve019c02af55a50af98ab26d98da0525baForm.post = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve019c02af55a50af98ab26d98da0525ba.url(args, options),
            method: 'post',
        })
    
    approve019c02af55a50af98ab26d98da0525ba.form = approve019c02af55a50af98ab26d98da0525baForm
    /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::approve
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:140
 * @route '/api/v1/ai/drafts/{draft}/approve'
 */
const approve52866bf822b3ab06b272d80f9ada2084 = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve52866bf822b3ab06b272d80f9ada2084.url(args, options),
    method: 'post',
})

approve52866bf822b3ab06b272d80f9ada2084.definition = {
    methods: ["post"],
    url: '/api/v1/ai/drafts/{draft}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::approve
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:140
 * @route '/api/v1/ai/drafts/{draft}/approve'
 */
approve52866bf822b3ab06b272d80f9ada2084.url = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { draft: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    draft: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        draft: args.draft,
                }

    return approve52866bf822b3ab06b272d80f9ada2084.definition.url
            .replace('{draft}', parsedArgs.draft.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::approve
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:140
 * @route '/api/v1/ai/drafts/{draft}/approve'
 */
approve52866bf822b3ab06b272d80f9ada2084.post = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve52866bf822b3ab06b272d80f9ada2084.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::approve
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:140
 * @route '/api/v1/ai/drafts/{draft}/approve'
 */
    const approve52866bf822b3ab06b272d80f9ada2084Form = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve52866bf822b3ab06b272d80f9ada2084.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::approve
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:140
 * @route '/api/v1/ai/drafts/{draft}/approve'
 */
        approve52866bf822b3ab06b272d80f9ada2084Form.post = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve52866bf822b3ab06b272d80f9ada2084.url(args, options),
            method: 'post',
        })
    
    approve52866bf822b3ab06b272d80f9ada2084.form = approve52866bf822b3ab06b272d80f9ada2084Form

export const approve = {
    '/api/v1/ai/actions/{draft}/approve': approve019c02af55a50af98ab26d98da0525ba,
    '/api/v1/ai/drafts/{draft}/approve': approve52866bf822b3ab06b272d80f9ada2084,
}

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::reject
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:228
 * @route '/api/v1/ai/actions/{draft}/reject'
 */
const rejectcedaf5294e19b6f85c25890e13782845 = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectcedaf5294e19b6f85c25890e13782845.url(args, options),
    method: 'post',
})

rejectcedaf5294e19b6f85c25890e13782845.definition = {
    methods: ["post"],
    url: '/api/v1/ai/actions/{draft}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::reject
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:228
 * @route '/api/v1/ai/actions/{draft}/reject'
 */
rejectcedaf5294e19b6f85c25890e13782845.url = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { draft: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    draft: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        draft: args.draft,
                }

    return rejectcedaf5294e19b6f85c25890e13782845.definition.url
            .replace('{draft}', parsedArgs.draft.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::reject
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:228
 * @route '/api/v1/ai/actions/{draft}/reject'
 */
rejectcedaf5294e19b6f85c25890e13782845.post = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectcedaf5294e19b6f85c25890e13782845.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::reject
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:228
 * @route '/api/v1/ai/actions/{draft}/reject'
 */
    const rejectcedaf5294e19b6f85c25890e13782845Form = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: rejectcedaf5294e19b6f85c25890e13782845.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::reject
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:228
 * @route '/api/v1/ai/actions/{draft}/reject'
 */
        rejectcedaf5294e19b6f85c25890e13782845Form.post = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rejectcedaf5294e19b6f85c25890e13782845.url(args, options),
            method: 'post',
        })
    
    rejectcedaf5294e19b6f85c25890e13782845.form = rejectcedaf5294e19b6f85c25890e13782845Form
    /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::reject
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:228
 * @route '/api/v1/ai/drafts/{draft}/reject'
 */
const reject39cab083ecc213f766cb8d482c91c36b = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject39cab083ecc213f766cb8d482c91c36b.url(args, options),
    method: 'post',
})

reject39cab083ecc213f766cb8d482c91c36b.definition = {
    methods: ["post"],
    url: '/api/v1/ai/drafts/{draft}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::reject
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:228
 * @route '/api/v1/ai/drafts/{draft}/reject'
 */
reject39cab083ecc213f766cb8d482c91c36b.url = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { draft: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    draft: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        draft: args.draft,
                }

    return reject39cab083ecc213f766cb8d482c91c36b.definition.url
            .replace('{draft}', parsedArgs.draft.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::reject
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:228
 * @route '/api/v1/ai/drafts/{draft}/reject'
 */
reject39cab083ecc213f766cb8d482c91c36b.post = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject39cab083ecc213f766cb8d482c91c36b.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::reject
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:228
 * @route '/api/v1/ai/drafts/{draft}/reject'
 */
    const reject39cab083ecc213f766cb8d482c91c36bForm = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject39cab083ecc213f766cb8d482c91c36b.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::reject
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:228
 * @route '/api/v1/ai/drafts/{draft}/reject'
 */
        reject39cab083ecc213f766cb8d482c91c36bForm.post = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject39cab083ecc213f766cb8d482c91c36b.url(args, options),
            method: 'post',
        })
    
    reject39cab083ecc213f766cb8d482c91c36b.form = reject39cab083ecc213f766cb8d482c91c36bForm

export const reject = {
    '/api/v1/ai/actions/{draft}/reject': rejectcedaf5294e19b6f85c25890e13782845,
    '/api/v1/ai/drafts/{draft}/reject': reject39cab083ecc213f766cb8d482c91c36b,
}

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::feedback
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:304
 * @route '/api/v1/ai/actions/{draft}/feedback'
 */
export const feedback = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: feedback.url(args, options),
    method: 'post',
})

feedback.definition = {
    methods: ["post"],
    url: '/api/v1/ai/actions/{draft}/feedback',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::feedback
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:304
 * @route '/api/v1/ai/actions/{draft}/feedback'
 */
feedback.url = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { draft: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    draft: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        draft: args.draft,
                }

    return feedback.definition.url
            .replace('{draft}', parsedArgs.draft.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiActionsController::feedback
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:304
 * @route '/api/v1/ai/actions/{draft}/feedback'
 */
feedback.post = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: feedback.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::feedback
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:304
 * @route '/api/v1/ai/actions/{draft}/feedback'
 */
    const feedbackForm = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: feedback.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiActionsController::feedback
 * @see app/Http/Controllers/Api/V1/AiActionsController.php:304
 * @route '/api/v1/ai/actions/{draft}/feedback'
 */
        feedbackForm.post = (args: { draft: string | number } | [draft: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: feedback.url(args, options),
            method: 'post',
        })
    
    feedback.form = feedbackForm
const AiActionsController = { plan, approve, reject, feedback }

export default AiActionsController