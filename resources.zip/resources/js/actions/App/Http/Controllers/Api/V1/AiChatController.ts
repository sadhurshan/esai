import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\AiChatController::index
 * @see app/Http/Controllers/Api/V1/AiChatController.php:33
 * @route '/api/v1/ai/chat/threads'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/ai/chat/threads',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::index
 * @see app/Http/Controllers/Api/V1/AiChatController.php:33
 * @route '/api/v1/ai/chat/threads'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::index
 * @see app/Http/Controllers/Api/V1/AiChatController.php:33
 * @route '/api/v1/ai/chat/threads'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AiChatController::index
 * @see app/Http/Controllers/Api/V1/AiChatController.php:33
 * @route '/api/v1/ai/chat/threads'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiChatController::index
 * @see app/Http/Controllers/Api/V1/AiChatController.php:33
 * @route '/api/v1/ai/chat/threads'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiChatController::index
 * @see app/Http/Controllers/Api/V1/AiChatController.php:33
 * @route '/api/v1/ai/chat/threads'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AiChatController::index
 * @see app/Http/Controllers/Api/V1/AiChatController.php:33
 * @route '/api/v1/ai/chat/threads'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\V1\AiChatController::store
 * @see app/Http/Controllers/Api/V1/AiChatController.php:97
 * @route '/api/v1/ai/chat/threads'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/v1/ai/chat/threads',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::store
 * @see app/Http/Controllers/Api/V1/AiChatController.php:97
 * @route '/api/v1/ai/chat/threads'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::store
 * @see app/Http/Controllers/Api/V1/AiChatController.php:97
 * @route '/api/v1/ai/chat/threads'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiChatController::store
 * @see app/Http/Controllers/Api/V1/AiChatController.php:97
 * @route '/api/v1/ai/chat/threads'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiChatController::store
 * @see app/Http/Controllers/Api/V1/AiChatController.php:97
 * @route '/api/v1/ai/chat/threads'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\V1\AiChatController::show
 * @see app/Http/Controllers/Api/V1/AiChatController.php:121
 * @route '/api/v1/ai/chat/threads/{thread}'
 */
export const show = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/v1/ai/chat/threads/{thread}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::show
 * @see app/Http/Controllers/Api/V1/AiChatController.php:121
 * @route '/api/v1/ai/chat/threads/{thread}'
 */
show.url = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { thread: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    thread: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        thread: args.thread,
                }

    return show.definition.url
            .replace('{thread}', parsedArgs.thread.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::show
 * @see app/Http/Controllers/Api/V1/AiChatController.php:121
 * @route '/api/v1/ai/chat/threads/{thread}'
 */
show.get = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AiChatController::show
 * @see app/Http/Controllers/Api/V1/AiChatController.php:121
 * @route '/api/v1/ai/chat/threads/{thread}'
 */
show.head = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiChatController::show
 * @see app/Http/Controllers/Api/V1/AiChatController.php:121
 * @route '/api/v1/ai/chat/threads/{thread}'
 */
    const showForm = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiChatController::show
 * @see app/Http/Controllers/Api/V1/AiChatController.php:121
 * @route '/api/v1/ai/chat/threads/{thread}'
 */
        showForm.get = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AiChatController::show
 * @see app/Http/Controllers/Api/V1/AiChatController.php:121
 * @route '/api/v1/ai/chat/threads/{thread}'
 */
        showForm.head = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\V1\AiChatController::stream
 * @see app/Http/Controllers/Api/V1/AiChatController.php:226
 * @route '/api/v1/ai/chat/threads/{thread}/stream'
 */
export const stream = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})

stream.definition = {
    methods: ["get","head"],
    url: '/api/v1/ai/chat/threads/{thread}/stream',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::stream
 * @see app/Http/Controllers/Api/V1/AiChatController.php:226
 * @route '/api/v1/ai/chat/threads/{thread}/stream'
 */
stream.url = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { thread: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    thread: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        thread: args.thread,
                }

    return stream.definition.url
            .replace('{thread}', parsedArgs.thread.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::stream
 * @see app/Http/Controllers/Api/V1/AiChatController.php:226
 * @route '/api/v1/ai/chat/threads/{thread}/stream'
 */
stream.get = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: stream.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AiChatController::stream
 * @see app/Http/Controllers/Api/V1/AiChatController.php:226
 * @route '/api/v1/ai/chat/threads/{thread}/stream'
 */
stream.head = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: stream.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiChatController::stream
 * @see app/Http/Controllers/Api/V1/AiChatController.php:226
 * @route '/api/v1/ai/chat/threads/{thread}/stream'
 */
    const streamForm = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: stream.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiChatController::stream
 * @see app/Http/Controllers/Api/V1/AiChatController.php:226
 * @route '/api/v1/ai/chat/threads/{thread}/stream'
 */
        streamForm.get = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AiChatController::stream
 * @see app/Http/Controllers/Api/V1/AiChatController.php:226
 * @route '/api/v1/ai/chat/threads/{thread}/stream'
 */
        streamForm.head = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: stream.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    stream.form = streamForm
/**
* @see \App\Http\Controllers\Api\V1\AiChatController::send
 * @see app/Http/Controllers/Api/V1/AiChatController.php:172
 * @route '/api/v1/ai/chat/threads/{thread}/send'
 */
export const send = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/api/v1/ai/chat/threads/{thread}/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::send
 * @see app/Http/Controllers/Api/V1/AiChatController.php:172
 * @route '/api/v1/ai/chat/threads/{thread}/send'
 */
send.url = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { thread: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    thread: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        thread: args.thread,
                }

    return send.definition.url
            .replace('{thread}', parsedArgs.thread.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::send
 * @see app/Http/Controllers/Api/V1/AiChatController.php:172
 * @route '/api/v1/ai/chat/threads/{thread}/send'
 */
send.post = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiChatController::send
 * @see app/Http/Controllers/Api/V1/AiChatController.php:172
 * @route '/api/v1/ai/chat/threads/{thread}/send'
 */
    const sendForm = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiChatController::send
 * @see app/Http/Controllers/Api/V1/AiChatController.php:172
 * @route '/api/v1/ai/chat/threads/{thread}/send'
 */
        sendForm.post = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(args, options),
            method: 'post',
        })
    
    send.form = sendForm
/**
* @see \App\Http\Controllers\Api\V1\AiChatController::resolveTools
 * @see app/Http/Controllers/Api/V1/AiChatController.php:288
 * @route '/api/v1/ai/chat/threads/{thread}/tools/resolve'
 */
export const resolveTools = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resolveTools.url(args, options),
    method: 'post',
})

resolveTools.definition = {
    methods: ["post"],
    url: '/api/v1/ai/chat/threads/{thread}/tools/resolve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::resolveTools
 * @see app/Http/Controllers/Api/V1/AiChatController.php:288
 * @route '/api/v1/ai/chat/threads/{thread}/tools/resolve'
 */
resolveTools.url = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { thread: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    thread: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        thread: args.thread,
                }

    return resolveTools.definition.url
            .replace('{thread}', parsedArgs.thread.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiChatController::resolveTools
 * @see app/Http/Controllers/Api/V1/AiChatController.php:288
 * @route '/api/v1/ai/chat/threads/{thread}/tools/resolve'
 */
resolveTools.post = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resolveTools.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiChatController::resolveTools
 * @see app/Http/Controllers/Api/V1/AiChatController.php:288
 * @route '/api/v1/ai/chat/threads/{thread}/tools/resolve'
 */
    const resolveToolsForm = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resolveTools.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiChatController::resolveTools
 * @see app/Http/Controllers/Api/V1/AiChatController.php:288
 * @route '/api/v1/ai/chat/threads/{thread}/tools/resolve'
 */
        resolveToolsForm.post = (args: { thread: string | number } | [thread: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resolveTools.url(args, options),
            method: 'post',
        })
    
    resolveTools.form = resolveToolsForm
const AiChatController = { index, store, show, stream, send, resolveTools }

export default AiChatController