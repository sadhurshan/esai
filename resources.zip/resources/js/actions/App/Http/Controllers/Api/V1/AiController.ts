import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\AiController::forecast
 * @see app/Http/Controllers/Api/V1/AiController.php:27
 * @route '/api/ai/forecast'
 */
export const forecast = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forecast.url(options),
    method: 'post',
})

forecast.definition = {
    methods: ["post"],
    url: '/api/ai/forecast',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiController::forecast
 * @see app/Http/Controllers/Api/V1/AiController.php:27
 * @route '/api/ai/forecast'
 */
forecast.url = (options?: RouteQueryOptions) => {
    return forecast.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiController::forecast
 * @see app/Http/Controllers/Api/V1/AiController.php:27
 * @route '/api/ai/forecast'
 */
forecast.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forecast.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiController::forecast
 * @see app/Http/Controllers/Api/V1/AiController.php:27
 * @route '/api/ai/forecast'
 */
    const forecastForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forecast.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiController::forecast
 * @see app/Http/Controllers/Api/V1/AiController.php:27
 * @route '/api/ai/forecast'
 */
        forecastForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forecast.url(options),
            method: 'post',
        })
    
    forecast.form = forecastForm
/**
* @see \App\Http\Controllers\Api\V1\AiController::supplierRisk
 * @see app/Http/Controllers/Api/V1/AiController.php:87
 * @route '/api/ai/supplier-risk'
 */
export const supplierRisk = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: supplierRisk.url(options),
    method: 'post',
})

supplierRisk.definition = {
    methods: ["post"],
    url: '/api/ai/supplier-risk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiController::supplierRisk
 * @see app/Http/Controllers/Api/V1/AiController.php:87
 * @route '/api/ai/supplier-risk'
 */
supplierRisk.url = (options?: RouteQueryOptions) => {
    return supplierRisk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiController::supplierRisk
 * @see app/Http/Controllers/Api/V1/AiController.php:87
 * @route '/api/ai/supplier-risk'
 */
supplierRisk.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: supplierRisk.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiController::supplierRisk
 * @see app/Http/Controllers/Api/V1/AiController.php:87
 * @route '/api/ai/supplier-risk'
 */
    const supplierRiskForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: supplierRisk.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiController::supplierRisk
 * @see app/Http/Controllers/Api/V1/AiController.php:87
 * @route '/api/ai/supplier-risk'
 */
        supplierRiskForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: supplierRisk.url(options),
            method: 'post',
        })
    
    supplierRisk.form = supplierRiskForm
const AiController = { forecast, supplierRisk }

export default AiController