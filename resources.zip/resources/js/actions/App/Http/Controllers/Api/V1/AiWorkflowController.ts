import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::index
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:36
 * @route '/api/v1/ai/workflows'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/ai/workflows',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::index
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:36
 * @route '/api/v1/ai/workflows'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::index
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:36
 * @route '/api/v1/ai/workflows'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::index
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:36
 * @route '/api/v1/ai/workflows'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::index
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:36
 * @route '/api/v1/ai/workflows'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::index
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:36
 * @route '/api/v1/ai/workflows'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::index
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:36
 * @route '/api/v1/ai/workflows'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::start
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:87
 * @route '/api/v1/ai/workflows/start'
 */
export const start = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/api/v1/ai/workflows/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::start
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:87
 * @route '/api/v1/ai/workflows/start'
 */
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::start
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:87
 * @route '/api/v1/ai/workflows/start'
 */
start.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::start
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:87
 * @route '/api/v1/ai/workflows/start'
 */
    const startForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::start
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:87
 * @route '/api/v1/ai/workflows/start'
 */
        startForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::next
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:133
 * @route '/api/v1/ai/workflows/{workflow}/next'
 */
export const next = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: next.url(args, options),
    method: 'get',
})

next.definition = {
    methods: ["get","head"],
    url: '/api/v1/ai/workflows/{workflow}/next',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::next
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:133
 * @route '/api/v1/ai/workflows/{workflow}/next'
 */
next.url = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: args.workflow,
                }

    return next.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::next
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:133
 * @route '/api/v1/ai/workflows/{workflow}/next'
 */
next.get = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: next.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::next
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:133
 * @route '/api/v1/ai/workflows/{workflow}/next'
 */
next.head = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: next.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::next
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:133
 * @route '/api/v1/ai/workflows/{workflow}/next'
 */
    const nextForm = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: next.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::next
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:133
 * @route '/api/v1/ai/workflows/{workflow}/next'
 */
        nextForm.get = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: next.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::next
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:133
 * @route '/api/v1/ai/workflows/{workflow}/next'
 */
        nextForm.head = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: next.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    next.form = nextForm
/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::events
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:173
 * @route '/api/v1/ai/workflows/{workflow}/events'
 */
export const events = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: events.url(args, options),
    method: 'get',
})

events.definition = {
    methods: ["get","head"],
    url: '/api/v1/ai/workflows/{workflow}/events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::events
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:173
 * @route '/api/v1/ai/workflows/{workflow}/events'
 */
events.url = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: args.workflow,
                }

    return events.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::events
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:173
 * @route '/api/v1/ai/workflows/{workflow}/events'
 */
events.get = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: events.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::events
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:173
 * @route '/api/v1/ai/workflows/{workflow}/events'
 */
events.head = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: events.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::events
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:173
 * @route '/api/v1/ai/workflows/{workflow}/events'
 */
    const eventsForm = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: events.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::events
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:173
 * @route '/api/v1/ai/workflows/{workflow}/events'
 */
        eventsForm.get = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: events.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::events
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:173
 * @route '/api/v1/ai/workflows/{workflow}/events'
 */
        eventsForm.head = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: events.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    events.form = eventsForm
/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::complete
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:222
 * @route '/api/v1/ai/workflows/{workflow}/complete'
 */
export const complete = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/api/v1/ai/workflows/{workflow}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::complete
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:222
 * @route '/api/v1/ai/workflows/{workflow}/complete'
 */
complete.url = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workflow: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    workflow: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        workflow: args.workflow,
                }

    return complete.definition.url
            .replace('{workflow}', parsedArgs.workflow.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::complete
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:222
 * @route '/api/v1/ai/workflows/{workflow}/complete'
 */
complete.post = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::complete
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:222
 * @route '/api/v1/ai/workflows/{workflow}/complete'
 */
    const completeForm = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AiWorkflowController::complete
 * @see app/Http/Controllers/Api/V1/AiWorkflowController.php:222
 * @route '/api/v1/ai/workflows/{workflow}/complete'
 */
        completeForm.post = (args: { workflow: string | number } | [workflow: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, options),
            method: 'post',
        })
    
    complete.form = completeForm
const AiWorkflowController = { index, start, next, events, complete }

export default AiWorkflowController