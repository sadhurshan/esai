import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierOptions
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:158
 * @route '/api/v1/analytics/supplier-options'
 */
export const supplierOptions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: supplierOptions.url(options),
    method: 'get',
})

supplierOptions.definition = {
    methods: ["get","head"],
    url: '/api/v1/analytics/supplier-options',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierOptions
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:158
 * @route '/api/v1/analytics/supplier-options'
 */
supplierOptions.url = (options?: RouteQueryOptions) => {
    return supplierOptions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierOptions
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:158
 * @route '/api/v1/analytics/supplier-options'
 */
supplierOptions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: supplierOptions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierOptions
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:158
 * @route '/api/v1/analytics/supplier-options'
 */
supplierOptions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: supplierOptions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierOptions
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:158
 * @route '/api/v1/analytics/supplier-options'
 */
    const supplierOptionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: supplierOptions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierOptions
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:158
 * @route '/api/v1/analytics/supplier-options'
 */
        supplierOptionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: supplierOptions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierOptions
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:158
 * @route '/api/v1/analytics/supplier-options'
 */
        supplierOptionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: supplierOptions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    supplierOptions.form = supplierOptionsForm
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::forecastReport
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/forecast-report'
 */
export const forecastReport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forecastReport.url(options),
    method: 'post',
})

forecastReport.definition = {
    methods: ["post"],
    url: '/api/v1/analytics/forecast-report',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::forecastReport
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/forecast-report'
 */
forecastReport.url = (options?: RouteQueryOptions) => {
    return forecastReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::forecastReport
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/forecast-report'
 */
forecastReport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forecastReport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::forecastReport
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/forecast-report'
 */
    const forecastReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forecastReport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::forecastReport
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:41
 * @route '/api/v1/analytics/forecast-report'
 */
        forecastReportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forecastReport.url(options),
            method: 'post',
        })
    
    forecastReport.form = forecastReportForm
/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierPerformanceReport
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:90
 * @route '/api/v1/analytics/supplier-performance-report'
 */
export const supplierPerformanceReport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: supplierPerformanceReport.url(options),
    method: 'post',
})

supplierPerformanceReport.definition = {
    methods: ["post"],
    url: '/api/v1/analytics/supplier-performance-report',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierPerformanceReport
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:90
 * @route '/api/v1/analytics/supplier-performance-report'
 */
supplierPerformanceReport.url = (options?: RouteQueryOptions) => {
    return supplierPerformanceReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierPerformanceReport
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:90
 * @route '/api/v1/analytics/supplier-performance-report'
 */
supplierPerformanceReport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: supplierPerformanceReport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierPerformanceReport
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:90
 * @route '/api/v1/analytics/supplier-performance-report'
 */
    const supplierPerformanceReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: supplierPerformanceReport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\V1\AnalyticsController::supplierPerformanceReport
 * @see app/Http/Controllers/Api/V1/AnalyticsController.php:90
 * @route '/api/v1/analytics/supplier-performance-report'
 */
        supplierPerformanceReportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: supplierPerformanceReport.url(options),
            method: 'post',
        })
    
    supplierPerformanceReport.form = supplierPerformanceReportForm
const AnalyticsController = { supplierOptions, forecastReport, supplierPerformanceReport }

export default AnalyticsController