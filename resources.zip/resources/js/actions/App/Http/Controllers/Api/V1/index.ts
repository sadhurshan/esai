import AiController from './AiController'
import AiActionsController from './AiActionsController'
import AiChatController from './AiChatController'
import AiWorkflowController from './AiWorkflowController'
import AnalyticsController from './AnalyticsController'
const V1 = {
    AiController: Object.assign(AiController, AiController),
AiActionsController: Object.assign(AiActionsController, AiActionsController),
AiChatController: Object.assign(AiChatController, AiChatController),
AiWorkflowController: Object.assign(AiWorkflowController, AiWorkflowController),
AnalyticsController: Object.assign(AnalyticsController, AnalyticsController),
}

export default V1