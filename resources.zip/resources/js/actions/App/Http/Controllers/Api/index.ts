import HealthController from './HealthController'
import DocsController from './DocsController'
import PlanCatalogController from './PlanCatalogController'
import CompanyInvitationController from './CompanyInvitationController'
import CompanyPlanController from './CompanyPlanController'
import Billing from './Billing'
import SupplierDocumentController from './SupplierDocumentController'
import UserProfileController from './UserProfileController'
import UserCompanyController from './UserCompanyController'
import SupplierSelfServiceController from './SupplierSelfServiceController'
import SupplierApplicationController from './SupplierApplicationController'
import Admin from './Admin'
import FileController from './FileController'
import SupplierController from './SupplierController'
import SupplierEsgController from './SupplierEsgController'
import V1 from './V1'
import Ai from './Ai'
import Library from './Library'
import RfpController from './RfpController'
import RfpProposalController from './RfpProposalController'
import RFQController from './RFQController'
import RfqLineController from './RfqLineController'
import RfqAttachmentController from './RfqAttachmentController'
import RfqTimelineController from './RfqTimelineController'
import RfqInvitationController from './RfqInvitationController'
import QuoteController from './QuoteController'
import RfqAwardCandidateController from './RfqAwardCandidateController'
import QuoteRevisionController from './QuoteRevisionController'
import AwardController from './AwardController'
import RfqAwardController from './RfqAwardController'
import RfqClarificationController from './RfqClarificationController'
import RFQQuoteController from './RFQQuoteController'
import AwardLineController from './AwardLineController'
import QuoteShortlistController from './QuoteShortlistController'
import PurchaseOrderController from './PurchaseOrderController'
import Orders from './Orders'
import SupplierDashboardController from './SupplierDashboardController'
import Supplier from './Supplier'
import QuoteInboxController from './QuoteInboxController'
import QuoteLineController from './QuoteLineController'
import SupplierQuoteController from './SupplierQuoteController'
import SupplierRfqInboxController from './SupplierRfqInboxController'
import PoChangeOrderController from './PoChangeOrderController'
import InvoiceController from './InvoiceController'
import GoodsReceiptNoteController from './GoodsReceiptNoteController'
import PurchaseOrderShipmentController from './PurchaseOrderShipmentController'
import NcrController from './NcrController'
import CompanyRegistrationController from './CompanyRegistrationController'
import CompanyDocumentController from './CompanyDocumentController'
import Inventory from './Inventory'
import DocumentController from './DocumentController'
import CompanyMemberController from './CompanyMemberController'
import CompanyRoleTemplateController from './CompanyRoleTemplateController'
import Settings from './Settings'
import Localization from './Localization'
import DashboardController from './DashboardController'
import DigitalTwin from './DigitalTwin'
import SearchController from './SearchController'
import SavedSearchController from './SavedSearchController'
import AnalyticsController from './AnalyticsController'
import CopilotController from './CopilotController'
import SupplierRiskController from './SupplierRiskController'
import NotificationController from './NotificationController'
import EventDeliveryController from './EventDeliveryController'
import NotificationPreferenceController from './NotificationPreferenceController'
import RmaController from './RmaController'
import ExportController from './ExportController'
import DownloadJobController from './DownloadJobController'
import CreditNoteController from './CreditNoteController'
import MoneySettingsController from './MoneySettingsController'
import FxRateController from './FxRateController'
import TaxCodeController from './TaxCodeController'
import QuoteTotalsController from './QuoteTotalsController'
import PoTotalsController from './PoTotalsController'
import InvoiceTotalsController from './InvoiceTotalsController'
import CreditTotalsController from './CreditTotalsController'
import ApprovalRuleController from './ApprovalRuleController'
import ApprovalRequestController from './ApprovalRequestController'
import DelegationController from './DelegationController'
import Auth from './Auth'
const Api = {
    HealthController: Object.assign(HealthController, HealthController),
DocsController: Object.assign(DocsController, DocsController),
PlanCatalogController: Object.assign(PlanCatalogController, PlanCatalogController),
CompanyInvitationController: Object.assign(CompanyInvitationController, CompanyInvitationController),
CompanyPlanController: Object.assign(CompanyPlanController, CompanyPlanController),
Billing: Object.assign(Billing, Billing),
SupplierDocumentController: Object.assign(SupplierDocumentController, SupplierDocumentController),
UserProfileController: Object.assign(UserProfileController, UserProfileController),
UserCompanyController: Object.assign(UserCompanyController, UserCompanyController),
SupplierSelfServiceController: Object.assign(SupplierSelfServiceController, SupplierSelfServiceController),
SupplierApplicationController: Object.assign(SupplierApplicationController, SupplierApplicationController),
Admin: Object.assign(Admin, Admin),
FileController: Object.assign(FileController, FileController),
SupplierController: Object.assign(SupplierController, SupplierController),
SupplierEsgController: Object.assign(SupplierEsgController, SupplierEsgController),
V1: Object.assign(V1, V1),
Ai: Object.assign(Ai, Ai),
Library: Object.assign(Library, Library),
RfpController: Object.assign(RfpController, RfpController),
RfpProposalController: Object.assign(RfpProposalController, RfpProposalController),
RFQController: Object.assign(RFQController, RFQController),
RfqLineController: Object.assign(RfqLineController, RfqLineController),
RfqAttachmentController: Object.assign(RfqAttachmentController, RfqAttachmentController),
RfqTimelineController: Object.assign(RfqTimelineController, RfqTimelineController),
RfqInvitationController: Object.assign(RfqInvitationController, RfqInvitationController),
QuoteController: Object.assign(QuoteController, QuoteController),
RfqAwardCandidateController: Object.assign(RfqAwardCandidateController, RfqAwardCandidateController),
QuoteRevisionController: Object.assign(QuoteRevisionController, QuoteRevisionController),
AwardController: Object.assign(AwardController, AwardController),
RfqAwardController: Object.assign(RfqAwardController, RfqAwardController),
RfqClarificationController: Object.assign(RfqClarificationController, RfqClarificationController),
RFQQuoteController: Object.assign(RFQQuoteController, RFQQuoteController),
AwardLineController: Object.assign(AwardLineController, AwardLineController),
QuoteShortlistController: Object.assign(QuoteShortlistController, QuoteShortlistController),
PurchaseOrderController: Object.assign(PurchaseOrderController, PurchaseOrderController),
Orders: Object.assign(Orders, Orders),
SupplierDashboardController: Object.assign(SupplierDashboardController, SupplierDashboardController),
Supplier: Object.assign(Supplier, Supplier),
QuoteInboxController: Object.assign(QuoteInboxController, QuoteInboxController),
QuoteLineController: Object.assign(QuoteLineController, QuoteLineController),
SupplierQuoteController: Object.assign(SupplierQuoteController, SupplierQuoteController),
SupplierRfqInboxController: Object.assign(SupplierRfqInboxController, SupplierRfqInboxController),
PoChangeOrderController: Object.assign(PoChangeOrderController, PoChangeOrderController),
InvoiceController: Object.assign(InvoiceController, InvoiceController),
GoodsReceiptNoteController: Object.assign(GoodsReceiptNoteController, GoodsReceiptNoteController),
PurchaseOrderShipmentController: Object.assign(PurchaseOrderShipmentController, PurchaseOrderShipmentController),
NcrController: Object.assign(NcrController, NcrController),
CompanyRegistrationController: Object.assign(CompanyRegistrationController, CompanyRegistrationController),
CompanyDocumentController: Object.assign(CompanyDocumentController, CompanyDocumentController),
Inventory: Object.assign(Inventory, Inventory),
DocumentController: Object.assign(DocumentController, DocumentController),
CompanyMemberController: Object.assign(CompanyMemberController, CompanyMemberController),
CompanyRoleTemplateController: Object.assign(CompanyRoleTemplateController, CompanyRoleTemplateController),
Settings: Object.assign(Settings, Settings),
Localization: Object.assign(Localization, Localization),
DashboardController: Object.assign(DashboardController, DashboardController),
DigitalTwin: Object.assign(DigitalTwin, DigitalTwin),
SearchController: Object.assign(SearchController, SearchController),
SavedSearchController: Object.assign(SavedSearchController, SavedSearchController),
AnalyticsController: Object.assign(AnalyticsController, AnalyticsController),
CopilotController: Object.assign(CopilotController, CopilotController),
SupplierRiskController: Object.assign(SupplierRiskController, SupplierRiskController),
NotificationController: Object.assign(NotificationController, NotificationController),
EventDeliveryController: Object.assign(EventDeliveryController, EventDeliveryController),
NotificationPreferenceController: Object.assign(NotificationPreferenceController, NotificationPreferenceController),
RmaController: Object.assign(RmaController, RmaController),
ExportController: Object.assign(ExportController, ExportController),
DownloadJobController: Object.assign(DownloadJobController, DownloadJobController),
CreditNoteController: Object.assign(CreditNoteController, CreditNoteController),
MoneySettingsController: Object.assign(MoneySettingsController, MoneySettingsController),
FxRateController: Object.assign(FxRateController, FxRateController),
TaxCodeController: Object.assign(TaxCodeController, TaxCodeController),
QuoteTotalsController: Object.assign(QuoteTotalsController, QuoteTotalsController),
PoTotalsController: Object.assign(PoTotalsController, PoTotalsController),
InvoiceTotalsController: Object.assign(InvoiceTotalsController, InvoiceTotalsController),
CreditTotalsController: Object.assign(CreditTotalsController, CreditTotalsController),
ApprovalRuleController: Object.assign(ApprovalRuleController, ApprovalRuleController),
ApprovalRequestController: Object.assign(ApprovalRequestController, ApprovalRequestController),
DelegationController: Object.assign(DelegationController, DelegationController),
Auth: Object.assign(Auth, Auth),
}

export default Api